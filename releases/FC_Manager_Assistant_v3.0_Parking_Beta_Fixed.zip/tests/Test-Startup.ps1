﻿param([string]$Source = "$PSScriptRoot/../FCManager.ps1")
$ErrorActionPreference = 'Stop'
$tokens = $null; $errors = $null
$ast = [Management.Automation.Language.Parser]::ParseFile($Source, [ref]$tokens, [ref]$errors)
if ($errors.Count) { throw ($errors | Out-String) }
try {
    foreach ($statement in $ast.EndBlock.Statements) {
        $text = $statement.Extent.Text
        if ($text.StartsWith('$generalModeRadio.Add_CheckedChanged')) { break }
        if ($text.StartsWith('$script:appDir =')) {
            $script:appDir = (Resolve-Path (Split-Path $Source)).Path
            continue
        }
        Invoke-Expression $text
    }
    if ($script:templates.Count -ne 11 -or $script:hdTemplates.Count -ne 11) { throw 'Template initialization failed' }
    if ($form.Controls.Count -lt 10) { throw 'Form initialization failed' }
    Write-Output 'PASS startup initialization: form and 22 templates; no timer, hotkey registration, native input or network requests'
} finally {
    if ($null -ne $form) { $form.Dispose() }
    if ($null -ne $script:httpClient) { $script:httpClient.Dispose() }
}
