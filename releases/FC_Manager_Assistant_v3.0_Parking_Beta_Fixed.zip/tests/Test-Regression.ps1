﻿param([string]$Source = "$PSScriptRoot/../FCManager.ps1")
$ErrorActionPreference = 'Stop'
$tokens = $null; $errors = $null
$ast = [Management.Automation.Language.Parser]::ParseFile($Source, [ref]$tokens, [ref]$errors)
if ($errors.Count) { throw ($errors | Out-String) }
Add-Type -AssemblyName System.Drawing
# Compile all embedded C# without launching the UI or sending native input.
$commands = $ast.FindAll({ param($n) $n -is [Management.Automation.Language.CommandAst] -and $n.GetCommandName() -eq 'Add-Type' }, $true)
foreach ($command in $commands) {
    if ($command.Extent.Text.Contains('@"')) { Invoke-Expression $command.Extent.Text }
}
$functions = $ast.FindAll({ param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] }, $true)
foreach ($function in $functions) { Invoke-Expression $function.Extent.Text }
function Write-Log { param($message) }
function Set-Status { param($text, $color) }
function Show-TopmostError { param($message, $titleText) $script:blocked = $true }
function Get-ForegroundInfo { return $script:foreground }
function Invoke-KeyTap { param($scanCode) $script:inputCount++ }
function Mark-AutomationProgress { param($fileName, $label) }
function Update-Counters {}
function Reset-TestState {
    foreach ($name in @('parkingModeRadio','onlyFcCheck','minimumPointsCheck','startButton','stopButton','finishMatchButton','generalModeRadio','readRankButton','targetPointsBox','minimumPointsBox','windowLabel')) {
        Set-Variable -Scope Script -Name $name -Value ([pscustomobject]@{ Checked = $false; Enabled = $true; Value = 0; Text = ''; BackColor = $null })
    }
    $script:targetPointsBox.Value = 5000
    $script:startingRankPoints = 4000
    $script:currentRankPoints = 4020
    $script:startingRankReadAt = [DateTime]::Now
    $script:foreground = [pscustomobject]@{ Allowed = $true; Handle = [IntPtr]1 }
    $script:running = $false
    $script:resultScreenCounted = $false
    $script:requiredStopAfterMatch = $false
    $script:stopAfterCurrentMatch = $false
    $script:lastTemplateActions = @{}
    $script:blocked = $false
    $script:inputCount = 0
}
$script:failures = 0
function Check($name, [scriptblock]$test) {
    Reset-TestState
    try { & $test; Write-Output "PASS $name" }
    catch { $script:failures++; Write-Output "FAIL ${name}: $($_.Exception.Message)" }
}
Check 'Parking restart requires a fresh rank reading' {
    $parkingModeRadio.Checked = $true
    Start-Automation
    if (-not $script:running) { throw 'Initial start failed' }
    $script:currentRankPoints = 4020
    $script:running = $false
    Start-Automation
    if ($script:running -or -not $script:blocked -or $script:currentRankPoints -ne 4020) { throw 'Restart reuses stale 4000 points' }
}
Check 'Restart preserves result deduplication' {
    $script:resultScreenCounted = $true
    Start-Automation
    if (-not $script:resultScreenCounted) { throw 'Already counted result becomes countable again' }
}
Check 'F8 cannot cancel a required parking stop' {
    $script:running = $true
    $script:requiredStopAfterMatch = $true
    $script:stopAfterCurrentMatch = $true
    Toggle-FinishMatchReservation
    if (-not $script:stopAfterCurrentMatch) { throw 'Required stop canceled' }
}
Check 'Manual stop reservation still toggles' {
    $script:running = $true
    Toggle-FinishMatchReservation
    if (-not $script:stopAfterCurrentMatch) { throw 'Reservation not set' }
    Toggle-FinishMatchReservation
    if ($script:stopAfterCurrentMatch) { throw 'Reservation not canceled' }
}
Check 'Focus change during recognition blocks input' {
    $onlyFcCheck.Checked = $true
    $script:foreground = [pscustomobject]@{ Allowed = $false; Handle = [IntPtr]2 }
    $recognized = [pscustomobject]@{ Template = [pscustomobject]@{ Definition = [pscustomobject]@{ File = 'space_1.png'; Action = 'space'; Label = 'test' } }; Match = [pscustomobject]@{ MeanDifference = 0 }; Source = '1280' }
    Invoke-TemplateAction $recognized ([pscustomobject]@{ Handle = [IntPtr]1 })
    if ($script:inputCount -ne 0) { throw 'Input sent to changed foreground window' }
}
Check 'Templates decode and round-trip through the pixel buffer' {
    $files = @(Get-ChildItem (Join-Path (Split-Path $Source) 'templates*') -Filter '*.png' -Recurse)
    if ($files.Count -ne 22) { throw 'Expected 22 templates' }
    foreach ($file in $files) {
        $bitmap = [Drawing.Bitmap]::new($file.FullName)
        try {
            $buffer = [FCTemplateMatcher]::FromBitmap($bitmap)
            $copy = [FCTemplateMatcher]::ToBitmap($buffer)
            try {
                if ($copy.Width -ne $bitmap.Width -or $copy.Height -ne $bitmap.Height) { throw 'Template dimensions changed' }
            } finally { $copy.Dispose() }
        } finally { $bitmap.Dispose() }
    }
}
Check 'Missing result frame forces a parking stop and counts only once' {
    function Get-SettledResultFrame { param($frame) [pscustomobject]@{ Frame = $frame; SameWindow = $true } }
    function Get-StableScoreResult { param($frame) [pscustomobject]@{ Frame = $frame; Score = [pscustomobject]@{ Found = $false } } }
    function Queue-DiscordNotification { param($titleText, $message) }
    function Save-MatchStats {}
    function Update-MatchCounter {}
    function Save-ResultSample { return '' }
    function Save-PointSample { return '' }
    function Save-DiagnosticInfo {}
    $script:parkingMode = $true
    $script:statsDate = Get-Date -Format 'yyyy-MM-dd'
    foreach ($prefix in @('session','today','total')) {
        foreach ($suffix in @('MatchCount','WinCount','DrawCount','LossCount','UnclassifiedCount')) {
            Set-Variable -Scope Script -Name ($prefix + $suffix) -Value 0
        }
    }
    $frame = [pscustomobject]@{ Buffer = $null }
    Register-CompletedMatch $frame
    Register-CompletedMatch $frame
    if (-not $script:requiredStopAfterMatch -or -not $script:stopAfterCurrentMatch) { throw 'Uncertain points did not force stop' }
    if ($script:sessionMatchCount -ne 1 -or $script:totalMatchCount -ne 1) { throw 'Result counted incorrectly' }
}
Check 'Windows OCR initialization and async file access' {
    $script:rankOcrEngine = $null
    Initialize-RankOcr
    $path = (Resolve-Path (Join-Path (Split-Path $Source) 'templates/click_1.png')).Path
    $file = Await-RankOcr ([Windows.Storage.StorageFile]::GetFileFromPathAsync($path)) ([Windows.Storage.StorageFile])
    if ($file.Name -ne 'click_1.png') { throw 'Async result mismatch' }
}
Write-Output "Failures: $script:failures"
if ($script:failures) { exit 1 }
