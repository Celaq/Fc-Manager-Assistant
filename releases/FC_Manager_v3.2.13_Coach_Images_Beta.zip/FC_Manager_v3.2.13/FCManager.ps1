﻿param(
    [int]$WatchPid,
    [long]$WatchStartTicks,
    [ValidatePattern('^[0-9a-f]{32}$')][string]$WatchToken
)
$ErrorActionPreference = "Stop"

function Test-DiscordWebhookUrl([string]$url) {
    if ([string]::IsNullOrWhiteSpace($url)) { return $false }
    return $url -match '^https://(canary\.|ptb\.)?(discord(?:app)?\.com)/api/webhooks/[0-9]+/[A-Za-z0-9._-]+/?$'
}

function Protect-DiscordWebhook([string]$url) {
    $secure = ConvertTo-SecureString -String $url -AsPlainText -Force
    return ConvertFrom-SecureString -SecureString $secure
}

function Unprotect-DiscordWebhook {
    if ([string]::IsNullOrWhiteSpace($script:encryptedWebhook)) { return "" }
    try {
        $secure = ConvertTo-SecureString -String $script:encryptedWebhook
        $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
        try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer) }
        finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) }
    } catch {
        return ""
    }
}

function Get-WatchExitKind([bool]$cleanMarker) {
    if ($cleanMarker) { return 'Clean' }
    return 'Unexpected'
}

function Invoke-HelperExitWatcher([int]$parentId, [long]$startedAt, [string]$token, [string]$appRoot) {
    $marker = Join-Path ([IO.Path]::GetTempPath()) "fc-manager-$token.closed"
    try {
        $process = Get-Process -Id $parentId -ErrorAction SilentlyContinue
        $exitCode = -1
        if ($process) {
            try {
                if ($process.StartTime.ToUniversalTime().Ticks -ne $startedAt) { return }
                $process.WaitForExit()
                $exitCode = $process.ExitCode
            } catch [InvalidOperationException] {
                # The process may end before Windows gives us its handle.
            } finally { $process.Dispose() }
        }
        if ((Get-WatchExitKind ([IO.File]::Exists($marker))) -eq 'Clean') { return }

        $settingsPath = Join-Path $appRoot 'settings.json'
        if (-not [IO.File]::Exists($settingsPath)) { return }
        $settings = Get-Content -LiteralPath $settingsPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if (-not $settings.DiscordEnabled) { return }
        $script:encryptedWebhook = [string]$settings.EncryptedWebhook
        $url = Unprotect-DiscordWebhook
        if (-not (Test-DiscordWebhookUrl $url)) { return }

        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $message = "**FC 감독모드 도우미 비정상 종료**`n도우미 프로세스가 정상 종료 확인 없이 닫혔습니다.`n시간: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
        if ($exitCode -ne -1) { $message += "`n종료 코드: $exitCode" }
        $body = @{content=$message;username='FC Manager Assistant'} | ConvertTo-Json -Compress
        for ($attempt = 1; $attempt -le 3; $attempt++) {
            try {
                Invoke-RestMethod -Method Post -Uri $url -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($body)) -TimeoutSec 10 | Out-Null
                return
            } catch {
                if ($attempt -lt 3) { Start-Sleep -Seconds (2 * $attempt) }
            }
        }
        $logFolder = Join-Path $appRoot '오류확인용_보내기/logs'
        if ([IO.Directory]::Exists($logFolder)) {
            Add-Content -LiteralPath (Join-Path $logFolder 'exit-watcher.log') -Value "[$(Get-Date -Format s)] 비정상 종료 Discord 알림 전송 실패" -Encoding UTF8
        }
    } finally {
        if ([IO.File]::Exists($marker)) { Remove-Item -LiteralPath $marker -ErrorAction SilentlyContinue }
    }
}

if ($WatchPid) {
    if ($WatchToken -and $WatchStartTicks) { Invoke-HelperExitWatcher $WatchPid $WatchStartTicks $WatchToken $PSScriptRoot }
    return
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Net.Http

Add-Type @"
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

public static class FCNative
{
    [StructLayout(LayoutKind.Sequential)]
    public struct INPUT
    {
        public uint type;
        public InputUnion U;
    }

    [StructLayout(LayoutKind.Explicit)]
    public struct InputUnion
    {
        [FieldOffset(0)] public KEYBDINPUT ki;
        [FieldOffset(0)] public MOUSEINPUT mi;
        [FieldOffset(0)] public HARDWAREINPUT hi;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct KEYBDINPUT
    {
        public ushort wVk;
        public ushort wScan;
        public uint dwFlags;
        public uint time;
        public UIntPtr dwExtraInfo;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct MOUSEINPUT
    {
        public int dx;
        public int dy;
        public uint mouseData;
        public uint dwFlags;
        public uint time;
        public UIntPtr dwExtraInfo;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct HARDWAREINPUT
    {
        public uint uMsg;
        public ushort wParamL;
        public ushort wParamH;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct RECT
    {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct POINT
    {
        public int X;
        public int Y;
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

    public static int LastInputError { get; private set; }

    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    public static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);

    [DllImport("user32.dll")]
    public static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);
    [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr hWnd, out RECT rect);
    [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr hWnd, ref POINT point);

    [DllImport("user32.dll")]
    public static extern short GetAsyncKeyState(int virtualKey);

    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool RegisterHotKey(IntPtr hWnd, int id, uint modifiers, uint virtualKey);

    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool UnregisterHotKey(IntPtr hWnd, int id);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool SetProcessDpiAwarenessContext(IntPtr dpiContext);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool SetProcessDPIAware();

    [DllImport("user32.dll")]
    private static extern bool GetCursorPos(out POINT point);

    [DllImport("user32.dll")]
    public static extern bool SetCursorPos(int x, int y);

    [DllImport("user32.dll")]
    private static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);

    public static bool LastClickUsedFallback { get; private set; }

    public static bool SendScanCode(ushort scanCode, bool keyUp)
    {
        const uint INPUT_KEYBOARD = 1;
        const uint KEYEVENTF_KEYUP = 0x0002;
        const uint KEYEVENTF_SCANCODE = 0x0008;

        INPUT input = new INPUT();
        input.type = INPUT_KEYBOARD;
        input.U.ki.wVk = 0;
        input.U.ki.wScan = scanCode;
        input.U.ki.dwFlags = KEYEVENTF_SCANCODE | (keyUp ? KEYEVENTF_KEYUP : 0);
        input.U.ki.time = 0;
        input.U.ki.dwExtraInfo = UIntPtr.Zero;
        uint sent = SendInput(1, new INPUT[] { input }, Marshal.SizeOf(typeof(INPUT)));
        LastInputError = sent == 1 ? 0 : Marshal.GetLastWin32Error();
        return sent == 1;
    }

    public static bool SendVirtualKey(ushort virtualKey, bool keyUp)
    {
        const uint INPUT_KEYBOARD = 1;
        const uint KEYEVENTF_KEYUP = 0x0002;

        INPUT input = new INPUT();
        input.type = INPUT_KEYBOARD;
        input.U.ki.wVk = virtualKey;
        input.U.ki.wScan = 0;
        input.U.ki.dwFlags = keyUp ? KEYEVENTF_KEYUP : 0;
        input.U.ki.time = 0;
        input.U.ki.dwExtraInfo = UIntPtr.Zero;
        uint sent = SendInput(1, new INPUT[] { input }, Marshal.SizeOf(typeof(INPUT)));
        LastInputError = sent == 1 ? 0 : Marshal.GetLastWin32Error();
        return sent == 1;
    }

    public static bool SendLeftClick(int screenX, int screenY)
    {
        const uint INPUT_MOUSE = 0;
        const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
        const uint MOUSEEVENTF_LEFTUP = 0x0004;

        LastClickUsedFallback = false;
        POINT oldPoint;
        bool haveOldPoint = GetCursorPos(out oldPoint);
        if (!SetCursorPos(screenX, screenY)) return false;

        // Give FC ONLINE a short moment to observe the new cursor position.
        // Sending movement and a click in the same instant was intermittently
        // returning zero inputs with no Windows error on some systems.
        System.Threading.Thread.Sleep(60);

        INPUT down = new INPUT();
        down.type = INPUT_MOUSE;
        down.U.mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
        INPUT up = new INPUT();
        up.type = INPUT_MOUSE;
        up.U.mi.dwFlags = MOUSEEVENTF_LEFTUP;

        uint sent = SendInput(2, new INPUT[] { down, up }, Marshal.SizeOf(typeof(INPUT)));
        LastInputError = sent == 2 ? 0 : Marshal.GetLastWin32Error();

        if (sent != 2)
        {
            // Legacy mouse_event is retained only as a compatibility fallback.
            // The next recognition cycle confirms whether the screen changed,
            // so a blocked fallback cannot silently advance the state machine.
            LastClickUsedFallback = true;
            mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, UIntPtr.Zero);
            System.Threading.Thread.Sleep(80);
            mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, UIntPtr.Zero);
            LastInputError = 0;
        }

        System.Threading.Thread.Sleep(80);
        if (haveOldPoint) SetCursorPos(oldPoint.X, oldPoint.Y);
        return true;
    }

    public static string GetTitle(IntPtr hWnd)
    {
        StringBuilder builder = new StringBuilder(512);
        GetWindowText(hWnd, builder, builder.Capacity);
        return builder.ToString();
    }

    public static string GetProcessName(IntPtr hWnd)
    {
        uint pid;
        GetWindowThreadProcessId(hWnd, out pid);
        if (pid == 0) return "";
        try { return Process.GetProcessById((int)pid).ProcessName; }
        catch { return ""; }
    }

    public static string EnableDpiAwareness()
    {
        try
        {
            // DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2. This makes
            // GetWindowRect, CopyFromScreen and SendInput share physical
            // pixel coordinates even when Windows scaling is above 100%.
            if (SetProcessDpiAwarenessContext(new IntPtr(-4)))
                return "Per-monitor V2";

            // ERROR_ACCESS_DENIED means the host already selected a DPI mode.
            if (Marshal.GetLastWin32Error() == 5)
                return "Already configured";
        }
        catch (EntryPointNotFoundException) { }

        try
        {
            if (SetProcessDPIAware()) return "System aware";
            if (Marshal.GetLastWin32Error() == 5) return "Already configured";
        }
        catch (EntryPointNotFoundException) { }
        return "Unavailable";
    }
}
"@

$script:dpiAwarenessMode = [FCNative]::EnableDpiAwareness()

Add-Type -ReferencedAssemblies "System.Drawing" -TypeDefinition @"
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Collections.Generic;

public sealed class FCPixelBuffer
{
    public int Width;
    public int Height;
    public int Stride;
    public byte[] Data;
}

public sealed class FCTemplateResult
{
    public bool Found;
    public int X;
    public int Y;
    public int MatchWidth;
    public int MatchHeight;
    public double MeanDifference;
}

public sealed class FCScoreResult
{
    public bool Found;
    public int LeftScore;
    public int RightScore;
    public double Confidence;
    public string Reason;
}

public static class FCTemplateMatcher
{
    public static FCPixelBuffer FromBitmap(Bitmap source)
    {
        Bitmap converted = new Bitmap(source.Width, source.Height, PixelFormat.Format32bppArgb);
        using (Graphics graphics = Graphics.FromImage(converted))
        {
            graphics.DrawImage(source, 0, 0, source.Width, source.Height);
        }

        Rectangle rect = new Rectangle(0, 0, converted.Width, converted.Height);
        BitmapData data = converted.LockBits(rect, ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        try
        {
            int byteCount = Math.Abs(data.Stride) * data.Height;
            byte[] bytes = new byte[byteCount];
            Marshal.Copy(data.Scan0, bytes, 0, byteCount);
            return new FCPixelBuffer {
                Width = converted.Width,
                Height = converted.Height,
                Stride = Math.Abs(data.Stride),
                Data = bytes
            };
        }
        finally
        {
            converted.UnlockBits(data);
            converted.Dispose();
        }
    }

    public static Bitmap ToBitmap(FCPixelBuffer source)
    {
        if (source == null) return null;
        Bitmap bitmap = new Bitmap(source.Width, source.Height, PixelFormat.Format32bppArgb);
        Rectangle rect = new Rectangle(0, 0, bitmap.Width, bitmap.Height);
        BitmapData data = bitmap.LockBits(rect, ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
        try
        {
            int targetStride = Math.Abs(data.Stride);
            if (targetStride == source.Stride)
            {
                Marshal.Copy(source.Data, 0, data.Scan0, Math.Min(source.Data.Length, targetStride * source.Height));
            }
            else
            {
                for (int y = 0; y < source.Height; y++)
                {
                    IntPtr row = new IntPtr(data.Scan0.ToInt64() + (long)y * targetStride);
                    Marshal.Copy(source.Data, y * source.Stride, row, Math.Min(source.Stride, targetStride));
                }
            }
        }
        finally
        {
            bitmap.UnlockBits(data);
        }
        return bitmap;
    }

    public static FCPixelBuffer Resize(FCPixelBuffer source, double scale)
    {
        if (source == null || scale <= 0.0) return null;
        int width = Math.Max(1, (int)Math.Round(source.Width * scale));
        int height = Math.Max(1, (int)Math.Round(source.Height * scale));
        if (width == source.Width && height == source.Height) return source;

        using (Bitmap original = ToBitmap(source))
        using (Bitmap resized = new Bitmap(width, height, PixelFormat.Format32bppArgb))
        {
            using (Graphics graphics = Graphics.FromImage(resized))
            {
                graphics.CompositingMode = CompositingMode.SourceCopy;
                graphics.CompositingQuality = CompositingQuality.HighQuality;
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
                graphics.SmoothingMode = SmoothingMode.HighQuality;
                graphics.DrawImage(original, new Rectangle(0, 0, width, height));
            }
            return FromBitmap(resized);
        }
    }

    private static long DifferenceAt(FCPixelBuffer screen, FCPixelBuffer template,
        int left, int top, int stepX, int stepY, long stopAt, out int sampleChannels)
    {
        long difference = 0;
        sampleChannels = 0;
        for (int ty = 0; ty < template.Height; ty += stepY)
        {
            int screenRow = (top + ty) * screen.Stride;
            int templateRow = ty * template.Stride;
            for (int tx = 0; tx < template.Width; tx += stepX)
            {
                int si = screenRow + (left + tx) * 4;
                int ti = templateRow + tx * 4;
                difference += Math.Abs(screen.Data[si] - template.Data[ti]);
                difference += Math.Abs(screen.Data[si + 1] - template.Data[ti + 1]);
                difference += Math.Abs(screen.Data[si + 2] - template.Data[ti + 2]);
                sampleChannels += 3;
                if (difference > stopAt) return difference;
            }
        }
        return difference;
    }

    public static FCTemplateResult Find(FCPixelBuffer screen, FCPixelBuffer template,
        double x1, double y1, double x2, double y2, double maximumMeanDifference)
    {
        FCTemplateResult result = new FCTemplateResult {
            Found = false,
            MeanDifference = 999.0,
            MatchWidth = template == null ? 0 : template.Width,
            MatchHeight = template == null ? 0 : template.Height
        };
        if (screen == null || template == null || template.Width > screen.Width || template.Height > screen.Height)
            return result;

        int minX = Math.Max(0, (int)Math.Floor(screen.Width * x1));
        int minY = Math.Max(0, (int)Math.Floor(screen.Height * y1));
        int maxX = Math.Min(screen.Width - template.Width, (int)Math.Ceiling(screen.Width * x2) - template.Width);
        int maxY = Math.Min(screen.Height - template.Height, (int)Math.Ceiling(screen.Height * y2) - template.Height);
        if (maxX < minX || maxY < minY) return result;

        int sampleStepX = Math.Max(2, template.Width / 12);
        int sampleStepY = Math.Max(2, template.Height / 6);
        int sampleColumns = (template.Width + sampleStepX - 1) / sampleStepX;
        int sampleRows = (template.Height + sampleStepY - 1) / sampleStepY;
        // Coarse candidates may be one pixel away from the true location.
        // Use a wider coarse allowance, then enforce the requested threshold
        // after the one-pixel refinement pass.
        long allowed = (long)Math.Ceiling(maximumMeanDifference * 2.5 * sampleColumns * sampleRows * 3.0);
        long best = allowed;
        int bestX = -1, bestY = -1;

        for (int y = minY; y <= maxY; y += 2)
        {
            for (int x = minX; x <= maxX; x += 2)
            {
                int channels;
                long value = DifferenceAt(screen, template, x, y, sampleStepX, sampleStepY, best, out channels);
                if (value < best)
                {
                    best = value;
                    bestX = x;
                    bestY = y;
                }
            }
        }

        if (bestX < 0) return result;

        int refineMinX = Math.Max(minX, bestX - 3);
        int refineMaxX = Math.Min(maxX, bestX + 3);
        int refineMinY = Math.Max(minY, bestY - 3);
        int refineMaxY = Math.Min(maxY, bestY + 3);
        for (int y = refineMinY; y <= refineMaxY; y++)
        {
            for (int x = refineMinX; x <= refineMaxX; x++)
            {
                int channels;
                long value = DifferenceAt(screen, template, x, y, sampleStepX, sampleStepY, best, out channels);
                if (value < best)
                {
                    best = value;
                    bestX = x;
                    bestY = y;
                }
            }
        }

        int finalChannels;
        long finalDifference = DifferenceAt(screen, template, bestX, bestY, 2, 2, long.MaxValue, out finalChannels);
        double finalMean = finalChannels > 0 ? finalDifference / (double)finalChannels : 999.0;
        result.Found = finalMean <= maximumMeanDifference;
        result.X = bestX;
        result.Y = bestY;
        result.MeanDifference = finalMean;
        return result;
    }

    // Compare the light S glyph, since the background changes every frame.
    public static FCTemplateResult FindForegroundGlyph(FCPixelBuffer screen, FCPixelBuffer template,
        double x1, double y1, double x2, double y2, double maximumMeanDifference)
    {
        FCTemplateResult result = new FCTemplateResult { Found = false, MeanDifference = 999.0 };
        if (screen == null || template == null || template.Width > screen.Width || template.Height > screen.Height) return result;
        List<int> offsets = new List<int>();
        for (int ty = 0; ty < template.Height; ty++)
            for (int tx = 0; tx < template.Width; tx++)
            {
                if (((tx + ty) & 1) != 0) continue;
                int ti = ty * template.Stride + tx * 4;
                if (template.Data[ti] >= 190 && template.Data[ti + 1] >= 190 && template.Data[ti + 2] >= 190)
                    offsets.Add(ty * template.Width + tx);
            }
        if (offsets.Count < 30) return result;
        int minX = Math.Max(0, (int)Math.Floor(screen.Width * x1));
        int minY = Math.Max(0, (int)Math.Floor(screen.Height * y1));
        int maxX = Math.Min(screen.Width - template.Width, (int)Math.Ceiling(screen.Width * x2) - template.Width);
        int maxY = Math.Min(screen.Height - template.Height, (int)Math.Ceiling(screen.Height * y2) - template.Height);
        long best = long.MaxValue;
        for (int y = minY; y <= maxY; y++)
            for (int x = minX; x <= maxX; x++)
            {
                long difference = 0;
                foreach (int offset in offsets)
                {
                    int ti = (offset / template.Width) * template.Stride + (offset % template.Width) * 4;
                    int si = (y + offset / template.Width) * screen.Stride + (x + offset % template.Width) * 4;
                    difference += Math.Abs(screen.Data[si] - template.Data[ti]);
                    difference += Math.Abs(screen.Data[si + 1] - template.Data[ti + 1]);
                    difference += Math.Abs(screen.Data[si + 2] - template.Data[ti + 2]);
                    if (difference >= best) break;
                }
                if (difference < best) { best = difference; result.X = x; result.Y = y; }
            }
        if (best == long.MaxValue) return result;
        result.MeanDifference = best / (double)(offsets.Count * 3);
        result.Found = result.MeanDifference <= maximumMeanDifference;
        return result;
    }

    // ESC alone also occurs in the lobby. Require the light SKIP label to its
    // right, at the bottom of the FC window, before sending any key.
    public static FCTemplateResult FindEscSkip(FCPixelBuffer screen, FCPixelBuffer template,
        double x1, double y1, double x2, double y2, double maximumMeanDifference)
    {
        FCTemplateResult result = FindForegroundGlyph(screen, template, x1, y1, x2, y2, maximumMeanDifference);
        if (!result.Found) return result;
        int firstX = result.X + template.Width + Math.Max(3, template.Width / 9);
        int lastX = Math.Min(screen.Width, firstX + Math.Max(30, template.Width * 13 / 10));
        int firstY = result.Y + Math.Max(2, template.Height / 7);
        int lastY = Math.Min(screen.Height, result.Y + template.Height - Math.Max(2, template.Height / 7));
        if (firstX >= lastX || firstY >= lastY) { result.Found = false; return result; }
        int bright = 0, total = 0;
        for (int y = firstY; y < lastY; y++)
            for (int x = firstX; x < lastX; x++)
            {
                int i = y * screen.Stride + x * 4;
                if (screen.Data[i] >= 175 && screen.Data[i + 1] >= 175 && screen.Data[i + 2] >= 175) bright++;
                total++;
            }
        result.Found = bright >= Math.Max(18, total / 10) && bright <= total / 2;
        return result;
    }

    // Sample the game area, excluding the changing prompts along the edges.
    // Repeated S prompts alone do not imply that the match is frozen.
    public static double VisualChangeFraction(FCPixelBuffer previous, FCPixelBuffer current)
    {
        if (previous == null || current == null || previous.Width != current.Width || previous.Height != current.Height)
            return 1.0;
        int changed = 0, total = 0;
        for (int y = current.Height * 15 / 100; y < current.Height * 78 / 100; y += 16)
            for (int x = current.Width * 15 / 100; x < current.Width * 82 / 100; x += 16)
            {
                int oldIndex = y * previous.Stride + x * 4;
                int newIndex = y * current.Stride + x * 4;
                int difference = Math.Abs(previous.Data[oldIndex] - current.Data[newIndex])
                    + Math.Abs(previous.Data[oldIndex + 1] - current.Data[newIndex + 1])
                    + Math.Abs(previous.Data[oldIndex + 2] - current.Data[newIndex + 2]);
                if (difference > 65) changed++;
                total++;
            }
        return total > 0 ? changed / (double)total : 0.0;
    }

    public static FCTemplateResult FindMultiScale(FCPixelBuffer screen, FCPixelBuffer template,
        double x1, double y1, double x2, double y2, double maximumMeanDifference, double[] scales, bool foregroundGlyph, bool escSkip)
    {
        FCTemplateResult best = new FCTemplateResult { Found = false, MeanDifference = 999.0 };
        if (screen == null || template == null || scales == null) return best;

        List<string> checkedSizes = new List<string>();
        foreach (double requestedScale in scales)
        {
            // High-resolution 2560 sources are intentionally reduced to
            // 1280/1600-class FC windows, so scales below 0.65 are valid.
            double scale = Math.Max(0.35, Math.Min(2.0, requestedScale));
            int width = Math.Max(1, (int)Math.Round(template.Width * scale));
            int height = Math.Max(1, (int)Math.Round(template.Height * scale));
            string sizeKey = width.ToString() + "x" + height.ToString();
            if (checkedSizes.Contains(sizeKey)) continue;
            checkedSizes.Add(sizeKey);

            FCPixelBuffer candidateTemplate = Resize(template, scale);
            FCTemplateResult candidate = escSkip
                ? FindEscSkip(screen, candidateTemplate, x1, y1, x2, y2, maximumMeanDifference)
                : foregroundGlyph
                    ? FindForegroundGlyph(screen, candidateTemplate, x1, y1, x2, y2, maximumMeanDifference)
                    : Find(screen, candidateTemplate, x1, y1, x2, y2, maximumMeanDifference);
            candidate.MatchWidth = candidateTemplate.Width;
            candidate.MatchHeight = candidateTemplate.Height;
            if (candidate.MeanDifference < best.MeanDifference) best = candidate;
            if (candidate.Found) return candidate;
        }
        return best;
    }
}

// Coordinates refer to the normalized 960 by 540 client, excluding its window frame.
public static class FCCoachVision
{
    private static double Grey(FCPixelBuffer b, int x, int y)
    {
        int p = y*b.Stride + x*4;
        return (b.Data[p]+2*b.Data[p+1]+b.Data[p+2])/4.0;
    }

    private static double Sample(FCPixelBuffer b, double x, double y)
    {
        int ix = (int)x, iy = (int)y;
        double fx = x-ix, fy = y-iy;
        return (1-fy)*((1-fx)*Grey(b,ix,iy)+fx*Grey(b,ix+1,iy))
              + fy*((1-fx)*Grey(b,ix,iy+1)+fx*Grey(b,ix+1,iy+1));
    }

    public static int SlotX(int col, int slot) { return 256 + col*238 + slot*28; }

    public static double[] Glyph(FCPixelBuffer b, int col, int slot, bool dialog)
    {
        double x = dialog ? 617.5+25*slot : SlotX(col,slot)+0.25*slot;
        double y = dialog ? 196 : 283.25;
        double w = dialog ? 15 : 18, h = dialog ? 14 : 17;
        double[] values = new double[144];
        double sum=0, energy=0;
        for (int j=0; j<12; j++) for (int i=0; i<12; i++) {
            double v = Sample(b,x+w*((i+0.5)/12-0.5),y+h*((j+0.5)/12-0.5));
            sum += v;
            values[12*j+i] = v;
        }
        for (int i=0; i<values.Length; i++) {
            values[i] -= sum/values.Length;
            energy += values[i]*values[i];
        }
        if (energy < values.Length*100) return null;
        double scale=(dialog ? -1 : 1)/Math.Sqrt(energy);
        for (int i=0; i<values.Length; i++) values[i]*=scale;
        return values;
    }


    public static bool HasTraitIcons(FCPixelBuffer b, int column)
    {
        // Count light edges against the background outside each of the three hexagons.
        // The centre can be dark or light depending on the individual trait.
        for (int slot=0; slot<3; slot++) {
            int x=SlotX(column,slot), y=283, edges=0;
            foreach (int direction in new int[] {-1,1}) {
                foreach (int offset in new int[] {-2,2}) {
                    if (Grey(b,x+offset,y+direction*9)-Grey(b,x+offset,y+direction*15)>55) edges++;
                    if (Grey(b,x+direction*9,y+offset)-Grey(b,x+direction*14,y+offset)>55) edges++;
                }
            }
            if (edges<3 || Glyph(b,column,slot,false)==null) return false;
        }
        return true;
    }

    public static bool SameCard(FCPixelBuffer original, FCPixelBuffer live, int col, bool dialog)
    {
        for (int i=0; i<3; i++) {
            double[] a=Glyph(original,col,i,false), b=Glyph(live,col,i,dialog);
            if (a==null || b==null) return false;
            double score=0;
            for (int k=0;k<a.Length;k++) score+=a[k]*b[k];
            if (score < (dialog ? 0.72 : 0.86)) return false;
        }
        return true;
    }

    // Trim the surrounding transparent (or solid) field before sampling the glyph.
    public static double[] Reference(FCPixelBuffer source)
    {
        int w=source.Width, h=source.Height;
        if (w<12 || h<12 || w>512 || h>512) return null;
        int x0=w, y0=h, x1=-1, y1=-1;
        int bg=source.Data[3], matte=255;
        if (bg<32) {
            double light=0; int count=0;
            for (int y=0;y<h;y++) for (int x=0;x<w;x++) {
                if (source.Data[y*source.Stride+x*4+3]>128) { light+=Grey(source,x,y); count++; }
            }
            if (count>0 && light/count>128) matte=0;
        }
        FCPixelBuffer flat=new FCPixelBuffer { Width=w, Height=h, Stride=w*4, Data=new byte[w*h*4] };
        for (int y=0;y<h;y++) for (int x=0;x<w;x++) {
            int i=y*source.Stride+4*x, o=4*(y*w+x), alpha=source.Data[i+3];
            bool ink=bg<32 ? alpha>96 : alpha>96 && Math.Abs(Grey(source,x,y)-Grey(source,0,0))>24;
            if (ink) { x0=Math.Min(x0,x); x1=Math.Max(x1,x); y0=Math.Min(y0,y); y1=Math.Max(y1,y); }
            for (int c=0;c<3;c++) flat.Data[o+c]=(byte)((source.Data[i+c]*alpha+matte*(255-alpha))/255);
        }
        if (x1-x0<10 || y1-y0<10) return null;
        double[] values=new double[144];
        double sum=0, energy=0;
        for (int j=0;j<12;j++) for (int i=0;i<12;i++) {
            double x=(x0+x1)*0.5+(x1-x0+1)*0.76*((i+0.5)/12-0.5);
            double y=(y0+y1)*0.5+(y1-y0+1)*0.63*((j+0.5)/12-0.5);
            double v=Sample(flat,x,y);
            sum+=v; values[j*12+i]=v;
        }
        for (int i=0;i<values.Length;i++) { values[i]-=sum/values.Length; energy+=values[i]*values[i]; }
        if (energy<values.Length*64) return null;
        double length=Math.Sqrt(energy);
        for (int i=0;i<values.Length;i++) values[i]/=length;
        return values;
    }

    public static int Identify(FCPixelBuffer frame, int column, int slot, Dictionary<int,double[]> catalog)
    {
        double[] glyph=Glyph(frame,column,slot,false);
        if (glyph==null) return -1;
        int id=-1; double best=0, second=0;
        foreach (KeyValuePair<int,double[]> entry in catalog) {
            double score=0;
            for (int i=0;i<glyph.Length;i++) score+=glyph[i]*entry.Value[i];
            score=Math.Abs(score); // The CDN and in-game views can use opposite colours.
            if (score>best) { second=best; best=score; id=entry.Key; }
            else if (score>second) second=score;
        }
        return best>=0.78 && best-second>=0.055 ? id : -1;
    }

}

public static class FCScoreReader
{
    private const int NormalWidth = 28;
    private const int NormalHeight = 56;
    private static readonly string[] EncodedTemplates = new string[] {
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH//4A///wH/n/gf4H+D/AP8P8A/w/gB/D+AH8P4Afw/gB/D+AH8P4Afw/gB/H+AH+f4Af5/gB/n+AH+f4Af5/gB/n+AH+f4Af5/gB/n+AH+f4Af4/gB/D+AH8P4Afw/gB/D+AH8P4Afw/wD/D/gP8H+B/gf+f+A///wB//+AH//4Af//gAf/4AB//gAAfgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
        "AAAAAAA/+AAH/4AA//gAf/+B///4H///gf//+B///4H///gf//+B///4H///gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAAAAA==",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP//8B///4P///w/8P/D/AP8P8A/w/gB/j+AH+P4Af5/gB/n+AH+P4Af4AAD/AAAP8AAA/wAAH/AAA/8AAH/gAAf+AAH/gAA/+AAH/4AA/+AAH/4AB/8AAH/wAA/+AAH/gAAf+AAD/gAAf+AAD/wAAP8AAA////j///+P///5////n///+f///5////n///+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAD///Af//+D/5/4P+D/w/wD/D/AP8P4A/w/gD/D+AP8PwA/wAAD/AAAP8AAB/gAAP+AAB/wAB/+AAH/wAAf/gAB//AAH/8AAf/8AAf/wAAP/AAAP+AAA/4AAB/gAAH+fwAf5/AB/n8AH+f4Af5/gD/j+AP8P8A/w/4H/D/5/8P///gf//8A///wB//+AD//wAH/+AAD/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/gAB/+AAH/4AA//gAH/+AAfv4AB8/gAHz+AA/P4AH4/gAfj+AB8P4APw/gB+D+AH4P4AfA/gD4D+APgP4B+A/gP4D+A/AP4D4B/gfgH+B////n///+f///5////n///+f///5////gAB/gAAH+AAAf4AAB/gAAH+AAAf4AAB/gAAH+AAAf4AAB/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAD///wP///A///8D///wPwAAA/AAAD8AAAfwAAB/AAAH8AAAfgAAB+HwAH7/4Af//4D///gP///A///+D///8P/n/w/wP/D/AP8H4A/4AAD/gAAH+AAAf4AAB/gAAH+AAAf4AAB/n+AH+f4Af5/gD/H/AP8P8A/w/4P/D/5/8H///gf//8A///gB//8AD//gAH/+AAD+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAB///gP///A/5/8H/A/wf4D/D/AP8P8Afw/wAAD/AAAP4AAA/gAAD+AAAf5/4B/v/wH+//gf///B///+H///8f///x/+f/H/AP8f8A/5/wB/n+AH+f4Af5/gA/j+AD+P4AP4/gA/j+AD+P4Af4/wB/j/AP8P8A/wf8H/B/5/8D///gH//8Af//wA//+AB//wAD/+AAB/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH///+f///5////n///+AAAfwAAD+AAAfwAAD+AAAP4AAB/gAAH8AAA/gAAD+AAAf4AAB/AAAP4AAA/gAAD+AAAfwAAB/AAAP4AAB/gAAH8AAAfwAAB/AAAP8AAA/wAAD/AAAf4AAB/gAAH+AAAfwAAB/AAAH8AAAfwAAB/AAAP8AAA/wAAD/AAAP8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP//8B///4H/n/g/4H/D/AP8P8A/w/gB/D+AH8P4Afw/gD/D/AP4H+B/gf8P8A///gB//+AD//gAP//AB///AP//+B///8P/D/w/4H/D+AP8P4Af5/gB/n+AH+f4Af5/gB/n+AH+f4Af4/gB/D/AP8P+B/w/+f/D///4D///AP//4Af//gA//4AB//gAA/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP//4B///wP///A/wH+D/AP4P4A/w/gB/H+AH8f4Afx/gB/H+AH8f4Afx/gB/H+AH8f4Af4/gD/j/Af+P/H/4////h///+D///4H///gf//8Af/fwAfx/AAAH8AAAfwAAB/AAAH8P4A/w/gD+D/Af4P8D/A/8/8B///gD//+AH//wAf/+AA//wAB/+AAA/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=="
    };
    private static readonly bool[][] Templates = DecodeTemplates();

    private static bool[][] DecodeTemplates()
    {
        bool[][] result = new bool[10][];
        for (int d = 0; d < 10; d++)
        {
            byte[] packed = Convert.FromBase64String(EncodedTemplates[d]);
            result[d] = new bool[NormalWidth * NormalHeight];
            for (int i = 0; i < result[d].Length; i++)
                result[d][i] = (packed[i / 8] & (1 << (7 - (i % 8)))) != 0;
        }
        return result;
    }

    private sealed class DigitResult
    {
        public bool Found;
        public int Digit;
        public double Difference;
        public double Gap;
        public string Reason;
    }

    private static DigitResult ReadDigit(FCPixelBuffer screen, double x1, double x2)
    {
        int left = Math.Max(0, (int)(screen.Width * x1));
        int right = Math.Min(screen.Width, (int)(screen.Width * x2));
        int top = Math.Max(0, (int)(screen.Height * 0.11));
        int bottom = Math.Min(screen.Height, (int)(screen.Height * 0.26));
        int width = right - left;
        int height = bottom - top;
        if (width <= 0 || height <= 0)
            return new DigitResult { Found = false, Reason = "점수 영역 없음" };

        int maximum = 0;
        for (int y = top; y < bottom; y++)
        {
            int row = y * screen.Stride;
            for (int x = left; x < right; x++)
            {
                int i = row + x * 4;
                int b = screen.Data[i], g = screen.Data[i + 1], r = screen.Data[i + 2];
                int lum = (r + g + b) / 3;
                if (lum > maximum) maximum = lum;
            }
        }
        if (maximum < 55)
            return new DigitResult { Found = false, Reason = "점수 표시 전환 중" };

        int threshold = Math.Max(38, (int)(maximum * 0.62));
        bool[] mask = new bool[width * height];
        for (int y = 0; y < height; y++)
        {
            int row = (top + y) * screen.Stride;
            for (int x = 0; x < width; x++)
            {
                int i = row + (left + x) * 4;
                int b = screen.Data[i], g = screen.Data[i + 1], r = screen.Data[i + 2];
                int lum = (r + g + b) / 3;
                int hi = Math.Max(r, Math.Max(g, b));
                int lo = Math.Min(r, Math.Min(g, b));
                mask[y * width + x] = lum > threshold && (hi - lo) < 50;
            }
        }

        bool[] visited = new bool[mask.Length];
        List<int> bestPixels = null;
        double bestComponentScore = -1;
        int[] queue = new int[mask.Length];
        int minimumHeight = Math.Max(35, (int)(screen.Height * 0.055));
        int maximumHeight = Math.Max(minimumHeight, (int)(screen.Height * 0.12));
        int minimumWidth = Math.Max(8, (int)(screen.Width * 0.008));
        int maximumWidth = Math.Max(minimumWidth, (int)(screen.Width * 0.06));

        for (int start = 0; start < mask.Length; start++)
        {
            if (!mask[start] || visited[start]) continue;
            int head = 0, tail = 0;
            queue[tail++] = start;
            visited[start] = true;
            List<int> pixels = new List<int>();
            int minX = width, maxX = 0, minY = height, maxY = 0;
            while (head < tail)
            {
                int p = queue[head++];
                pixels.Add(p);
                int px = p % width, py = p / width;
                if (px < minX) minX = px; if (px > maxX) maxX = px;
                if (py < minY) minY = py; if (py > maxY) maxY = py;
                int next;
                if (px > 0) { next = p - 1; if (mask[next] && !visited[next]) { visited[next] = true; queue[tail++] = next; } }
                if (px + 1 < width) { next = p + 1; if (mask[next] && !visited[next]) { visited[next] = true; queue[tail++] = next; } }
                if (py > 0) { next = p - width; if (mask[next] && !visited[next]) { visited[next] = true; queue[tail++] = next; } }
                if (py + 1 < height) { next = p + width; if (mask[next] && !visited[next]) { visited[next] = true; queue[tail++] = next; } }
            }

            int componentWidth = maxX - minX + 1;
            int componentHeight = maxY - minY + 1;
            if (pixels.Count < 80 || componentHeight < minimumHeight || componentHeight > maximumHeight ||
                componentWidth < minimumWidth || componentWidth > maximumWidth) continue;
            double componentScore = componentHeight * 10.0 + pixels.Count;
            if (componentScore > bestComponentScore)
            {
                bestComponentScore = componentScore;
                bestPixels = pixels;
            }
        }

        if (bestPixels == null)
            return new DigitResult { Found = false, Reason = "점수 숫자 없음" };

        int bx0 = width, bx1 = 0, by0 = height, by1 = 0;
        bool[] componentMask = new bool[mask.Length];
        foreach (int p in bestPixels)
        {
            componentMask[p] = true;
            int px = p % width, py = p / width;
            if (px < bx0) bx0 = px; if (px > bx1) bx1 = px;
            if (py < by0) by0 = py; if (py > by1) by1 = py;
        }
        int bw = bx1 - bx0 + 1, bh = by1 - by0 + 1;
        double scale = Math.Min((NormalWidth - 2.0) / bw, (NormalHeight - 2.0) / bh);
        int scaledWidth = Math.Max(1, (int)Math.Round(bw * scale));
        int scaledHeight = Math.Max(1, (int)Math.Round(bh * scale));
        int offsetX = (NormalWidth - scaledWidth) / 2;
        int offsetY = (NormalHeight - scaledHeight) / 2;
        bool[] normalized = new bool[NormalWidth * NormalHeight];
        for (int y = 0; y < scaledHeight; y++)
        {
            int sourceY = Math.Min(bh - 1, (int)((double)y * bh / scaledHeight));
            for (int x = 0; x < scaledWidth; x++)
            {
                int sourceX = Math.Min(bw - 1, (int)((double)x * bw / scaledWidth));
                normalized[(offsetY + y) * NormalWidth + offsetX + x] = componentMask[(by0 + sourceY) * width + bx0 + sourceX];
            }
        }

        int bestDigit = -1;
        double bestDifference = 1.0, secondDifference = 1.0;
        for (int digit = 0; digit < 10; digit++)
        {
            int mismatch = 0;
            for (int i = 0; i < normalized.Length; i++)
                if (normalized[i] != Templates[digit][i]) mismatch++;
            if (digit == 3) {
                byte[] variant = Convert.FromBase64String("AAAAAAAAAAAAAAAAAAAAH+AAB/8AAP/8AD//8Af//4B///gP//+A/9/8H/A/4f4D/j/gP+P8Af4/wB/h/AH+AAAf4AAB/gAAH8AAA/wAAD/AAAf4AAH/gAf/8AB//AAH/8AAf/8AB//4AH//gAAH/AAAf8AAAf4AAB/gAAD+AAAP4AAA/gAAD+f4AP5/gA/n+AD+P8Af4/4D/h/4/+H///wP///A///4B///gD//4AD/+AAH/wAAAAAAAAAAAAAAAAAAAA==");
                int variantMismatch = 0;
                for (int i = 0; i < normalized.Length; i++)
                    if (normalized[i] != ((variant[i/8] & (1 << (7-i%8))) != 0)) variantMismatch++;
                // This tightly matched variant may only resolve the observed
                // three glyph; it must not steal a moderately similar two.
                if (variantMismatch <= normalized.Length * 0.08)
                    mismatch = Math.Min(mismatch, variantMismatch);
            }
            if (digit == 6) {
                byte[] variant = Convert.FromBase64String("AAAAAAAAAAAAAAAAAAAAAAAAAfwAAH/wAA//wAP//gA///AH//+A///4D/h/wP8D/h/gP+H+AP4/wA/j/AD4P8AIA/gAAD+AAAP4AAB/gAAH+AwAf4f8B/j/4H+f/wf7//h///+H/4f8f/A/x/4B/n/AH+f8AP5/gA/n+AD+P4AP4/gA/j+AD+P8AP4/wB/h/AH+H+A/4P8D/g/4/8D///gH//+AP//wA//+AAf/gAAf8AAAAAAAAAAAAAAAAAAAAAAAAA==");
                int variantMismatch=0;
                for(int i=0;i<normalized.Length;i++)
                    if(normalized[i]!=((variant[i/8]&(1<<(7-i%8)))!=0)) variantMismatch++;
                if(variantMismatch<=normalized.Length*0.08) mismatch=Math.Min(mismatch,variantMismatch);
            }
            double difference = mismatch / (double)normalized.Length;
            if (difference < bestDifference)
            {
                secondDifference = bestDifference;
                bestDifference = difference;
                bestDigit = digit;
            }
            else if (difference < secondDifference)
            {
                secondDifference = difference;
            }
        }

        double gap = secondDifference - bestDifference;
        bool accepted = bestDifference <= 0.31 && gap >= 0.025;
        return new DigitResult {
            Found = accepted,
            Digit = bestDigit,
            Difference = bestDifference,
            Gap = gap,
            Reason = accepted ? "확인" : "숫자 신뢰도 부족"
        };
    }

    public static FCScoreResult Read(FCPixelBuffer screen)
    {
        if (screen == null)
            return new FCScoreResult { Found = false, Reason = "화면 없음" };
        DigitResult left = ReadDigit(screen, 0.40, 0.50);
        DigitResult right = ReadDigit(screen, 0.50, 0.59);
        if (!left.Found || !right.Found)
            return new FCScoreResult { Found = false, Reason = left.Found ? right.Reason : left.Reason };
        double confidence = 1.0 - Math.Max(left.Difference, right.Difference);
        return new FCScoreResult {
            Found = true,
            LeftScore = left.Digit,
            RightScore = right.Digit,
            Confidence = confidence,
            Reason = "확인"
        };
    }
}

public sealed class FCRankPointResult
{
    public bool Found;
    public int Delta;
    public double Confidence;
    public string Reason;
}


public static class FCRewardLabels
{
    public static bool Matches(FCPixelBuffer original, int x, int y, int width, int height, string encoded)
    {
        if (original == null) return false;
        FCPixelBuffer f = original.Width == 1296 ? original : FCTemplateMatcher.Resize(original, 1296.0 / original.Width);
        if (f.Width < x + width || f.Height < y + height) return false;
        byte[] sample = Convert.FromBase64String(encoded);
        int foreground = 0, missing = 0, extra = 0;
        for (int i = 0; i < width * height; i++) {
            bool expected = (sample[i / 8] & (1 << (i % 8))) != 0;
            int at = (y + i / width) * f.Stride + (x + i % width) * 4;
            bool actual = f.Data[at] >= 140 && f.Data[at+1] >= 140 && f.Data[at+2] >= 140;
            if (expected) { foreground++; if (!actual) missing++; }
            else if (actual) extra++;
        }
        return foreground >= 40 && missing <= foreground * 0.12 && extra <= foreground * 0.35;
    }
    public static bool IsLeague(FCPixelBuffer f) { return Matches(f,513,324,62,18,"AAAAAAAAAAAAAAAAAAAAAKoBQAAAAAAAQAAQIIAPAAAQEASYAAIAAAQEAQCAAAAAAEJAACAAAAAIEYgDBAD4PwCEAAAAAAAAAAAAIAAAAAAAAAAEAEAAABAAQAAAEBAABAEBAAAEAAABAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="); }
    public static bool IsRank(FCPixelBuffer f) { return Matches(f,513,324,62,18,"AAAAAAAAAAAAAAAAAAAAAAABAABB8A8AQQAAABAAAEAQIAAABAAAEAQEAAABAAAIASAAQAAAQEQAAOAQAAAIAAAAEAQAAAAAAAAEAQAAAAAAAAAAAABAAAAAAAACABAAAAAEAAAABAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="); }
    public static bool IsTierResult(FCPixelBuffer f) { return Matches(f,698,306,56,18,"AAAAAAAAAPAQAMFHAAKAGRgBfkACgBgIAUJAAkAYCAFhQAJgHgjBQEAGGBgIAQBIBgAABIF/CALABwMBQAgCIIgBgX/+AiAYAIEAAAJADACBAQACAAAAAAAAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"); }
    public static bool IsTierPopup(FCPixelBuffer original) {
        if (original == null) return false;
        FCPixelBuffer f = original.Width == 1296 ? original : FCTemplateMatcher.Resize(original,1296.0/original.Width);
        if (f.Height < 620) return false;
        int[] xs = {420,870,420,870}; int[] ys = {170,170,550,550};
        for(int k=0;k<4;k++) { int i=ys[k]*f.Stride+xs[k]*4;
            if(f.Data[i]<235 || f.Data[i+1]<235 || f.Data[i+2]<235) return false; }
        return true;
    }
}


public static class FCContextScreens
{
    public static FCPixelBuffer NormalizeGreen(FCPixelBuffer f) {
        FCPixelBuffer result = new FCPixelBuffer { Width=f.Width, Height=f.Height, Stride=f.Stride, Data=(byte[])f.Data.Clone() };
        // Hover/pressed buttons use a darker green. Preserve the black text,
        // check mark and edges, but compare the green fill at one brightness.
        for(int y=0;y<f.Height;y++) for(int x=0;x<f.Width;x++) {
            int i=y*f.Stride+x*4;int b=f.Data[i],g=f.Data[i+1],r=f.Data[i+2];
            if(g>=80 && g-r>50 && g-b>40) {result.Data[i]=80;result.Data[i+1]=220;result.Data[i+2]=0;}
        }
        return result;
    }
    public static bool IsReward(FCPixelBuffer original) {
        if (original == null) return false;
        FCPixelBuffer f = original.Width == 1296 ? original : FCTemplateMatcher.Resize(original,1296.0/original.Width);
        if (f.Width < 1296 || f.Height < 749) return false;
        int[] xs={480,640,180,380}; int[] ys={240,240,320,350};
        for(int k=0;k<4;k++){int i=ys[k]*f.Stride+xs[k]*4;
            if(f.Data[i]<225 || f.Data[i+1]<225 || f.Data[i+2]<225) return false;}
        return true;
    }
    public static bool IsLevelUp(FCPixelBuffer f) { return FCRewardLabels.Matches(f,622,232,74,17,"AAAAAAAAAAAAAAAAAAAAAAAAAEAAACAADyACAAAgAIAAIIAPAACAAAEEgACiAAAQAgQAABKIAABACAACAkHgAwAAQQAAAAAAAACAAAAAAAAAAAAAAAAACEAAABAAAAAAIAAAAEAAAAAAgAAAAAIAAAACAAIAAAgAAAAAAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="); }
    public static bool IsNetworkError(FCPixelBuffer original) {
        if(original==null) return false;
        FCPixelBuffer f=original.Width==1296?original:FCTemplateMatcher.Resize(original,1296.0/original.Width);
        if(f.Height<490) return false;
        int[] xs={450,840,450,840};int[] ys={300,300,420,420};
        for(int k=0;k<4;k++){int i=ys[k]*f.Stride+xs[k]*4;
            if(f.Data[i]<235 || f.Data[i+1]<235 || f.Data[i+2]<235) return false;}
        string[] knownBodies = { "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPMZYBAEMIAhBiAABhAYAwgMAMA/gHgGMMAA/POfZ/DHM79xxjN45hN+8w0//ME/jvhmMN8A5oOfbfBnNsz95z9sxhk8k49hAME/m8BuMMMAZsPfbPBndtxxZjbMxh08k4lg/ME/kWBuMMMA5nPebPhvNr75fibE5hNmk49hDOD/sTtmMMMD/DPYbPjPM7OZbj7Mdhd+940//OF/kRlmMMMBAOOfbPAHMCCYZj5sBhA8Awge/ME/mxBmNMMACAOYZwCGMPz4xiN4xhBYYwgAIAAwn/DnP/8ACOAfY/CHAIRxhiEwxgD/Y8D//sM/hPAHMMAA+OMfYPCHP/wBBiAAxh8A489//sM/gPAHMMAM+OMfQPCHP/gABiAAxh8A4Q8AAMA/gPAHMMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYOAPYIgEaGSBACCAAAAAAAAAAAAAAAAAAAAA+OGPb9iEeX/BYSCfAAAAAAAAAAAAAAAAAAAADOMPbvicee7xYyCDAAAAAAAAAAAAAAAAAAAABOMPZNjMef85biCDAAAAAAAAAAAAAAAAAAAADOMP5vjEf3sBYCCDAwAAAAAAAAAAAAAAAAAA/OEP5vBmfm/9byCDAQAAAAAAAAAAAAAAAAAAYPAfY/AHKEARZDzDAAAAAAAAAAAAAAAAAAAAYPDfYQAGP8zw5z//AAAAAAAAAAAAAAAAAAAA/kfGYPCHcczxByCAAAAAAAAAAAAAAAAAAAAA/kMGYPCHO/7zByCACAAAAAAAAAAAAAAAAAAAAEAGYPAHHzLwByCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYOAPYIgEeGSBACCAAAAAAAAAAAAAAAAAAAAA+OGPb9iEeX/BYSCfAAAAAAAAAAAAAAAAAAAADOMPbvicee7xZyCDAAAAAAAAAAAAAAAAAAAABOMHZNjMef85biCDAAAAAAAAAAAAAAAAAAAADOMP5vjEf3sBYCCDAwAAAAAAAAAAAAAAAAAA/OEP5vBmfm/9byCDAQAAAAAAAAAAAAAAAAAAYPgfY/AHKEARZDzDAAAAAAAAAAAAAAAAAAAAYPDfYQAGP8zw5z//AAAAAAAAAAAAAAAAAAAA/kfGYPCHcczxByCAAAAAAAAAAAAAAAAAAAAA/kMGYPCHP/7zByCACAAAAAAAAAAAAAAAAAAAAEAGYPAHHiLwByCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPMZYBAEMIBhBiCAAOABgDEA+AdnAGMef8CC/POfZ/DHM7/9ZyCfAOH5xzP/+Md/PGOef8ji5oOfbfBnNszxbiCDAOEZYDbA+INvZvMfHMgyZsPfbPBndtz5fiCDAPn54zfA+IftZ2MeP+gy5nPebPhvNr6ZZiCDA/kZwDP/+IfvZvOec/gi/DPYbPjPM7P5ZiCDAeH54z/A/A9nPJOfQNziAOOfbPAHMCAQZDzDAOH55zPA+Md/AJPf//5iCAOYZwCGMPzw5z//AP8BgD1A+AcACPMeDPZiCOAfY/CHAITxByCAAOD9j73/+Yd/CGAeDMLy+OMfYPCHP/zxByCACOD9hzH/+Qdg+AMeDMDy+OMfQPCHP/jwByCAAIABADAA+Adg+AMQDAACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" };
        foreach(string encoded in knownBodies) {
            byte[] mask=Convert.FromBase64String(encoded);
            int ink=0,missing=0,extra=0;
            for(int i=0;i<216*16;i++) {
                bool expected=(mask[i/8]&(1<<(i%8)))!=0;
                int at=(367+i/216)*f.Stride+(495+i%216)*4;
                bool actual=Math.Min(f.Data[at],Math.Min(f.Data[at+1],f.Data[at+2]))<180;
                if(expected){ink++;if(!actual)missing++;}else if(actual)extra++;
            }
            if(ink>=80 && missing<=ink*0.12 && extra<=ink*0.35) return true;
        }
        return false;
    }
}

public static class FCRankPointsReader
{
    // 20x12 binary digits sampled from the user's reward screens. They carry
    // digit shapes only; no screenshots, account names or game identifiers.
    private static readonly string[] Samples = new string[] {
        "0:MMAP/vEch3M4gzM4gzMwgzM4gzM4h3M4zuEffAAA,OMAP/vEchzM4gzM4gzM4gzM4gzM4g3M4z+EffAAA",
        "1:GMABH/ABGIABGIABGIABGIABGIABGIABGIABAAAA,DMAAD/AADMAADMAADMAADMAADMAADMAADMAAAAAA",
        "2:MMAP/nEchwEYgAEcwAEO4AAHOMABHOAAD/A//wMA,MOAP/nEcgwEYgAEcwAEO4AAHOMABHuAAB/Af/wEA",
        "3:OOAP/nEchwEYgAEc4IAH+AAcgAE4gjM4x+EffAAA,GOAH/nEcgwEYgAEc4IAH+AAcgAEYgjEYx+EffAAA",
        "4:wAEc4AEe8IEbmMEYjGEYhnEY//d/gAEYgAEYAAAA,gAEc4AEe8AEbmIEZjOEYhnE4//d/gAEYgAEYAAAA",
        "5:/uEfBmAABmAAduAPzmE4gAM4gCM4h3Mc/sEPAAAA,/uEfBmAABmAAdvAPx2EYgAE4gCM4g3Ec/sEHAAAA",
        "6:MMAP/nE4hzMAAzAAY7Afx3E4gzMwA3M4xuEf/AAA,MMAP/nE4hzMAAzAAY7Afx3E4gzMwA3M4xuEf/AAA,MMAP/nEcgzEAAzAAc7APxzEYgzM4gzMYx+Ef/AAA",
        "7://M/gAMYwAEM4AAGcAADMIADOIABHMABHMAAAAAA,//M/gAMYwAEM4AAGYAAHMIADOIABHMABHMAAAAAA",
        "8:MMAP7nEch3M4h2EYzsAP/nEYgzM4gzM4x+Ef/AAA,MMAP/nEch3M4h2EYzsAP/nEYgzM4g3M4x+Mf/AAA",
        "9:OOAP/nEcgzM4gzM4h3M8voM4gAM4gDM4x+EffAAA,OMAP/nEcgzM4gzM4h2M8vgMwgAM4gDM4x+EffAAA"
    };

    private static bool Bright(FCPixelBuffer frame, int x, int y)
    {
        int index = y * frame.Stride + x * 4;
        return frame.Data[index] >= 140 && frame.Data[index + 1] >= 140 && frame.Data[index + 2] >= 140;
    }

    private static int Distance(bool[] pixels, byte[] pattern)
    {
        int difference = 0;
        for (int bit = 0; bit < 240; bit++)
            if (pixels[bit] != ((pattern[bit / 8] & (1 << (bit % 8))) != 0)) difference++;
        return difference;
    }

    public static FCRankPointResult Read(FCPixelBuffer original)
    {
        FCRankPointResult result = new FCRankPointResult { Found = false, Reason = "보상 화면 확인 실패" };
        if (original == null || original.Width < 1000 || original.Height < 650) return result;
        FCPixelBuffer frame = original.Width == 1296 ? original : FCTemplateMatcher.Resize(original, 1296.0 / original.Width);
        if (frame.Width < 1296 || frame.Height < 749) return result;

        // This white tab appears on the settled reward panel, not the ranking
        // lobby. Requiring it prevents interpreting a lobby score as a delta.
        if (!Bright(frame, 499, 240) || !Bright(frame, 530, 240) || !Bright(frame, 600, 240)) return result;

        if (FCRewardLabels.IsLeague(frame)) { result.Reason = "등급 승점 화면"; return result; }
        if (!FCRewardLabels.IsRank(frame)) { result.Reason = "랭킹 점수 항목 확인 실패"; return result; }

        const int left = 974, top = 317, width = 55, height = 31;
        bool[] seen = new bool[width * height];
        System.Collections.Generic.List<System.Tuple<int, bool[]>> glyphs =
            new System.Collections.Generic.List<System.Tuple<int, bool[]>>();
        for (int y = 0; y < height; y++) for (int x = 0; x < width; x++)
        {
            int start = y * width + x;
            if (seen[start] || !Bright(frame, left + x, top + y)) continue;
            int[] queue = new int[width * height];
            int count = 1; queue[0] = start; seen[start] = true;
            int minX = x, maxX = x, minY = y, maxY = y;
            for (int head = 0; head < count; head++)
            {
                int at = queue[head], cx = at % width, cy = at / width;
                minX = Math.Min(minX, cx); maxX = Math.Max(maxX, cx);
                minY = Math.Min(minY, cy); maxY = Math.Max(maxY, cy);
                for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++)
                {
                    int nx = cx + dx, ny = cy + dy;
                    if (nx < 0 || nx >= width || ny < 0 || ny >= height) continue;
                    int next = ny * width + nx;
                    if (seen[next] || !Bright(frame, left + nx, top + ny)) continue;
                    seen[next] = true; queue[count++] = next;
                }
            }
            int gw = maxX - minX + 1, gh = maxY - minY + 1;
            if (count < 18 || gh < 13 || gh > 20 || gw > 12) continue;
            if (left + minX < 994 || left + minX > 1016) continue;
            bool[] bits = new bool[240];
            for (int k = 0; k < count; k++)
            {
                int cx = queue[k] % width - minX, cy = queue[k] / width - minY;
                bits[cy * 12 + cx] = true;
            }
            glyphs.Add(System.Tuple.Create(left + minX, bits));
        }
        glyphs.Sort((a, b) => a.Item1.CompareTo(b.Item1));
        if (glyphs.Count < 1 || glyphs.Count > 2) { result.Reason = "보상 점수 숫자 수 불일치"; return result; }
        int signPixels = 0;
        for (int y = 329; y < 340; y++) for (int x = 984; x < 994; x++)
            if (Bright(frame, x, y)) signPixels++;
        if (signPixels > 2 && signPixels < 8) { result.Reason = "부호 신뢰도 부족"; return result; }
        int number = 0, worstDistance = 0, smallestGap = 240;
        foreach (var glyph in glyphs)
        {
            int best = 241, nextBest = 241, digit = -1;
            foreach (string line in Samples)
            {
                int colon = line.IndexOf(':'); int candidate = line[0] - '0';
                int distance = 241;
                foreach (string encoded in line.Substring(colon + 1).Split(','))
                    distance = Math.Min(distance, Distance(glyph.Item2, Convert.FromBase64String(encoded)));
                if (distance < best) { nextBest = best; best = distance; digit = candidate; }
                else if (distance < nextBest) nextBest = distance;
            }
            worstDistance = Math.Max(worstDistance, best);
            smallestGap = Math.Min(smallestGap, nextBest - best);
            if (best > 12 || nextBest - best < 5) { result.Reason = "숫자 모양 신뢰도 부족"; return result; }
            number = number * 10 + digit;
        }
        result.Found = true;
        result.Delta = signPixels >= 8 ? -number : number;
        result.Confidence = 1.0 - worstDistance / 240.0;
        result.Reason = "확인";
        return result;
    }
}
"@

[System.Windows.Forms.Application]::EnableVisualStyles()

# When this file is loaded through the UTF-8 launcher it runs as an in-memory
# script block, so PSScriptRoot can be empty on Windows PowerShell 5.1.
$script:appDir = if ([string]::IsNullOrWhiteSpace($PSScriptRoot)) {
    (Get-Location).Path
} else {
    $PSScriptRoot
}
. (Join-Path $script:appDir 'UpdateManager.ps1')
$script:updateInstalling=$false

$script:diagnosticDir = Join-Path $script:appDir "오류확인용_보내기"
$script:logDir = Join-Path $script:diagnosticDir "logs"
$script:captureDir = Join-Path $script:diagnosticDir "captures"
$script:resultSampleDir = Join-Path $script:diagnosticDir "result_samples"
$script:pointSampleDir = Join-Path $script:diagnosticDir "point_samples"
$script:pointSampleFullDir = Join-Path $script:pointSampleDir "full"
$script:pointSampleRoiDir = Join-Path $script:pointSampleDir "score_area"
[IO.Directory]::CreateDirectory($script:diagnosticDir) | Out-Null
[IO.Directory]::CreateDirectory($script:logDir) | Out-Null
[IO.Directory]::CreateDirectory($script:captureDir) | Out-Null
[IO.Directory]::CreateDirectory($script:resultSampleDir) | Out-Null
[IO.Directory]::CreateDirectory($script:pointSampleDir) | Out-Null
[IO.Directory]::CreateDirectory($script:pointSampleFullDir) | Out-Null
[IO.Directory]::CreateDirectory($script:pointSampleRoiDir) | Out-Null
$script:logPath = Join-Path $script:logDir ("FCManager_{0}.log" -f (Get-Date -Format "yyyyMMdd"))
$script:templateDir = Join-Path $script:appDir "templates"
$script:hdTemplateDir = Join-Path $script:appDir "templates_2560"
$script:settingsPath = Join-Path $script:appDir "settings.json"
$script:statsPath = Join-Path $script:appDir "stats.json"

$script:running = $false
$script:paused = $false
$script:gamePresence = @{}
$script:nextClientPoll = [DateTime]::MinValue
$script:clientInputBlocked = $false
$script:actionCount = 0
$script:pauseCount = 0
$script:nextScanDue = [DateTime]::Now
$script:resumeStableSince = $null
$script:f9WasDown = $false
$script:f8WasDown = $false
$script:f8HotkeyActive = $false
$script:f8HotkeyId = 0xFC08
$script:f12WasDown = $false
$script:lastTemplateActions = @{}
$script:lastRecognitionLogAt = [DateTime]::MinValue
$script:templates = New-Object System.Collections.ArrayList
$script:hdTemplates = New-Object System.Collections.ArrayList
$script:lastRecognizedFile = ""
$script:sameScreenActionCount = 0
$script:sameScreenSince = [DateTime]::Now
$script:lastProgressAt = [DateTime]::Now
$script:stuckAlertActive = $false
$script:lastStuckAlertAt = [DateTime]::MinValue
$script:previousVisualFrame = $null
$script:lastVisualChangeAt = [DateTime]::Now
$script:notificationQueue = New-Object System.Collections.Queue
$script:activeNotification = $null
$script:httpClient = New-Object System.Net.Http.HttpClient
$script:httpClient.Timeout = [TimeSpan]::FromSeconds(10)
$script:discordEnabled = $false
$script:encryptedWebhook = ""
$script:sessionMatchCount = 0
$script:todayMatchCount = 0
$script:totalMatchCount = 0
$script:sessionWinCount = 0
$script:sessionDrawCount = 0
$script:sessionLossCount = 0
$script:sessionUnclassifiedCount = 0
$script:todayWinCount = 0
$script:todayDrawCount = 0
$script:todayLossCount = 0
$script:todayUnclassifiedCount = 0
$script:totalWinCount = 0
$script:totalDrawCount = 0
$script:totalLossCount = 0
$script:totalUnclassifiedCount = 0
$script:statsDate = Get-Date -Format "yyyy-MM-dd"
$script:resultScreenCounted = $false
$script:stopAfterCurrentMatch = $false
$script:requiredStopAfterMatch = $false
$script:pointSampleCount = 0
$script:runMatchLimit = 0
$script:runStartMatchCount = 0
$script:parkingMode = $false
$script:startingRankPoints = $null
$script:currentRankPoints = $null
$script:rankResyncRequired = $false
$script:startingRankReadAt = [DateTime]::MinValue
$script:rankOcrEngine = $null
$script:rankOcrAwaiter = $null

# Template filenames intentionally define their behavior.
$templateDefinitions = @(
    [PSCustomObject]@{ File = "tier_popup.png"; Action = "click"; Label = "등급 변경 안내 확인"; X1 = 0.52; Y1 = 0.73; X2 = 0.66; Y2 = 0.81; Threshold = 4.0; ScaledThreshold = 5.0; Cooldown = 1800 },
    [PSCustomObject]@{ File = "tier_result.png"; Action = "click"; Label = "승급·강등·잔류 결과 확인"; X1 = 0.75; Y1 = 0.90; X2 = 0.89; Y2 = 0.99; Threshold = 4.0; ScaledThreshold = 5.0; Cooldown = 1800 },
    [PSCustomObject]@{ File = "click_1.png"; Action = "click"; Label = "공식경기 (전 등급)"; X1 = 0.70; Y1 = 0.72; X2 = 1.00; Y2 = 1.00; Threshold = 7.5; ScaledThreshold = 7.5; Cooldown = 1800 },
    [PSCustomObject]@{ File = "click_2.png"; Action = "click"; Label = "확인"; X1 = 0.10; Y1 = 0.30; X2 = 1.00; Y2 = 1.00; Threshold = 6.0; ScaledThreshold = 8.0; Cooldown = 1800 },
    [PSCustomObject]@{ File = "click_3.png"; Action = "click"; Label = "확인 화살표"; X1 = 0.10; Y1 = 0.30; X2 = 1.00; Y2 = 1.00; Threshold = 6.0; ScaledThreshold = 8.0; Cooldown = 1800 },
    [PSCustomObject]@{ File = "click_4.png"; Action = "click"; Label = "준비 완료"; X1 = 0.40; Y1 = 0.45; X2 = 0.85; Y2 = 0.80; Threshold = 6.0; ScaledThreshold = 8.5; Cooldown = 1800 },
    [PSCustomObject]@{ File = "client.png"; Action = "none"; Label = "FC 클라이언트"; X1 = 0.00; Y1 = 0.00; X2 = 0.25; Y2 = 0.25; Threshold = 10.0; ScaledThreshold = 12.0; Cooldown = 3000 },
    [PSCustomObject]@{ File = "esc.png"; Action = "esc"; Label = "경기 하이라이트 ESC SKIP"; X1 = 0.80; Y1 = 0.915; X2 = 0.87; Y2 = 0.975; Threshold = 36.0; ScaledThreshold = 36.0; Cooldown = 2200 },
    [PSCustomObject]@{ File = "s.png"; Action = "s"; Label = "S 안내"; X1 = 0.89; Y1 = 0.89; X2 = 0.98; Y2 = 0.99; Threshold = 12.0; ScaledThreshold = 16.0; Cooldown = 900 },
    [PSCustomObject]@{ File = "skip.png"; Action = "s"; Label = "후반 종료 SKIP"; X1 = 0.20; Y1 = 0.60; X2 = 1.00; Y2 = 1.00; Threshold = 16.0; ScaledThreshold = 18.0; Cooldown = 900 },
    [PSCustomObject]@{ File = "space_1.png"; Action = "space"; Label = "진행"; X1 = 0.60; Y1 = 0.70; X2 = 1.00; Y2 = 1.00; Threshold = 6.0; ScaledThreshold = 8.5; Cooldown = 1500 },
    [PSCustomObject]@{ File = "space_2.png"; Action = "space"; Label = "선택 완료"; X1 = 0.25; Y1 = 0.50; X2 = 0.65; Y2 = 0.75; Threshold = 6.0; ScaledThreshold = 7.0; Cooldown = 1500 },
    [PSCustomObject]@{ File = "space_3.png"; Action = "space"; Label = "다음"; X1 = 0.60; Y1 = 0.70; X2 = 1.00; Y2 = 1.00; Threshold = 6.0; ScaledThreshold = 6.0; Cooldown = 1500 }
)

foreach ($definition in $templateDefinitions) {
    $templatePath = Join-Path $script:templateDir $definition.File
    if (-not [IO.File]::Exists($templatePath)) {
        throw "화면 인식 템플릿을 찾지 못했습니다: $($definition.File)"
    }
    $templateBitmap = New-Object Drawing.Bitmap($templatePath)
    try {
        $buffer = [FCTemplateMatcher]::FromBitmap($templateBitmap)
    } finally {
        $templateBitmap.Dispose()
    }
    [void]$script:templates.Add([PSCustomObject]@{
        Definition = $definition
        Buffer = $buffer
    })

    $hdTemplatePath = Join-Path $script:hdTemplateDir $definition.File
    if ([IO.File]::Exists($hdTemplatePath)) {
        $hdTemplateBitmap = New-Object Drawing.Bitmap($hdTemplatePath)
        try {
            $hdBuffer = [FCTemplateMatcher]::FromBitmap($hdTemplateBitmap)
        } finally {
            $hdTemplateBitmap.Dispose()
        }
        [void]$script:hdTemplates.Add([PSCustomObject]@{
            Definition = $definition
            Buffer = $hdBuffer
        })
    }
}

$form = New-Object System.Windows.Forms.Form
$form.Text = "FC Manager Assistant"
$form.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::None
$form.ClientSize = New-Object System.Drawing.Size(720, 880)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox = $false
$form.BackColor = [Drawing.Color]::FromArgb(8, 31, 23)
$form.ForeColor = [Drawing.Color]::White
$form.Font = New-Object Drawing.Font("Malgun Gothic", 9)

$title = New-Object System.Windows.Forms.Label
$title.Text = "FC 온라인 감독모드 도우미 v3.2.13 MATCH CONTROL"
$title.Font = New-Object Drawing.Font("Malgun Gothic", 18, [Drawing.FontStyle]::Bold)
$title.ForeColor = [Drawing.Color]::FromArgb(244, 249, 241)
$title.Location = New-Object Drawing.Point(24, 18)
$title.Size = New-Object Drawing.Size(500, 42)
$form.Controls.Add($title)

$subtitle = New-Object System.Windows.Forms.Label
$subtitle.Text = "일반 모드 · 연속 진행     |     주차 모드 · 목표점수 또는 최저점수에서 중지"
$subtitle.ForeColor = [Drawing.Color]::FromArgb(160, 205, 174)
$subtitle.Location = New-Object Drawing.Point(27, 62)
$subtitle.Size = New-Object Drawing.Size(650, 24)
$form.Controls.Add($subtitle)

$statusPanel = New-Object System.Windows.Forms.Panel
$statusPanel.Location = New-Object Drawing.Point(24, 94)
$statusPanel.Size = New-Object Drawing.Size(672, 94)
$statusPanel.BackColor = [Drawing.Color]::FromArgb(18, 76, 49)
$form.Controls.Add($statusPanel)

$statusDot = New-Object System.Windows.Forms.Label
$statusDot.Text = "●"
$statusDot.Font = New-Object Drawing.Font("Malgun Gothic", 16, [Drawing.FontStyle]::Bold)
$statusDot.ForeColor = [Drawing.Color]::FromArgb(150, 156, 166)
$statusDot.Location = New-Object Drawing.Point(16, 10)
$statusDot.Size = New-Object Drawing.Size(30, 30)
$statusPanel.Controls.Add($statusDot)

$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Text = "대기 중"
$statusLabel.Font = New-Object Drawing.Font("Malgun Gothic", 13, [Drawing.FontStyle]::Bold)
$statusLabel.Location = New-Object Drawing.Point(48, 12)
$statusLabel.Size = New-Object Drawing.Size(330, 30)
$statusPanel.Controls.Add($statusLabel)

$windowLabel = New-Object System.Windows.Forms.Label
$windowLabel.Text = "현재 창: 확인 중"
$windowLabel.ForeColor = [Drawing.Color]::FromArgb(190, 196, 205)
$windowLabel.Location = New-Object Drawing.Point(18, 52)
$windowLabel.Size = New-Object Drawing.Size(620, 24)
$statusPanel.Controls.Add($windowLabel)

$counterLabel = New-Object System.Windows.Forms.Label
$counterLabel.Text = "화면 동작: 0회   |   자동 일시정지: 0회"
$counterLabel.TextAlign = "MiddleRight"
$counterLabel.Location = New-Object Drawing.Point(382, 14)
$counterLabel.Size = New-Object Drawing.Size(270, 28)
$statusPanel.Controls.Add($counterLabel)

$startButton = New-Object System.Windows.Forms.Button
$startButton.Text = "시작  (F9)"
$startButton.Location = New-Object Drawing.Point(24, 204)
$startButton.Size = New-Object Drawing.Size(150, 48)
$startButton.FlatStyle = "Flat"
$startButton.BackColor = [Drawing.Color]::FromArgb(24, 160, 88)
$startButton.ForeColor = [Drawing.Color]::White
$startButton.Font = New-Object Drawing.Font("Malgun Gothic", 11, [Drawing.FontStyle]::Bold)
$form.Controls.Add($startButton)

$stopButton = New-Object System.Windows.Forms.Button
$stopButton.Text = "중지  (F12)"
$stopButton.Location = New-Object Drawing.Point(184, 204)
$stopButton.Size = New-Object Drawing.Size(150, 48)
$stopButton.FlatStyle = "Flat"
$stopButton.BackColor = [Drawing.Color]::FromArgb(184, 55, 62)
$stopButton.ForeColor = [Drawing.Color]::White
$stopButton.Font = New-Object Drawing.Font("Malgun Gothic", 11, [Drawing.FontStyle]::Bold)
$stopButton.Enabled = $false
$form.Controls.Add($stopButton)

$finishMatchButton = New-Object System.Windows.Forms.Button
$finishMatchButton.Text = "이번 판까지만 (F8)"
$finishMatchButton.Location = New-Object Drawing.Point(344, 204)
$finishMatchButton.Size = New-Object Drawing.Size(172, 48)
$finishMatchButton.FlatStyle = "Flat"
$finishMatchButton.BackColor = [Drawing.ColorTranslator]::FromHtml('#263240')
$finishMatchButton.ForeColor = [Drawing.Color]::White
$finishMatchButton.Font = New-Object Drawing.Font("Malgun Gothic", 10, [Drawing.FontStyle]::Bold)
$finishMatchButton.Enabled = $false
$form.Controls.Add($finishMatchButton)

$captureButton = New-Object System.Windows.Forms.Button
$captureButton.Text = "FC 화면 저장"
$captureButton.Location = New-Object Drawing.Point(526, 204)
$captureButton.Size = New-Object Drawing.Size(170, 48)
$captureButton.FlatStyle = "Flat"
$captureButton.BackColor = [Drawing.Color]::FromArgb(35, 100, 72)
$captureButton.ForeColor = [Drawing.Color]::White
$form.Controls.Add($captureButton)

$onlyFcCheck = New-Object System.Windows.Forms.CheckBox
$onlyFcCheck.Text = "FC ONLINE 창에서만 입력 (권장)"
$onlyFcCheck.Checked = $true
$onlyFcCheck.Location = New-Object Drawing.Point(30, 264)
$onlyFcCheck.Size = New-Object Drawing.Size(290, 28)
$form.Controls.Add($onlyFcCheck)

$modeGroup = New-Object System.Windows.Forms.GroupBox
$modeGroup.Text = "진행 모드"
$modeGroup.Location = New-Object Drawing.Point(24, 300)
$modeGroup.Size = New-Object Drawing.Size(672, 145)
$modeGroup.ForeColor = [Drawing.Color]::White
$modeGroup.BackColor = [Drawing.Color]::FromArgb(12, 48, 35)
$form.Controls.Add($modeGroup)

$generalModeRadio = New-Object System.Windows.Forms.RadioButton
$generalModeRadio.Text = "일반 모드 · 계속 진행"
$generalModeRadio.Location = New-Object Drawing.Point(16, 23)
$generalModeRadio.Size = New-Object Drawing.Size(225, 25)
$generalModeRadio.Checked = $true
$modeGroup.Controls.Add($generalModeRadio)

$parkingModeRadio = New-Object System.Windows.Forms.RadioButton
$parkingModeRadio.Text = "주차 모드 · 점수 조건에서 중지"
$parkingModeRadio.Location = New-Object Drawing.Point(256, 23)
$parkingModeRadio.Size = New-Object Drawing.Size(290, 25)
$modeGroup.Controls.Add($parkingModeRadio)

$readRankButton = New-Object System.Windows.Forms.Button
$readRankButton.Text = "시작점수 화면 인식"
$readRankButton.Location = New-Object Drawing.Point(16, 58)
$readRankButton.Size = New-Object Drawing.Size(174, 34)
$readRankButton.FlatStyle = "Flat"
$readRankButton.BackColor = [Drawing.Color]::FromArgb(65, 83, 133)
$readRankButton.ForeColor = [Drawing.Color]::White
$modeGroup.Controls.Add($readRankButton)

$rankPointsLabel = New-Object System.Windows.Forms.Label
$rankPointsLabel.Text = "시작점수: 미확인  |  게임의 감독 랭킹 화면에서 읽기"
$rankPointsLabel.Location = New-Object Drawing.Point(199, 64)
$rankPointsLabel.Size = New-Object Drawing.Size(457, 25)
$modeGroup.Controls.Add($rankPointsLabel)

$targetCaption = New-Object System.Windows.Forms.Label
$targetCaption.Text = "목표점수"
$targetCaption.Location = New-Object Drawing.Point(16, 106)
$targetCaption.Size = New-Object Drawing.Size(75, 23)
$modeGroup.Controls.Add($targetCaption)

$targetPointsBox = New-Object System.Windows.Forms.NumericUpDown
$targetPointsBox.Location = New-Object Drawing.Point(91, 104)
$targetPointsBox.Size = New-Object Drawing.Size(105, 24)
$targetPointsBox.Minimum = 0
$targetPointsBox.Maximum = 99999
$targetPointsBox.Value = 4000
$modeGroup.Controls.Add($targetPointsBox)

$minimumPointsCheck = New-Object System.Windows.Forms.CheckBox
$minimumPointsCheck.Text = "최저점수"
$minimumPointsCheck.Location = New-Object Drawing.Point(255, 104)
$minimumPointsCheck.Size = New-Object Drawing.Size(93, 26)
$modeGroup.Controls.Add($minimumPointsCheck)

$minimumPointsBox = New-Object System.Windows.Forms.NumericUpDown
$minimumPointsBox.Location = New-Object Drawing.Point(351, 104)
$minimumPointsBox.Size = New-Object Drawing.Size(105, 24)
$minimumPointsBox.Minimum = 0
$minimumPointsBox.Maximum = 99999
$minimumPointsBox.Value = 3500
$modeGroup.Controls.Add($minimumPointsBox)

$modeHint = New-Object System.Windows.Forms.Label
$modeHint.Text = "주차: 챔피언스 감독 랭킹 화면에서 시작점수를 읽은 뒤 실행"
$modeHint.Location = New-Object Drawing.Point(470, 102)
$modeHint.Size = New-Object Drawing.Size(192, 35)
$modeHint.ForeColor = [Drawing.Color]::FromArgb(205, 184, 243)
$modeGroup.Controls.Add($modeHint)

$matchCounterLabel = New-Object System.Windows.Forms.Label
$matchCounterLabel.Text = "이번 실행 0판 · 0승 0무 0패 (미분류 0)`r`n오늘 0판 · 전체 0판"
$matchCounterLabel.ForeColor = [Drawing.Color]::FromArgb(160, 225, 177)
$matchCounterLabel.Font = New-Object Drawing.Font("Malgun Gothic", 9, [Drawing.FontStyle]::Bold)
$matchCounterLabel.Location = New-Object Drawing.Point(24, 451)
$matchCounterLabel.Size = New-Object Drawing.Size(672, 42)
$matchCounterLabel.TextAlign = "MiddleLeft"
$form.Controls.Add($matchCounterLabel)

$discordGroup = New-Object System.Windows.Forms.GroupBox
$discordGroup.Text = "Discord 멈춤 알림"
$discordGroup.Location = New-Object Drawing.Point(24, 498)
$discordGroup.Size = New-Object Drawing.Size(672, 112)
$discordGroup.ForeColor = [Drawing.Color]::White
$discordGroup.BackColor = [Drawing.Color]::FromArgb(12, 48, 35)
$form.Controls.Add($discordGroup)

$webhookLabel = New-Object System.Windows.Forms.Label
$webhookLabel.Text = "웹훅 주소"
$webhookLabel.Location = New-Object Drawing.Point(14, 28)
$webhookLabel.Size = New-Object Drawing.Size(70, 24)
$discordGroup.Controls.Add($webhookLabel)

$webhookBox = New-Object System.Windows.Forms.TextBox
$webhookBox.Location = New-Object Drawing.Point(86, 25)
$webhookBox.Size = New-Object Drawing.Size(392, 24)
$webhookBox.UseSystemPasswordChar = $true
$discordGroup.Controls.Add($webhookBox)

$saveWebhookButton = New-Object System.Windows.Forms.Button
$saveWebhookButton.Text = "저장"
$saveWebhookButton.Location = New-Object Drawing.Point(486, 23)
$saveWebhookButton.Size = New-Object Drawing.Size(78, 29)
$saveWebhookButton.FlatStyle = "Flat"
$saveWebhookButton.BackColor = [Drawing.Color]::FromArgb(35, 100, 72)
$saveWebhookButton.ForeColor = [Drawing.Color]::White
$discordGroup.Controls.Add($saveWebhookButton)

$testWebhookButton = New-Object System.Windows.Forms.Button
$testWebhookButton.Text = "테스트"
$testWebhookButton.Location = New-Object Drawing.Point(572, 23)
$testWebhookButton.Size = New-Object Drawing.Size(82, 29)
$testWebhookButton.FlatStyle = "Flat"
$testWebhookButton.BackColor = [Drawing.Color]::FromArgb(24, 160, 88)
$testWebhookButton.ForeColor = [Drawing.Color]::White
$discordGroup.Controls.Add($testWebhookButton)

$discordCheck = New-Object System.Windows.Forms.CheckBox
$discordCheck.Text = "감독모드 알림 사용"
$discordCheck.Location = New-Object Drawing.Point(18, 64)
$discordCheck.Size = New-Object Drawing.Size(220, 26)
$discordGroup.Controls.Add($discordCheck)

$discordStatus = New-Object System.Windows.Forms.Label
$discordStatus.Text = "웹훅을 입력하고 저장해 주세요."
$discordStatus.ForeColor = [Drawing.Color]::FromArgb(190, 196, 205)
$discordStatus.Location = New-Object Drawing.Point(244, 67)
$discordStatus.Size = New-Object Drawing.Size(410, 24)
$discordStatus.TextAlign = "MiddleRight"
$discordGroup.Controls.Add($discordStatus)

$note = New-Object System.Windows.Forms.Label
$note.Text = "사용법: F9 시작 · F8 이번 판까지만 예약/취소 · F12 즉시 중지"
$note.ForeColor = [Drawing.Color]::FromArgb(236, 190, 86)
$note.Location = New-Object Drawing.Point(27, 624)
$note.Size = New-Object Drawing.Size(665, 26)
$form.Controls.Add($note)

$logBox = New-Object System.Windows.Forms.RichTextBox
$logBox.Location = New-Object Drawing.Point(24, 658)
$logBox.Size = New-Object Drawing.Size(672, 172)
$logBox.ReadOnly = $true
$logBox.BackColor = [Drawing.Color]::FromArgb(5, 22, 16)
$logBox.ForeColor = [Drawing.Color]::FromArgb(210, 231, 216)
$logBox.BorderStyle = "FixedSingle"
$logBox.Font = New-Object Drawing.Font("Consolas", 9)
$form.Controls.Add($logBox)

$footer = New-Object System.Windows.Forms.Label
$footer.Text = "외부 자동 입력은 게임 운영정책에 따라 제한될 수 있습니다. 사용 책임은 사용자에게 있습니다."
$footer.ForeColor = [Drawing.Color]::FromArgb(145, 150, 158)
$footer.Location = New-Object Drawing.Point(27, 846)
$footer.Size = New-Object Drawing.Size(665, 22)
$form.Controls.Add($footer)

function Get-RunMatchProgress {
    $completed=[Math]::Max(0,([int]$script:sessionMatchCount - [int]$script:runStartMatchCount))
    $limit=[int]$script:runMatchLimit
    return [PSCustomObject]@{Completed=$completed;Limit=$limit;Remaining=[Math]::Max(0,$limit-$completed);Reached=($limit -gt 0 -and $completed -ge $limit)}
}

function Update-RunMatchLimit {
    $progress=Get-RunMatchProgress
    if ($progress.Reached -and -not $script:requiredStopAfterMatch) {
        $script:stopAfterCurrentMatch=$true
        $script:requiredStopAfterMatch=$true
        Write-Log "설정한 $($progress.Limit)판을 완료했습니다. 결과 화면을 넘긴 뒤 중지합니다."
        Queue-DiscordNotification '설정 판수 완료' "$($progress.Completed) / $($progress.Limit)판 완료"
    }
}

function Update-RunProgress {
    if ($null -eq $script:runProgressLabel) { return }
    $progress=Get-RunMatchProgress
    $limit=$progress.Limit
    $completed=$progress.Completed
    if (-not $script:running -and $completed -eq 0) {
        $limit=if ($script:runLimitCheck.Checked) {[int]$script:runLimitBox.Value}else{0}
    }
    $script:runProgressLabel.Text=if($limit -gt 0){"완료 $completed / $limit 판"}else{"완료 $completed 판"}
    $script:runProgressHint.Text=if($limit -gt 0){"남은 경기 $([Math]::Max(0,$limit-$completed))판"}else{'판수 제한 없음'}
    $fraction=if($limit -gt 0){[Math]::Min(1.0,$completed/[double]$limit)}else{0.0}
    $script:runProgressFill.Width=[int]($script:runProgressTrack.Width*$fraction)
}

function Apply-ModernLayout {
    $bg=[Drawing.ColorTranslator]::FromHtml('#10151C')
    $card=[Drawing.ColorTranslator]::FromHtml('#19212C')
    $inputBg=[Drawing.ColorTranslator]::FromHtml('#263240')
    $muted=[Drawing.ColorTranslator]::FromHtml('#AAB9C8')
    $text=[Drawing.ColorTranslator]::FromHtml('#F0F6FA')
    $accent=[Drawing.ColorTranslator]::FromHtml('#147C76')
    $form.ClientSize=[Drawing.Size]::new(1148,682)
    $form.BackColor=$bg
    $form.Font=[Drawing.Font]::new('Malgun Gothic',10)
    $title.Text='FC Manager'
    $title.SetBounds(24,12,540,42)
    $title.Font=[Drawing.Font]::new('Segoe UI',23,[Drawing.FontStyle]::Bold)
    $title.ForeColor=$text
    $subtitle.Text='FC 온라인 감독모드 도우미'
    $subtitle.SetBounds(26,57,540,25);$subtitle.ForeColor=$muted
    $statusPanel.SetBounds(24,96,544,126);$statusPanel.BackColor=$card
    $statusDot.SetBounds(14,14,24,30)
    $statusLabel.SetBounds(40,13,485,32)
    $windowLabel.SetBounds(16,51,512,30);$windowLabel.ForeColor=$muted
    $counterLabel.SetBounds(16,87,512,27);$counterLabel.TextAlign='MiddleLeft';$counterLabel.ForeColor=$muted
    $statusLabel.ForeColor=$text
    $startButton.SetBounds(24,238,180,42);$startButton.BackColor=$accent
    $stopButton.SetBounds(214,238,136,42);$stopButton.BackColor=[Drawing.ColorTranslator]::FromHtml('#3C2832')
    $finishMatchButton.SetBounds(360,238,215,42)
    $captureButton.SetBounds(954,238,170,42);$captureButton.BackColor=$inputBg
    foreach($b in @($startButton,$stopButton,$finishMatchButton,$captureButton,$readRankButton,$saveWebhookButton,$testWebhookButton)){
        $b.FlatAppearance.BorderSize=0;$b.Cursor=[Windows.Forms.Cursors]::Hand
        $b.Font=[Drawing.Font]::new('Malgun Gothic',10,[Drawing.FontStyle]::Bold)
        $b.ForeColor=$text
        $b.UseVisualStyleBackColor=$false
        $b.FlatAppearance.MouseOverBackColor=[Drawing.ColorTranslator]::FromHtml('#354658')
        $b.FlatAppearance.MouseDownBackColor=[Drawing.ColorTranslator]::FromHtml('#425770')
    }
    $script:progressCard=[Windows.Forms.Panel]::new()
    $script:progressCard.SetBounds(584,96,540,126);$script:progressCard.BackColor=$card
    $form.Controls.Add($script:progressCard)
    $script:runProgressLabel=[Windows.Forms.Label]::new()
    $script:runProgressLabel.SetBounds(18,7,285,44)
    $script:runProgressLabel.Font=[Drawing.Font]::new('Malgun Gothic',17,[Drawing.FontStyle]::Bold)
    $script:runProgressLabel.ForeColor=$text
    $script:progressCard.Controls.Add($script:runProgressLabel)
    $script:runProgressHint=[Windows.Forms.Label]::new()
    $script:runProgressHint.SetBounds(307,19,215,25);$script:runProgressHint.TextAlign='MiddleRight'
    $script:runProgressHint.ForeColor=$muted;$script:progressCard.Controls.Add($script:runProgressHint)
    $script:runProgressTrack=[Windows.Forms.Panel]::new()
    $script:runProgressTrack.SetBounds(18,55,504,5);$script:runProgressTrack.BackColor=$inputBg
    $script:runProgressFill=[Windows.Forms.Panel]::new()
    $script:runProgressFill.SetBounds(0,0,0,5);$script:runProgressFill.BackColor=$accent
    $script:runProgressTrack.Controls.Add($script:runProgressFill)
    $script:progressCard.Controls.Add($script:runProgressTrack)
    $matchCounterLabel.Parent=$script:progressCard
    $matchCounterLabel.SetBounds(18,67,504,49)
    $matchCounterLabel.ForeColor=$muted;$matchCounterLabel.Font=[Drawing.Font]::new('Malgun Gothic',9)
    $script:settingsTabs=[Windows.Forms.TabControl]::new()
    $script:settingsTabs.ItemSize=[Drawing.Size]::new(140,34)
    $script:settingsTabs.SizeMode='Fixed'
    $form.Controls.Add($script:settingsTabs)
    $script:runSettingsPage=[Windows.Forms.TabPage]::new('진행 설정')
    $script:notifyPage=[Windows.Forms.TabPage]::new('Discord 알림')
    $script:logsPage=[Windows.Forms.TabPage]::new('실행 기록')
    foreach($p in @($script:runSettingsPage,$script:notifyPage,$script:logsPage)){
        $p.BackColor=$card;$p.ForeColor=$text;$script:settingsTabs.TabPages.Add($p)
    }
    # Clip the native tab strip. The sidebar drives the selected page.
    $tabHost=[Windows.Forms.Panel]::new();$tabHost.SetBounds(180,298,944,330);$tabHost.BackColor=$card
    $form.Controls.Add($tabHost);$script:settingsTabs.Parent=$tabHost
    $script:settingsTabs.SetBounds(-4,-38,952,372)
    $script:tabNav=@()
    $navTop=298
    for($index=0;$index -lt 3;$index++){
        $navRow=@(0,2,3)[$index]
        $nav=[Windows.Forms.Button]::new();$nav.Text=$script:settingsTabs.TabPages[$index].Text
        $nav.SetBounds(24,($navTop+$navRow*46),140,40);$nav.FlatStyle='Flat';$nav.FlatAppearance.BorderSize=0
        $nav.Cursor=[Windows.Forms.Cursors]::Hand;$nav.ForeColor=$muted
        $nav.TextAlign='MiddleLeft';$nav.Padding=[Windows.Forms.Padding]::new(12,0,0,0)
        $nav.BackColor=if($index -eq 0){[Drawing.ColorTranslator]::FromHtml('#203D3F')}else{$bg}
        if($index -eq 0){$nav.ForeColor=[Drawing.ColorTranslator]::FromHtml('#A9E8DF')}
        $nav.Tag=$index
        $nav.Add_Click({param($sender,$e) $script:settingsTabs.SelectedIndex=[int]$sender.Tag})
        $script:tabNav+=,$nav;$form.Controls.Add($nav)
    }
    $script:settingsTabs.Add_SelectedIndexChanged({
        for($i=0;$i -lt $script:tabNav.Count;$i++){
            $selected=$i -eq $script:settingsTabs.SelectedIndex
            $script:tabNav[$i].BackColor=[Drawing.ColorTranslator]::FromHtml($(if($selected){'#203D3F'}else{'#10151C'}))
            $script:tabNav[$i].ForeColor=[Drawing.ColorTranslator]::FromHtml($(if($selected){'#A9E8DF'}else{'#AAB9C8'}))
        }
    })
    $script:runLimitCheck=[Windows.Forms.CheckBox]::new()
    $script:runLimitCheck.Text='판수 제한';$script:runLimitCheck.SetBounds(18,13,105,28)
    $script:runSettingsPage.Controls.Add($script:runLimitCheck)
    $script:runLimitBox=[Windows.Forms.NumericUpDown]::new()
    $script:runLimitBox.Minimum=1;$script:runLimitBox.Maximum=9999;$script:runLimitBox.Value=20
    $script:runLimitBox.SetBounds(130,14,95,29);$script:runLimitBox.Enabled=$false
    $script:runSettingsPage.Controls.Add($script:runLimitBox)
    $limitHint=[Windows.Forms.Label]::new()
    $limitHint.Text='판 완료 후 중지  ·  끄면 계속 진행';$limitHint.SetBounds(238,16,470,27)
    $limitHint.ForeColor=$muted;$script:runSettingsPage.Controls.Add($limitHint)
    $script:runLimitCheck.Add_CheckedChanged({
        $script:runLimitBox.Enabled=$script:runLimitCheck.Checked -and -not $script:running
        Update-RunProgress
    })
    $script:runLimitBox.Add_ValueChanged({Update-RunProgress})
    $modeGroup.Parent=$script:runSettingsPage;$modeGroup.SetBounds(14,52,908,123)
    $modeGroup.Text='점수 조건';$modeGroup.BackColor=$card
    $generalModeRadio.SetBounds(16,20,225,25);$parkingModeRadio.SetBounds(256,20,400,25)
    $readRankButton.SetBounds(16,50,174,30)
    $rankPointsLabel.SetBounds(205,54,680,26)
    $targetCaption.SetBounds(16,91,75,25);$targetPointsBox.SetBounds(91,88,105,27)
    $minimumPointsCheck.SetBounds(255,88,93,27);$minimumPointsBox.SetBounds(351,88,105,27)
    $modeHint.SetBounds(475,88,410,28);$modeHint.Text='주차 모드는 시작점수 확인 후 실행';$modeHint.ForeColor=$muted
    $onlyFcCheck.Parent=$script:runSettingsPage;$onlyFcCheck.SetBounds(18,180,800,27)
    $discordGroup.Parent=$script:notifyPage;$discordGroup.SetBounds(14,10,908,155)
    $discordGroup.BackColor=$card;$discordGroup.Text='알림 연결'
    $webhookBox.SetBounds(86,27,600,29)
    $saveWebhookButton.SetBounds(699,26,82,31);$testWebhookButton.SetBounds(793,26,94,31)
    $discordCheck.SetBounds(18,75,290,28);$discordStatus.SetBounds(315,77,570,26)
    $logBox.Parent=$script:logsPage;$logBox.Dock='Fill'
    $logBox.BackColor=$bg;$logBox.ForeColor=$muted;$logBox.BorderStyle='None'
    $logBox.Font=[Drawing.Font]::new('Malgun Gothic',9)
    foreach($box in @($webhookBox,$targetPointsBox,$minimumPointsBox,$script:runLimitBox)){
        $box.BackColor=$inputBg;$box.ForeColor=$text
    }
    $readRankButton.BackColor=$inputBg;$saveWebhookButton.BackColor=$inputBg;$testWebhookButton.BackColor=$accent
    $note.SetBounds(24,642,1100,27);$note.ForeColor=$muted
    $footer.Visible=$false
    Update-RunProgress
}

function Initialize-UpdateUI {
    $script:appVersion='3.2.13'
    $script:releaseManifestUrl='https://raw.githubusercontent.com/Celaq/Fc-Manager-Assistant/main/releases/latest.json'
    $script:updateTask=$null;$script:updatePhase='Idle';$script:availableRelease=$null;$script:updateInstalling=$false
    $script:updateClient=[Net.Http.HttpClient]::new();$script:updateClient.Timeout=[TimeSpan]::FromSeconds(20)
    $script:updateButton=[Windows.Forms.Button]::new();$script:updateButton.Text='업데이트 확인'
    $script:updateButton.SetBounds(932,18,192,34);$script:updateButton.FlatStyle='Flat';$script:updateButton.FlatAppearance.BorderSize=0
    $script:updateButton.BackColor=[Drawing.ColorTranslator]::FromHtml('#263240');$script:updateButton.ForeColor=[Drawing.Color]::White
    $script:updateButton.Font=[Drawing.Font]::new('Malgun Gothic',11,[Drawing.FontStyle]::Bold)
    $form.Controls.Add($script:updateButton)
    $script:releaseNotesButton=[Windows.Forms.Button]::new();$script:releaseNotesButton.Text='변경내용'
    $script:releaseNotesButton.SetBounds(808,18,112,34);$script:releaseNotesButton.FlatStyle='Flat';$script:releaseNotesButton.FlatAppearance.BorderSize=0
    $script:releaseNotesButton.BackColor=[Drawing.ColorTranslator]::FromHtml('#263240');$script:releaseNotesButton.ForeColor=[Drawing.Color]::White
    $script:releaseNotesButton.Font=[Drawing.Font]::new('Malgun Gothic',11);$script:releaseNotesButton.Visible=$false
    $form.Controls.Add($script:releaseNotesButton)
    $script:releaseNotesButton.Add_Click({
        if($script:availableRelease){[void][Windows.Forms.MessageBox]::Show($form,$script:availableRelease.Notes,'업데이트 변경내용',[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Information)}
    })
    $script:updateLabel=[Windows.Forms.Label]::new();$script:updateLabel.SetBounds(604,56,520,26)
    $script:updateLabel.Font=[Drawing.Font]::new('Malgun Gothic',10.5);$script:updateLabel.TextAlign='MiddleRight'
    $script:updateLabel.ForeColor=[Drawing.ColorTranslator]::FromHtml('#ABC2CE');$script:updateLabel.Text='현재 버전 3.2.13'
    $form.Controls.Add($script:updateLabel)
    $script:updateButton.Add_Click({
        if($script:availableRelease){Start-UpdateDownload}else{Start-UpdateCheck}
    })
    $form.Add_Shown({if(-not $script:disableUpdateCheck){Start-UpdateCheck}})
}

function Start-UpdateCheck {
    if($null -ne $script:updateTask -or $script:updateInstalling){return}
    try {
        [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
        $script:updateLabel.Text='새 버전을 확인하고 있습니다…'
        $script:updateButton.Enabled=$false
        $script:updatePhase='Check'
        $script:updateTask=$script:updateClient.GetStringAsync($script:releaseManifestUrl)
    } catch {Set-UpdateFailure $_.Exception.Message}
}

function Set-UpdateFailure([string]$message) {
    $script:updateTask=$null;$script:updateInstalling=$false;$script:updatePhase='Idle'
    $script:updateButton.Enabled=$true;$startButton.Enabled=-not $script:running
    $script:updateButton.Text=if($script:availableRelease){'업데이트 재시도'}else{'업데이트 확인'}
    $script:updateLabel.Text='업데이트 확인/다운로드 실패 · 다시 시도할 수 있습니다'
    Write-Log "업데이트: $message"
}

function Start-UpdateDownload {
    if($script:running -or $script:coachRun -or $script:bpRun -or $script:maintenancePlan){$script:updateLabel.Text='자동 진행과 예약을 종료한 뒤 업데이트해 주세요.';return}
    if($null -eq $script:availableRelease -or $null -ne $script:updateTask){return}
    try {
        $script:updateInstalling=$true;$startButton.Enabled=$false;$script:updateButton.Enabled=$false
        $script:updateLabel.Text='업데이트 다운로드 중 · 설정과 전적은 보존됩니다'
        $script:updatePhase='Download'
        $script:updateTask=$script:updateClient.GetByteArrayAsync($script:availableRelease.Url)
    } catch {Set-UpdateFailure $_.Exception.Message}
}

function Process-UpdateTask {
    if($null -eq $script:updateTask -or !$script:updateTask.IsCompleted){return}
    try {
        $task=$script:updateTask;$phase=$script:updatePhase;$script:updateTask=$null
        if($phase -eq 'Check'){
            $manifest=$task.GetAwaiter().GetResult()|ConvertFrom-Json
            $release=Test-FCRelease $manifest $script:appVersion
            if($release.Available){
                $script:availableRelease=$release
                $script:releaseNotesButton.Visible=-not [string]::IsNullOrWhiteSpace($release.Notes)
                $script:updateButton.Text="v$($release.Version) 업데이트"
                $script:updateLabel.Text='새 버전이 있습니다 · 중지 후 버튼을 눌러 설치'
            } else {
                $script:availableRelease=$null;$script:updateButton.Text='업데이트 확인'
                $script:releaseNotesButton.Visible=$false
                $script:updateLabel.Text='최신 버전을 사용하고 있습니다.'
            }
            $script:updateButton.Enabled=$true;$script:updatePhase='Idle'
        } elseif($phase -eq 'Download'){
            $data=$task.GetAwaiter().GetResult()
            if($data.Length -gt 20MB){throw 'Downloaded package exceeds size limit.'}
            $cache=Join-Path $script:appDir '.updates';[void][IO.Directory]::CreateDirectory($cache)
            $zip=Join-Path $cache ('release-'+[Guid]::NewGuid().ToString('N')+'.zip')
            [IO.File]::WriteAllBytes($zip,$data)
            if((Get-FCSha256 $zip) -ne $script:availableRelease.Sha256){throw 'Downloaded ZIP digest mismatch.'}
            if($script:running){throw 'Automatic progression is running; update cancelled.'}
            $script:updateLabel.Text='파일 검증 완료 · 종료 후 업데이트하고 재실행합니다'
            $installer=Join-Path $script:appDir 'InstallUpdate.ps1'
            # All arguments are local paths or values validated by Test-FCRelease.
            foreach($p in @($installer,$script:appDir,$zip)){if($p.Contains('"')){throw 'Unsupported quote in update path.'}}
            $launchArgs='-NoProfile -ExecutionPolicy Bypass -File "{0}" -AppRoot "{1}" -ZipPath "{2}" -Sha256 {3} -Version {4} -ParentId {5}' -f $installer,$script:appDir,$zip,$script:availableRelease.Sha256,$script:availableRelease.Version,$PID
            Start-Process -FilePath 'powershell.exe' -ArgumentList $launchArgs -WorkingDirectory $script:appDir -WindowStyle Hidden -ErrorAction Stop|Out-Null
            $form.Close()
        }
    } catch {Set-UpdateFailure $_.Exception.Message}
}

function Apply-ReadableFonts {
    $form.Font=[Drawing.Font]::new('Malgun Gothic',12)
    $pending=[Collections.Generic.Queue[Windows.Forms.Control]]::new();$pending.Enqueue($form)
    while($pending.Count){
        $control=$pending.Dequeue()
        foreach($child in $control.Controls){$pending.Enqueue($child)}
        if($control -is [Windows.Forms.Label] -or $control -is [Windows.Forms.CheckBox] -or $control -is [Windows.Forms.RadioButton] -or $control -is [Windows.Forms.GroupBox]){
            $control.Font=[Drawing.Font]::new('Malgun Gothic',11.5)
            $control.ForeColor=[Drawing.ColorTranslator]::FromHtml('#DCE5F2')
            if($control -is [Windows.Forms.Label]){$control.AutoEllipsis=$true}
        }
        if($control -is [Windows.Forms.Button]){$control.Font=[Drawing.Font]::new('Malgun Gothic',11.5,[Drawing.FontStyle]::Bold)}
        if($control -is [Windows.Forms.NumericUpDown] -or $control -is [Windows.Forms.TextBox]){$control.Font=[Drawing.Font]::new('Malgun Gothic',12)}
    }
    $title.Font=[Drawing.Font]::new('Segoe UI',23,[Drawing.FontStyle]::Bold)
    $subtitle.Font=[Drawing.Font]::new('Malgun Gothic',12)
    $statusLabel.Font=[Drawing.Font]::new('Malgun Gothic',14,[Drawing.FontStyle]::Bold)
    $counterLabel.Font=[Drawing.Font]::new('Malgun Gothic',10.5)
    $script:runProgressLabel.Font=[Drawing.Font]::new('Malgun Gothic',20,[Drawing.FontStyle]::Bold)
    $script:runProgressLabel.Height=44
    $matchCounterLabel.Font=[Drawing.Font]::new('Malgun Gothic',10.5)
    $logBox.Font=[Drawing.Font]::new('Malgun Gothic',11);$logBox.ForeColor=[Drawing.ColorTranslator]::FromHtml('#DCE5F2')
    $modeGroup.SetBounds(14,58,908,162)
    $generalModeRadio.SetBounds(16,25,230,29);$parkingModeRadio.SetBounds(260,25,600,29)
    $readRankButton.SetBounds(16,65,195,34);$rankPointsLabel.SetBounds(225,67,665,30)
    $targetCaption.SetBounds(16,116,75,28);$targetPointsBox.SetBounds(91,111,105,30)
    $minimumPointsCheck.SetBounds(255,111,98,30);$minimumPointsBox.SetBounds(358,111,105,30)
    $modeHint.SetBounds(480,111,410,42);$modeHint.Font=[Drawing.Font]::new('Malgun Gothic',11)
    $onlyFcCheck.SetBounds(18,236,890,30)
    $note.Font=[Drawing.Font]::new('Malgun Gothic',10.5)
    $script:runLimitCheck.SetBounds(18,14,110,30);$script:runLimitBox.SetBounds(138,14,100,30)
    $limitHintControl=@($script:runSettingsPage.Controls|Where-Object{$_.Text -like '판 완료 후*'})[0]
    $limitHintControl.SetBounds(252,16,640,30)
    $webhookBox.SetBounds(110,30,565,32)
    $webhookLabel.SetBounds(14,32,92,29)
    $discordCheck.SetBounds(18,80,300,32)
    $discordStatus.SetBounds(330,82,550,45)
    $discordGroup.Height=155
    $notificationHelp=[Windows.Forms.Label]::new()
    $notificationHelp.Text='보상 확인 실패·복귀 실패 및 승급·강등을 알립니다. 등급 결과 판독에는 Windows 한국어 OCR이 필요합니다.'
    $notificationHelp.SetBounds(18,115,855,32)
    $notificationHelp.Font=[Drawing.Font]::new('Malgun Gothic',10)
    $notificationHelp.ForeColor=[Drawing.ColorTranslator]::FromHtml('#AAB9C8')
    $discordGroup.Controls.Add($notificationHelp)
}

function Write-Log([string]$message) {
    $line = "[{0}] {1}" -f (Get-Date -Format "HH:mm:ss"), $message
    $logBox.AppendText($line + [Environment]::NewLine)
    $logBox.SelectionStart = $logBox.TextLength
    $logBox.ScrollToCaret()
    try { Add-Content -LiteralPath $script:logPath -Value $line -Encoding UTF8 } catch {}
}

function Save-DiagnosticInfo([string]$lastEvent) {
    try {
        $bounds = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
        $fcWindowText = "찾지 못함"
        $fcInfo = Get-FCWindowInfo
        if ($null -ne $fcInfo) {
            $fcRect = New-Object FCNative+RECT
            if ([FCNative]::GetWindowRect($fcInfo.Handle, [ref]$fcRect)) {
                $fcWidth = $fcRect.Right - $fcRect.Left
                $fcHeight = $fcRect.Bottom - $fcRect.Top
                $fcWindowText = "$($fcWidth)x$($fcHeight) / 위치 $($fcRect.Left),$($fcRect.Top)"
            }
        }
        $lines = @(
            "FC 온라인 감독모드 도우미 v3.2.13 일반·주차 베타 진단정보",
            "생성 시각: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')",
            "마지막 상태: $lastEvent",
            "Windows: $([Environment]::OSVersion.VersionString)",
            "PowerShell: $($PSVersionTable.PSVersion.ToString())",
            "DPI 인식: $script:dpiAwarenessMode",
            "주 모니터: $($bounds.Width)x$($bounds.Height)",
            "FC 창: $fcWindowText",
            "FC 권장 설정: 1280x720 창모드 / Windows 배율 100%",
            "전적: $(Get-MatchSummary)",
            "",
            "이 폴더에는 Discord 웹훅과 settings.json이 포함되지 않습니다."
        )
        $lines | Set-Content -LiteralPath (Join-Path $script:diagnosticDir "진단정보.txt") -Encoding UTF8
    } catch {}
}

function Update-MatchCounter {
    Update-RunProgress
    $matchCounterLabel.Text = "이번 실행 $($script:sessionMatchCount)판 · $($script:sessionWinCount)승 $($script:sessionDrawCount)무 $($script:sessionLossCount)패 (미분류 $($script:sessionUnclassifiedCount))`r`n" +
        "오늘 $($script:todayMatchCount)판 $($script:todayWinCount)승 $($script:todayDrawCount)무 $($script:todayLossCount)패(미분류 $($script:todayUnclassifiedCount)) · 전체 $($script:totalMatchCount)판 · 점수 샘플 $($script:pointSampleCount)장"
}

function Get-StatsDay {
    return ([DateTime]::UtcNow.AddHours(9)).ToString('yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture)
}
function Test-StatsDay([string]$day) {
    $parsed=[datetime]::MinValue
    return [datetime]::TryParseExact($day,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$parsed)
}
function New-DailyStatsEntry($count,$win,$draw,$loss,$unknown) {
    $w=[Math]::Max(0,[int]$win);$d=[Math]::Max(0,[int]$draw);$l=[Math]::Max(0,[int]$loss)
    $n=[Math]::Max([Math]::Max(0,[int]$count),$w+$d+$l+[Math]::Max(0,[int]$unknown))
    return @{Count=$n;Win=$w;Draw=$d;Loss=$l;Unclassified=($n-$w-$d-$l)}
}
function Read-DailyStats($stats,[string]$csv) {
    $days=@{}
    if($stats -and $null -ne $stats.DailyHistory){
        foreach($p in $stats.DailyHistory.PSObject.Properties){
            if(Test-StatsDay $p.Name){
                $v=$p.Value
                try{$days[$p.Name]=New-DailyStatsEntry $v.Count $v.Win $v.Draw $v.Loss $v.Unclassified}catch{}
            }
        }
    }
    if($stats -and (Test-StatsDay ([string]$stats.Date)) -and !$days.ContainsKey([string]$stats.Date)){
        try{$days[[string]$stats.Date]=New-DailyStatsEntry $stats.TodayCount $stats.TodayWin $stats.TodayDraw $stats.TodayLoss $stats.TodayUnclassified}catch{}
    }
    $seen=@{}
    $imported=@{}
    if([IO.File]::Exists($csv)){
        try{$rows=Import-Csv -LiteralPath $csv -Encoding UTF8 -ErrorAction Stop}catch{$rows=@();Write-Log '기존 경기 샘플 목록을 읽지 못했습니다.'}
        foreach($row in $rows){
            if($row.time -notmatch '^(\d{4}-\d{2}-\d{2})[ T]' -or [string]::IsNullOrWhiteSpace($row.file)){continue}
            $day=$Matches[1]
            if(!(Test-StatsDay $day) -or $days.ContainsKey($day) -or $seen.ContainsKey($row.file)){continue}
            if($row.result -notin @('win','draw','loss','unclassified')){continue}
            $seen[$row.file]=$true
            if(!$imported.ContainsKey($day)){$imported[$day]=New-DailyStatsEntry 0 0 0 0 0}
            $entry=$imported[$day]
            $entry.Count++
            $key=if($row.result -eq 'unclassified'){'Unclassified'}else{$row.result}
            $entry[$key]++
        }
    }
    if($imported){foreach($day in $imported.Keys){$days[$day]=$imported[$day]}}
    return $days
}
function Update-DailyStatsEntry {
    $script:dailyHistory[$script:statsDate]=New-DailyStatsEntry $script:todayMatchCount $script:todayWinCount $script:todayDrawCount $script:todayLossCount $script:todayUnclassifiedCount
}
function Refresh-DailyStatsView {
    if(!$script:dailyGrid -or !$script:dailyDirty){return}
    $grid=$script:dailyGrid
    $selected=if($grid.CurrentRow){[string]$grid.CurrentRow.Cells[0].Value}else{''}
    $grid.Rows.Clear()
    $selectedIndex=-1
    foreach($day in ($script:dailyHistory.Keys | Sort-Object -Descending)){
        $v=$script:dailyHistory[$day]
        if($v.Count -eq 0){continue}
        $pct=if($v.Win+$v.Draw+$v.Loss -gt 0){'{0:F1}%' -f (100.0*$v.Win/($v.Win+$v.Draw+$v.Loss))}else{'—'}
        $i=$grid.Rows.Add($day,$v.Count,$v.Win,$v.Draw,$v.Loss,$v.Unclassified,$pct)
        if($day -eq $selected){$selectedIndex=$i}
    }
    if($selectedIndex -ge 0){$grid.CurrentCell=$grid.Rows[$selectedIndex].Cells[0]}
    $script:dailyEmpty.Visible=$grid.Rows.Count -eq 0
    $script:dailyDirty=$false
}
function Initialize-DailyStatsView {
    $page=[Windows.Forms.TabPage]::new('일별 전적')
    $page.BackColor=[Drawing.ColorTranslator]::FromHtml('#19212C')
    $hint=[Windows.Forms.Label]::new()
    $hint.Text='날짜별 경기 결과  ·  한국 시간 기준  ·  승률은 판정된 경기 기준'
    $hint.SetBounds(20,12,885,27);$hint.ForeColor=[Drawing.Color]::White
    $grid=[Windows.Forms.DataGridView]::new()
    $script:dailyGrid=$grid
    $grid.SetBounds(20,48,900,266);$grid.BackgroundColor=$page.BackColor
    $grid.ReadOnly=$true;$grid.AllowUserToAddRows=$false;$grid.AllowUserToDeleteRows=$false
    $grid.RowHeadersVisible=$false;$grid.AutoSizeColumnsMode='Fill';$grid.SelectionMode='FullRowSelect'
    $grid.MultiSelect=$false;$grid.EnableHeadersVisualStyles=$false
    $grid.DefaultCellStyle.BackColor=[Drawing.ColorTranslator]::FromHtml('#19212C')
    $grid.DefaultCellStyle.ForeColor=[Drawing.Color]::White
    $grid.ColumnHeadersDefaultCellStyle.BackColor=[Drawing.ColorTranslator]::FromHtml('#263240')
    $grid.ColumnHeadersDefaultCellStyle.ForeColor=[Drawing.Color]::White
    $grid.BorderStyle='None'
    $grid.GridColor=[Drawing.ColorTranslator]::FromHtml('#304050')
    $grid.AlternatingRowsDefaultCellStyle.BackColor=[Drawing.ColorTranslator]::FromHtml('#1E2834')
    $grid.DefaultCellStyle.SelectionBackColor=[Drawing.ColorTranslator]::FromHtml('#203D3F')
    $grid.DefaultCellStyle.SelectionForeColor=[Drawing.ColorTranslator]::FromHtml('#D6FBF5')
    $grid.ColumnHeadersHeight=34;$grid.RowTemplate.Height=31
    foreach($col in @('날짜','전체 판수','승','무','패','미분류','승률')){
        $i=$grid.Columns.Add("daily$($grid.Columns.Count)",$col)
        $grid.Columns[$i].SortMode='NotSortable'
    }
    $grid.Columns[0].FillWeight=150
    $script:dailyEmpty=[Windows.Forms.Label]::new()
    $script:dailyEmpty.Text='저장된 경기 기록이 없습니다.'
    $script:dailyEmpty.SetBounds(36,97,630,38);$script:dailyEmpty.ForeColor=[Drawing.Color]::White
    $page.Controls.Add($hint);$page.Controls.Add($grid);$page.Controls.Add($script:dailyEmpty)
    $script:dailyEmpty.BringToFront()
    $script:settingsTabs.TabPages.Add($page)
    $script:dailyPageIndex=$script:settingsTabs.TabPages.Count-1
    $nav=[Windows.Forms.Button]::new()
    $nav.Text='일별 전적';$nav.Tag=$script:dailyPageIndex
    $nav.SetBounds(24,344,140,40);$nav.FlatStyle='Flat';$nav.FlatAppearance.BorderSize=0
    $nav.BackColor=[Drawing.ColorTranslator]::FromHtml('#10151C');$nav.ForeColor=[Drawing.ColorTranslator]::FromHtml('#AAB9C8')
    $nav.Cursor=[Windows.Forms.Cursors]::Hand;$nav.TextAlign='MiddleLeft';$nav.Padding=[Windows.Forms.Padding]::new(12,0,0,0)
    $nav.Font=[Drawing.Font]::new('Malgun Gothic',11.5,[Drawing.FontStyle]::Bold)
    $nav.Add_Click({param($sender,$e) $script:settingsTabs.SelectedIndex=[int]$sender.Tag})
    $script:tabNav+=,$nav;$form.Controls.Add($nav)
    $script:settingsTabs.Add_SelectedIndexChanged({
        if($script:settingsTabs.SelectedIndex -eq $script:dailyPageIndex){Refresh-DailyStatsView}
    })
}

$script:dailyHistory=@{}
$script:dailyDirty=$true

function Save-MatchStats {
    try {
        $stats = [ordered]@{
            Date = $script:statsDate
            TodayCount = [int]$script:todayMatchCount
            TotalCount = [int]$script:totalMatchCount
            TodayWin = [int]$script:todayWinCount
            TodayDraw = [int]$script:todayDrawCount
            TodayLoss = [int]$script:todayLossCount
            TodayUnclassified = [int]$script:todayUnclassifiedCount
            TotalWin = [int]$script:totalWinCount
            TotalDraw = [int]$script:totalDrawCount
            TotalLoss = [int]$script:totalLossCount
            TotalUnclassified = [int]$script:totalUnclassifiedCount
        }
        Update-DailyStatsEntry
        $stats['DailyHistory']=$script:dailyHistory
        $temp=$script:statsPath+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
        try{
            [IO.File]::WriteAllText($temp,($stats|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($true))
            if([IO.File]::Exists($script:statsPath)){
                [IO.File]::Replace($temp,$script:statsPath,($script:statsPath+'.bak'))
            }else{[IO.File]::Move($temp,$script:statsPath)}
        }finally{if([IO.File]::Exists($temp)){[IO.File]::Delete($temp)}}
    } catch {
        Write-Log "판수 기록 저장 실패: $($_.Exception.Message)"
    }
}

function Load-MatchStats {
    $today = Get-StatsDay
    $stats=$null
    $script:statsDate = $today
    if ([IO.File]::Exists($script:statsPath)) {
        try {
            $stats = Get-Content -LiteralPath $script:statsPath -Raw -Encoding UTF8 | ConvertFrom-Json
            $script:totalMatchCount = [Math]::Max(0, [int]$stats.TotalCount)
            $script:totalWinCount = [Math]::Max(0, [int]$stats.TotalWin)
            $script:totalDrawCount = [Math]::Max(0, [int]$stats.TotalDraw)
            $script:totalLossCount = [Math]::Max(0, [int]$stats.TotalLoss)
            $script:totalUnclassifiedCount = [Math]::Max(0, [int]$stats.TotalUnclassified)
            $totalKnown = $script:totalWinCount + $script:totalDrawCount + $script:totalLossCount + $script:totalUnclassifiedCount
            if ($totalKnown -lt $script:totalMatchCount) {
                $script:totalUnclassifiedCount += ($script:totalMatchCount - $totalKnown)
            }
            if ([string]$stats.Date -eq $today) {
                $script:todayMatchCount = [Math]::Max(0, [int]$stats.TodayCount)
                $script:todayWinCount = [Math]::Max(0, [int]$stats.TodayWin)
                $script:todayDrawCount = [Math]::Max(0, [int]$stats.TodayDraw)
                $script:todayLossCount = [Math]::Max(0, [int]$stats.TodayLoss)
                $script:todayUnclassifiedCount = [Math]::Max(0, [int]$stats.TodayUnclassified)
                $todayKnown = $script:todayWinCount + $script:todayDrawCount + $script:todayLossCount + $script:todayUnclassifiedCount
                if ($todayKnown -lt $script:todayMatchCount) {
                    $script:todayUnclassifiedCount += ($script:todayMatchCount - $todayKnown)
                }
            }
        } catch {
            Write-Log "기존 판수 기록을 읽지 못해 새 기록으로 시작합니다."
        }
    }
    $script:dailyHistory=Read-DailyStats $stats (Join-Path $script:resultSampleDir 'samples.csv')
    if($script:dailyHistory.ContainsKey($today)){
        $v=$script:dailyHistory[$today]
        $script:todayMatchCount=$v.Count
        $script:todayWinCount=$v.Win
        $script:todayDrawCount=$v.Draw
        $script:todayLossCount=$v.Loss
        $script:todayUnclassifiedCount=$v.Unclassified
    }
    if($stats -and $script:dailyHistory.Count){Save-MatchStats}
    $script:dailyDirty=$true
    Update-MatchCounter
}

function Get-MatchSummary {
    $summary = "이번 실행 $($script:sessionMatchCount)판 ($($script:sessionWinCount)승 $($script:sessionDrawCount)무 $($script:sessionLossCount)패 · 미분류 $($script:sessionUnclassifiedCount)) · 오늘 $($script:todayMatchCount)판 · 전체 $($script:totalMatchCount)판"
    if ($script:parkingMode -and $null -ne $script:currentRankPoints) {
        $summary += " · 확인된 랭킹 점수 $($script:currentRankPoints)점"
    }
    return $summary
}

function Save-ResultSample($frame, [int]$matchNumber, [string]$result, [string]$scoreText) {
    try {
        $bitmap = [FCTemplateMatcher]::ToBitmap($frame.Buffer)
        if ($null -eq $bitmap) { return "" }
        try {
            $fileName = "Result_{0}_match{1:D4}_{2}.png" -f (Get-Date -Format "yyyyMMdd_HHmmss"), $matchNumber, $result
            $path = Join-Path $script:resultSampleDir $fileName
            $bitmap.Save($path, [Drawing.Imaging.ImageFormat]::Png)
        } finally {
            $bitmap.Dispose()
        }

        $indexPath = Join-Path $script:resultSampleDir "samples.csv"
        if (-not [IO.File]::Exists($indexPath)) {
            Add-Content -LiteralPath $indexPath -Value "time,session,today,total,result,file" -Encoding UTF8
        }
        $row = "{0},{1},{2},{3},{4},{5}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $script:sessionMatchCount, $script:todayMatchCount, $script:totalMatchCount, $result, $fileName
        Add-Content -LiteralPath $indexPath -Value $row -Encoding UTF8
        return $fileName
    } catch {
        Write-Log "경기 결과 샘플 저장 실패: $($_.Exception.Message)"
        return ""
    }
}

function Get-SettledResultFrame($initialFrame) {
    # The green '다음' button appears before every reward row has finished
    # fading in. Keep the result screen open long enough to capture the final
    # points row. This also gives the existing win/draw/loss reader a stable
    # scoreboard instead of a transition frame.
    $bestFrame = $initialFrame
    $sameWindow = $true
    Set-Status "경기 결과 화면 안정화 중" ([Drawing.Color]::FromArgb(236, 190, 86))
    for ($attempt = 1; $attempt -le 14; $attempt++) {
        Start-Sleep -Milliseconds 250
        # Do not pump WinForms messages here. A nested timer tick could see
        # the same '다음' button and press Space before sampling is complete.
        $info = Get-ForegroundInfo
        if (-not $info.Allowed -or $info.Handle -ne $initialFrame.Handle) {
            $sameWindow = $false
            break
        }
        $nextFrame = Get-FCFrame $initialFrame.Handle
        if ($null -ne $nextFrame) { $bestFrame = $nextFrame }
    }
    return [PSCustomObject]@{ Frame = $bestFrame; SameWindow = $sameWindow }
}

function Save-PointSample($frame, [int]$matchNumber, [string]$result, [string]$scoreText) {
    try {
        $bitmap = [FCTemplateMatcher]::ToBitmap($frame.Buffer)
        if ($null -eq $bitmap) { return "" }

        $stamp = Get-Date -Format "yyyyMMdd_HHmmss_fff"
        $safeResult = if ($result -match '^(win|draw|loss|unclassified)$') { $result } else { "unclassified" }
        $baseName = "Point_{0}_match{1:D4}_{2}" -f $stamp, $matchNumber, $safeResult
        $fullName = "$baseName`_full.png"
        $roiName = "$baseName`_score_area.png"
        $fullPath = Join-Path $script:pointSampleFullDir $fullName
        $roiPath = Join-Path $script:pointSampleRoiDir $roiName

        try {
            $bitmap.Save($fullPath, [Drawing.Imaging.ImageFormat]::Png)

            # Broad normalized reward-panel crop. It deliberately includes the
            # label as well as the signed value so future OCR can validate both
            # '승점' and high-tier '점수 획득' layouts.
            $left = [Math]::Max(0, [int]($bitmap.Width * 0.27))
            $top = [Math]::Max(0, [int]($bitmap.Height * 0.27))
            $right = [Math]::Min($bitmap.Width, [int]($bitmap.Width * 0.99))
            $bottom = [Math]::Min($bitmap.Height, [int]($bitmap.Height * 0.82))
            $roiRect = New-Object Drawing.Rectangle($left, $top, ($right - $left), ($bottom - $top))
            $roiBitmap = $bitmap.Clone($roiRect, [Drawing.Imaging.PixelFormat]::Format32bppArgb)
            try {
                $roiBitmap.Save($roiPath, [Drawing.Imaging.ImageFormat]::Png)
            } finally {
                $roiBitmap.Dispose()
            }
        } finally {
            $width = $bitmap.Width
            $height = $bitmap.Height
            $bitmap.Dispose()
        }

        $indexPath = Join-Path $script:pointSampleDir "point_samples.csv"
        if (-not [IO.File]::Exists($indexPath)) {
            Add-Content -LiteralPath $indexPath -Value "time,session,today,total,result,match_score,full_file,score_area_file,width,height" -Encoding UTF8
        }
        $row = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9}" -f `
            (Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"), $script:sessionMatchCount,
            $script:todayMatchCount, $script:totalMatchCount, $safeResult, $scoreText,
            $fullName, $roiName, $width, $height
        Add-Content -LiteralPath $indexPath -Value $row -Encoding UTF8
        $script:pointSampleCount++
        return $fullName
    } catch {
        Write-Log "점수 화면 샘플 저장 실패: $($_.Exception.Message)"
        return ""
    }
}

function Get-StableScoreResult($initialFrame) {
    $bestFrame = $initialFrame
    $lastScore = [FCScoreReader]::Read($initialFrame.Buffer)
    if ($lastScore.Found) {
        return [PSCustomObject]@{ Score = $lastScore; Frame = $initialFrame }
    }

    for ($attempt = 1; $attempt -le 12; $attempt++) {
        Start-Sleep -Milliseconds 250
        $info = Get-ForegroundInfo
        if (-not $info.Allowed -or $info.Handle -ne $initialFrame.Handle) { break }
        $nextFrame = Get-FCFrame $initialFrame.Handle
        if ($null -eq $nextFrame) { continue }
        $bestFrame = $nextFrame
        $lastScore = [FCScoreReader]::Read($nextFrame.Buffer)
        if ($lastScore.Found) {
            return [PSCustomObject]@{ Score = $lastScore; Frame = $nextFrame }
        }
    }
    return [PSCustomObject]@{ Score = $lastScore; Frame = $bestFrame }
}

function Get-ParkingTransition($reading, $current, [int]$target, [bool]$minimumEnabled, [int]$minimum) {
    if ($reading.Reason -eq '등급 승점 화면') {
        return [PSCustomObject]@{ Kind='League'; Current=$null; Stop=$false; Resync=$false }
    }
    if (-not $reading.Found) {
        return [PSCustomObject]@{ Kind='Unreadable'; Current=$null; Stop=$true; Resync=$true }
    }
    if ($null -eq $current) {
        return [PSCustomObject]@{ Kind='Resync'; Current=$null; Stop=$false; Resync=$true }
    }
    $total = [int]$current + [int]$reading.Delta
    $kind = if ($total -ge $target) { 'Target' } elseif ($minimumEnabled -and $total -le $minimum) { 'Minimum' } else { 'Rank' }
    return [PSCustomObject]@{ Kind=$kind; Current=$total; Stop=($kind -in @('Target','Minimum')); Resync=$false }
}

function Get-StableRankResult($initialFrame) {
    $last = $null
    $frame = $initialFrame
    for ($attempt = 0; $attempt -lt 5; $attempt++) {
        $reading = [FCRankPointsReader]::Read($frame.Buffer)
        if ($null -ne $last -and
            (($reading.Found -and $last.Found -and $reading.Delta -eq $last.Delta) -or
             ($reading.Reason -eq '등급 승점 화면' -and $last.Reason -eq $reading.Reason))) { return $reading }
        $last = $reading
        if ($attempt -eq 4) { break }
        Start-Sleep -Milliseconds 300
        $info = Get-ForegroundInfo
        if (-not $info.Allowed -or $info.Handle -ne $initialFrame.Handle) { break }
        $next = Get-FCFrame $initialFrame.Handle
        if ($null -eq $next) { break }
        $frame = $next
    }
    return [PSCustomObject]@{ Found=$false; Delta=0; Reason='점수 재확인 실패 또는 연속 판독 불일치' }
}

function Sync-ParkingRank($frame) {
    $rank = Read-StartingRankPoints $frame
    if (-not $rank.Found) { throw "등급 복귀 후 현재점수 재확인 실패: $($rank.Reason)" }
    Start-Sleep -Milliseconds 350
    $info = Get-ForegroundInfo
    if (-not $info.Allowed -or $info.Handle -ne $frame.Handle) { return $false }
    $secondFrame = Get-FCFrame $frame.Handle
    if ($null -eq $secondFrame) { return $false }
    $second = Read-StartingRankPoints $secondFrame
    if (-not $second.Found -or $second.Points -ne $rank.Points) { throw '등급 복귀 후 현재점수 연속 판독 불일치' }
    $script:currentRankPoints = [int]$rank.Points
    $script:rankResyncRequired = $false
    $rankPointsLabel.Text = "등급 복귀 후 현재 $($script:currentRankPoints)점 재확인"
    Write-Log "등급 복귀 후 현재점수 재확인: $($script:currentRankPoints)점"
    if ($script:currentRankPoints -ge [int]$targetPointsBox.Value -or
        ($minimumPointsCheck.Checked -and $script:currentRankPoints -le [int]$minimumPointsBox.Value)) {
        Stop-Automation '재확인 점수 조건 도달'
        return $false
    }
    return $true
}

function Register-CompletedMatch($frame) {
    if ($script:resultScreenCounted) { return $true }
    if (-not (Test-RewardScreen $frame)) { return $false }

    $settled = Get-SettledResultFrame $frame
    $frameForAnalysis = $settled.Frame
    if (-not (Test-RewardScreen $frameForAnalysis)) {
        Write-Log '결과 저장 전 화면이 변경되어 경기 집계와 다음 입력을 보류했습니다.'
        return $false
    }
    Set-Status "경기 결과 판정 및 점수 저장 중" ([Drawing.Color]::FromArgb(236, 190, 86))
    $analysis = Get-StableScoreResult $frameForAnalysis
    if (-not (Test-RewardScreen $analysis.Frame)) { return $false }
    $script:resultScreenCounted = $true
    $rankDelta = $null
    if ($script:parkingMode) {
        $reading = Get-StableRankResult $analysis.Frame
        $transition = Get-ParkingTransition $reading $script:currentRankPoints ([int]$targetPointsBox.Value) $minimumPointsCheck.Checked ([int]$minimumPointsBox.Value)
        $script:currentRankPoints = $transition.Current
        $script:rankResyncRequired = $transition.Resync
        if ($transition.Stop) { $script:stopAfterCurrentMatch = $true; $script:requiredStopAfterMatch = $true }
        switch ($transition.Kind) {
            'League' {
                $rankPointsLabel.Text = '챔피언스 아래 등급 · 승점 합산 제외 · 등급 복귀 후 점수 재확인'
                Write-Log '등급 승점 화면: 랭킹 점수 합산을 보류하고 등급 경기를 계속합니다.'
            }
            'Resync' {
                $rankPointsLabel.Text = '챔피언스 점수 복귀 · 다음 경기 전 현재점수 재확인 대기'
                Write-Log '랭킹 점수가 다시 나타났습니다. 기존 누적값을 사용하지 않고 로비에서 재확인합니다.'
            }
            'Unreadable' {
                $rankPointsLabel.Text = '점수 미확인 · 재판독 실패로 중지'
                Write-Log "점수 재판독 후에도 확인할 수 없어 다음 경기를 시작하지 않습니다. ($($reading.Reason))"
                Queue-OperatorReport '주차 점수 판독 실패'
                Queue-DiscordNotification '주차 점수 판독 실패' '연속 재판독에 실패해 중지합니다. 현재점수를 다시 읽어 주세요.'
            }
            default {
                $rankDelta = [int]$reading.Delta
                $rankPointsLabel.Text = "시작 $($script:startingRankPoints)점 | 현재 $($script:currentRankPoints)점 ($('{0:+#;-#;0}' -f $rankDelta))"
                $rankRecord = '{0},{1},{2},{3}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), ($script:sessionMatchCount + 1), $rankDelta, $script:currentRankPoints
                Add-Content -LiteralPath (Join-Path $script:diagnosticDir 'rank_points.csv') -Value $rankRecord -Encoding UTF8
                Write-Log "주차 점수: $rankDelta 점, 현재 $($script:currentRankPoints)점"
                if ($transition.Kind -eq 'Target') {
                    Write-Log "목표점수 $([int]$targetPointsBox.Value)점 도달. 이번 결과를 넘긴 뒤 중지합니다."
                    Queue-DiscordNotification '주차 목표점수 도달' "현재 $($script:currentRankPoints)점"
                } elseif ($transition.Kind -eq 'Minimum') {
                    Write-Log "최저점수 $([int]$minimumPointsBox.Value)점 도달. 이번 결과를 넘긴 뒤 중지합니다."
                    Queue-DiscordNotification '주차 최저점수 도달' "현재 $($script:currentRankPoints)점"
                }
            }
        }
    }
    $result = "unclassified"
    $resultLabel = "미분류"
    $scoreText = "점수 인식 실패"
    if ($analysis.Score.Found) {
        $leftScore = [int]$analysis.Score.LeftScore
        $rightScore = [int]$analysis.Score.RightScore
        $scoreText = "$leftScore`:$rightScore"
        if ($leftScore -gt $rightScore) { $result = "win"; $resultLabel = "승" }
        elseif ($leftScore -eq $rightScore) { $result = "draw"; $resultLabel = "무" }
        else { $result = "loss"; $resultLabel = "패" }
    }

    $today = Get-StatsDay
    if ($script:statsDate -ne $today) {
        if(Test-StatsDay $script:statsDate){Update-DailyStatsEntry}
        $script:statsDate = $today
        $script:todayMatchCount = 0
        $script:todayWinCount = 0
        $script:todayDrawCount = 0
        $script:todayLossCount = 0
        $script:todayUnclassifiedCount = 0
    }

    $script:sessionMatchCount++
    Update-RunMatchLimit
    $script:todayMatchCount++
    $script:totalMatchCount++
    switch ($result) {
        "win" {
            $script:sessionWinCount++; $script:todayWinCount++; $script:totalWinCount++
        }
        "draw" {
            $script:sessionDrawCount++; $script:todayDrawCount++; $script:totalDrawCount++
        }
        "loss" {
            $script:sessionLossCount++; $script:todayLossCount++; $script:totalLossCount++
        }
        default {
            $script:sessionUnclassifiedCount++; $script:todayUnclassifiedCount++; $script:totalUnclassifiedCount++
        }
    }
    Update-DailyStatsEntry
    Save-MatchStats
    $script:dailyDirty=$true
    if($script:settingsTabs -and $script:settingsTabs.SelectedIndex -eq $script:dailyPageIndex){Refresh-DailyStatsView}
    Update-MatchCounter
    $sampleName = Save-ResultSample $analysis.Frame $script:totalMatchCount $result $scoreText
    $pointSampleName = Save-PointSample $analysis.Frame $script:totalMatchCount $result $scoreText
    Update-MatchCounter
    $sampleText = if ([string]::IsNullOrWhiteSpace($sampleName)) { "샘플 저장 실패" } else { "샘플: $sampleName" }
    $pointSampleText = if ([string]::IsNullOrWhiteSpace($pointSampleName)) { "점수 샘플 저장 실패" } else { "점수 샘플: $pointSampleName" }
    Write-Log "경기 완료 집계: $scoreText $resultLabel · $(Get-MatchSummary) · $sampleText · $pointSampleText"
    if (-not $settled.SameWindow) {
        Write-Log "결과 화면 대기 중 FC 창 선택이 해제되어 입력은 보류합니다. 저장된 화면을 확인해 주세요."
    }
    Save-DiagnosticInfo "경기 완료: $scoreText $resultLabel"

    if (($script:sessionMatchCount % 20) -eq 0) {
        Queue-DiscordNotification "FC 감독모드 20판 진행 알림" "$(Get-MatchSummary)`n최근 경기: $scoreText $resultLabel"
    }
    return $true
}

function Save-DiscordSettings {
    $settings = [ordered]@{
        DiscordEnabled = [bool]$script:discordEnabled
        OperatorDiagnostics = [bool]$script:operatorOpt.Checked
        EncryptedWebhook = [string]$script:encryptedWebhook
    }
    $settings | ConvertTo-Json | Set-Content -LiteralPath $script:settingsPath -Encoding UTF8
}

function Load-DiscordSettings {
    if (-not [IO.File]::Exists($script:settingsPath)) { return }
    try {
        $settings = Get-Content -LiteralPath $script:settingsPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $script:discordEnabled = [bool]$settings.DiscordEnabled
        $script:encryptedWebhook = [string]$settings.EncryptedWebhook
        $script:operatorOpt.Checked=[bool]$settings.OperatorDiagnostics
        $savedUrl = Unprotect-DiscordWebhook
        if (Test-DiscordWebhookUrl $savedUrl) {
            $webhookBox.Text = $savedUrl
            $discordCheck.Checked = $script:discordEnabled
            $discordStatus.Text = "암호화하여 저장된 웹훅을 불러왔습니다."
        } else {
            $script:discordEnabled = $false
            $script:encryptedWebhook = ""
            $discordCheck.Checked = $false
            $discordStatus.Text = "저장된 웹훅을 사용할 수 없습니다. 다시 입력해 주세요."
        }
    } catch {
        $script:discordEnabled = $false
        $script:encryptedWebhook = ""
        $discordStatus.Text = "설정을 불러오지 못했습니다. 웹훅을 다시 저장해 주세요."
    }
}

function Start-HelperExitWatcher {
    if (-not $script:discordEnabled -or $script:helperExitMarker) { return }
    $token = [Guid]::NewGuid().ToString('N')
    $process = [Diagnostics.Process]::GetCurrentProcess()
    try {
        $ticks = $process.StartTime.ToUniversalTime().Ticks
        $source = Join-Path $script:appDir 'FCManager.ps1'
        $arguments = '-NoProfile -ExecutionPolicy Bypass -File "{0}" -WatchPid {1} -WatchStartTicks {2} -WatchToken {3}' -f $source, $PID, $ticks, $token
        Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -ArgumentList $arguments -WorkingDirectory $script:appDir -WindowStyle Hidden
        $script:helperExitMarker = Join-Path ([IO.Path]::GetTempPath()) "fc-manager-$token.closed"
    } catch {
        Write-Log '도우미 종료 감시 프로세스를 시작하지 못했습니다.'
    } finally { $process.Dispose() }
}

function Save-DiscordSettingsFromUi {
    $url = $webhookBox.Text.Trim()
    if (-not (Test-DiscordWebhookUrl $url)) {
        throw "Discord 웹훅 주소 형식이 올바르지 않습니다."
    }
    $script:encryptedWebhook = Protect-DiscordWebhook $url
    $script:discordEnabled = [bool]$discordCheck.Checked
    Save-DiscordSettings
    Start-HelperExitWatcher
    $discordStatus.Text = if ($script:discordEnabled) { "알림 사용 중" } else { "저장됨 · 알림 꺼짐" }
    Write-Log "Discord 웹훅 설정을 안전하게 저장했습니다."
}

function Queue-DiscordNotification([string]$titleText, [string]$message, [bool]$force = $false) {
    if (-not $force -and -not $script:discordEnabled) { return }
    $url = Unprotect-DiscordWebhook
    if (-not (Test-DiscordWebhookUrl $url)) {
        Write-Log "Discord 알림을 보내지 못했습니다: 저장된 웹훅을 확인해 주세요."
        return
    }
    $item = [PSCustomObject]@{
        Url = $url
        Title = $titleText
        Message = $message
        Attempt = 0
        DueAt = [DateTime]::Now
    }
    $script:notificationQueue.Enqueue($item)
}

function Queue-OperatorReport([string]$reason,[string]$capture) {
    if (-not $script:operatorOpt.Checked) { return }
    if (-not $script:remoteDevice) { Write-Log '운영자 오류 전송 대기 불가 · Discord 계정을 먼저 연결하세요.'; return }
    try {
        Save-DiagnosticInfo $reason
        if ($script:operatorQueue.Count -ge 4) { Write-Log '운영자 오류 전송 대기열이 가득 찼습니다.'; return }
        $infoPath=Join-Path $script:diagnosticDir '진단정보.txt'
        $parts=@("FC Manager $script:appVersion · $reason")
        if ([IO.File]::Exists($infoPath)) { $parts += Get-Content -LiteralPath $infoPath -Encoding UTF8 }
        if ([IO.File]::Exists($script:logPath)) { $parts += Get-Content -LiteralPath $script:logPath -Tail 40 -Encoding UTF8 }
        $text=($parts -join "`n") -replace 'https?://[^\s]+','[URL]' -replace '(?i)Bearer\s+\S+','[인증 정보]'
        if ($text.Length -gt 17500) { $text=$text.Substring(0,17500) }
        $payload=@{id=[guid]::NewGuid().ToString('N');text=$text}
        if ($capture -and [IO.File]::Exists($capture) -and (Get-Item -LiteralPath $capture).Length -le 2MB) {
            $payload.png=[Convert]::ToBase64String([IO.File]::ReadAllBytes($capture))
        }
        $script:operatorQueue.Enqueue(@{Device=$script:remoteDevice;Payload=$payload;Attempts=0;Due=[datetime]::UtcNow})
    } catch { Write-Log '운영자 오류 보고서 준비 실패' }
}

function Update-OperatorReports {
    try {
        $active=$script:operatorActive
        if ($active) {
            if (-not $active.Task.IsCompleted) { return }
            $script:operatorActive=$null
            $code=0
            try {
                $reply=$active.Task.GetAwaiter().GetResult()
                try { $code=[int]$reply.StatusCode } finally { $reply.Dispose() }
            } catch {} finally { $active.Request.Dispose() }
            if ($code -eq 200) { Write-Log '운영자 Discord에 오류 자료를 전송했습니다.' }
            elseif (($code -in 0,429,500,502,504) -and $active.Item.Attempts -lt 3 -and $script:operatorOpt.Checked) {
                $active.Item.Due=[datetime]::UtcNow.AddSeconds(16*$active.Item.Attempts)
                $script:operatorQueue.Enqueue($active.Item)
            } else { Write-Log "운영자 오류 자료 전송 실패 · HTTP $code (서버 웹훅 및 계정 연결 확인)" }
        }
        if (-not $script:operatorOpt.Checked -or -not $script:remoteDevice) { $script:operatorQueue.Clear(); return }
        if ($script:operatorQueue.Count -eq 0) { return }
        $item=$script:operatorQueue.Peek()
        if ($item.Due -gt [datetime]::UtcNow) { return }
        [void]$script:operatorQueue.Dequeue()
        if ($item.Device.token -cne $script:remoteDevice.token -or $item.Device.origin -ne $script:remoteDevice.origin) { return }
        $request=[Net.Http.HttpRequestMessage]::new([Net.Http.HttpMethod]::Post,($item.Device.origin+'/diagnostics'))
        try {
            $request.Headers.Authorization=[Net.Http.Headers.AuthenticationHeaderValue]::new('Bearer',$item.Device.token)
            $request.Content=[Net.Http.StringContent]::new(($item.Payload | ConvertTo-Json -Compress),[Text.Encoding]::UTF8,'application/json')
            $item.Attempts++
            $script:operatorActive=@{Request=$request;Task=$script:operatorHttp.SendAsync($request);Item=$item}
        } catch { $request.Dispose(); throw }
    } catch { Write-Log '운영자 오류 전송 연결 실패' }
}

function Process-DiscordQueue {
    if ($null -ne $script:activeNotification) {
        $active = $script:activeNotification
        if (-not $active.Task.IsCompleted) { return }
        $success = $false
        $failure = ""
        try {
            if ($active.Task.IsCanceled) {
                $failure = "전송 시간 초과"
            } elseif ($active.Task.IsFaulted) {
                $failure = $active.Task.Exception.GetBaseException().Message
            } else {
                $response = $active.Task.Result
                $success = $response.IsSuccessStatusCode
                if (-not $success) { $failure = "HTTP $([int]$response.StatusCode)" }
                $response.Dispose()
            }
        } catch {
            $failure = $_.Exception.Message
        } finally {
            $active.Content.Dispose()
        }

        if ($success) {
            Write-Log "Discord 알림을 보냈습니다: $($active.Item.Title)"
            $discordStatus.Text = "최근 알림 전송 성공: $(Get-Date -Format 'HH:mm:ss')"
        } else {
            $active.Item.Attempt++
            if ($active.Item.Attempt -lt 3) {
                $active.Item.DueAt = [DateTime]::Now.AddSeconds([Math]::Pow(2, $active.Item.Attempt))
                $script:notificationQueue.Enqueue($active.Item)
                Write-Log "Discord 알림 전송 재시도 $($active.Item.Attempt)/2"
            } else {
                if ($failure.Length -gt 120) { $failure = $failure.Substring(0, 120) }
                Write-Log "Discord 알림 전송 실패: $failure"
                $discordStatus.Text = "최근 알림 전송 실패 · 웹훅/인터넷 확인"
            }
        }
        $script:activeNotification = $null
    }

    if ($null -eq $script:activeNotification -and $script:notificationQueue.Count -gt 0) {
        $next = $script:notificationQueue.Peek()
        if ([DateTime]::Now -lt $next.DueAt) { return }
        [void]$script:notificationQueue.Dequeue()
        $contentText = "**$($next.Title)**`n$($next.Message)`n시간: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
        if ($contentText.Length -gt 1900) { $contentText = $contentText.Substring(0, 1900) }
        $payload = @{ content = $contentText; username = "FC Manager Assistant" } | ConvertTo-Json -Compress
        $content = [System.Net.Http.StringContent]::new($payload, [Text.Encoding]::UTF8, "application/json")
        $task = $script:httpClient.PostAsync($next.Url, $content)
        $script:activeNotification = [PSCustomObject]@{ Item = $next; Task = $task; Content = $content }
    }
}

function Send-StuckAlert([string]$reason) {
    $now = [DateTime]::Now
    if (($now - $script:lastStuckAlertAt).TotalMinutes -lt 10) { return }
    $script:lastStuckAlertAt = $now
    $script:stuckAlertActive = $true
    Queue-DiscordNotification "FC 감독모드 멈춤 감지" "$reason`n$(Get-MatchSummary)`nPC에서 FC 온라인 화면과 도우미 로그를 확인해 주세요."
    Write-Log "멈춤 가능성을 감지했습니다: $reason"
    Save-DiagnosticInfo "멈춤 감지: $reason"
    # Preserve the actual screen that failed before the user has to intervene.
    try {
        $foreground = Get-ForegroundInfo
        if ($foreground.Allowed) {
            $stuckFrame = Get-FCFrame $foreground.Handle
            if ($null -ne $stuckFrame) {
                $snapshot = [FCTemplateMatcher]::ToBitmap($stuckFrame.Buffer)
                if ($null -ne $snapshot) {
                    try {
                        $snapshotPath = Join-Path $script:captureDir ("stuck_{0}.png" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
                        $snapshot.Save($snapshotPath, [Drawing.Imaging.ImageFormat]::Png)
                        Write-Log "멈춤 당시 화면을 저장했습니다: $([IO.Path]::GetFileName($snapshotPath))"
                    } finally { $snapshot.Dispose() }
                }
            }
        }
    } catch {
        Write-Log "멈춤 화면 저장 실패: $($_.Exception.Message)"
    }
    $reportImage=$null
    if ($snapshotPath -and $foreground.Process -eq 'fczf' -and [FCNative]::GetForegroundWindow() -eq $foreground.Handle) {
        $reportImage=$snapshotPath
    }
    Queue-OperatorReport "멈춤 감지 · $reason" $reportImage
}

function Mark-AutomationProgress([string]$fileName, [string]$label) {
    $wasStuck = $script:stuckAlertActive
    $script:lastProgressAt = [DateTime]::Now

    if ($script:lastRecognizedFile -eq $fileName) {
        $script:sameScreenActionCount++
    } else {
        $script:lastRecognizedFile = $fileName
        $script:sameScreenActionCount = 1
        $script:sameScreenSince = [DateTime]::Now
        $script:stuckAlertActive = $false
        if ($wasStuck) {
            Queue-DiscordNotification "FC 감독모드 정상 작동 재개" "새 화면 '$label'을 인식해 자동 진행이 다시 작동했습니다.`n$(Get-MatchSummary)"
        }
    }

    if ($script:sameScreenActionCount -ge 3) {
        if ($fileName -in @("s.png", "skip.png", "esc.png")) {
            if (([DateTime]::Now - $script:lastVisualChangeAt).TotalMinutes -ge 3) {
                Send-StuckAlert "경기 진행 안내가 반복되는 동안 FC 경기 화면이 3분 이상 변하지 않았습니다."
            }
        } elseif (([DateTime]::Now - $script:sameScreenSince).TotalSeconds -ge 15) {
            Send-StuckAlert "'$label' 화면에서 같은 동작이 반복되고 15초 이상 화면이 바뀌지 않았습니다."
        }
    }
}

function Show-TopmostError([string]$message, [string]$titleText = "FC 감독모드 도우미 오류") {
    $previousTopMost = $form.TopMost
    try {
        if ($form.WindowState -eq [System.Windows.Forms.FormWindowState]::Minimized) {
            $form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
        }
        $form.Show()
        $form.TopMost = $true
        $form.BringToFront()
        $form.Activate()
        [System.Windows.Forms.MessageBox]::Show(
            $form,
            $message,
            $titleText,
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    } finally {
        $form.TopMost = $previousTopMost
    }
}

function Get-ForegroundInfo {
    $handle = [FCNative]::GetForegroundWindow()
    if ($handle -eq [IntPtr]::Zero) {
        return [PSCustomObject]@{ Handle = $handle; Allowed = $false; Title = "창 없음"; Process = "" }
    }
    $titleText = [FCNative]::GetTitle($handle)
    $processName = [FCNative]::GetProcessName($handle)
    $allowed = ($processName -ieq "fczf") -or ($titleText -like "*FC ONLINE*")
    return [PSCustomObject]@{ Handle = $handle; Allowed = $allowed; Title = $titleText; Process = $processName }
}

function Test-GameProcessPresent {
    $processes = [Diagnostics.Process]::GetProcessesByName('fczf')
    try { return ($processes.Count -gt 0) }
    finally { foreach ($process in $processes) { $process.Dispose() } }
}

function Update-GamePresence($state, [bool]$present, [datetime]$utc) {
    if ($present) {
        $state.Observed = $true
        $state.MissingSince = $null
        return ''
    }
    if (-not $state.Observed) { return '' }
    if ($null -eq $state.MissingSince) { $state.MissingSince = $utc }
    if (($utc - $state.MissingSince).TotalSeconds -lt 3) { return '' }
    $state.Observed = $false
    $state.MissingSince = $null
    return 'Exited'
}

function Get-FCWindowInfo {
    foreach ($process in @(Get-Process -Name "fczf" -ErrorAction SilentlyContinue)) {
        try {
            if ($process.MainWindowHandle -ne [IntPtr]::Zero) {
                return [PSCustomObject]@{
                    Handle = $process.MainWindowHandle
                    Allowed = $true
                    Title = $process.MainWindowTitle
                    Process = $process.ProcessName
                }
            }
        } catch {}
    }
    return $null
}

function Get-FCFrame([IntPtr]$handle) {
    $rect = New-Object FCNative+RECT
    if (-not [FCNative]::GetWindowRect($handle, [ref]$rect)) { return $null }
    $width = $rect.Right - $rect.Left
    $height = $rect.Bottom - $rect.Top
    if ($width -lt 640 -or $height -lt 360) { return $null }

    $bitmap = New-Object Drawing.Bitmap($width, $height)
    $graphics = [Drawing.Graphics]::FromImage($bitmap)
    try {
        $graphics.CopyFromScreen($rect.Left, $rect.Top, 0, 0, (New-Object Drawing.Size($width, $height)))
        $buffer = [FCTemplateMatcher]::FromBitmap($bitmap)
        return [PSCustomObject]@{ Rect = $rect; Buffer = $buffer; Handle = $handle }
    } finally {
        $graphics.Dispose()
        $bitmap.Dispose()
    }
}

function Initialize-ScreenOcr {
    if ($null -ne $script:rankOcrAwaiter) { return }
    Add-Type -AssemblyName System.Runtime.WindowsRuntime
    $null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
    $null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
    $null = [Windows.Media.Ocr.OcrResult, Windows.Foundation, ContentType = WindowsRuntime]
    $null = [Windows.Foundation.IAsyncOperation`1, Windows.Foundation, ContentType = WindowsRuntime]
    $null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Foundation, ContentType = WindowsRuntime]
    $null = [Windows.Storage.Streams.IRandomAccessStream, Windows.Foundation, ContentType = WindowsRuntime]
    $null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType = WindowsRuntime]
    $null = [Windows.Globalization.Language, Windows.Globalization, ContentType = WindowsRuntime]
    $script:rankOcrAwaiter = [WindowsRuntimeSystemExtensions].GetMember('GetAwaiter').Where({
        $PSItem.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
    }, 'First')[0]
    if ($null -eq $script:rankOcrAwaiter) { throw 'Windows OCR 비동기 호출을 준비하지 못했습니다.' }
}

function Initialize-RankOcr {
    if ($null -ne $script:rankOcrEngine) { return }
    Initialize-ScreenOcr
    $language = [Windows.Globalization.Language]::new('en-US')
    $script:rankOcrEngine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($language)
    if ($null -eq $script:rankOcrEngine) {
        $script:rankOcrEngine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
    }
    if ($null -eq $script:rankOcrEngine) { throw 'Windows OCR 언어를 사용할 수 없습니다.' }
}

function Await-RankOcr($operation, [Type]$resultType) {
    return $script:rankOcrAwaiter.MakeGenericMethod($resultType).Invoke($null, @($operation)).GetResult()
}

function Read-ScreenOcr([string]$imagePath, $engine) {
    $file = Await-RankOcr ([Windows.Storage.StorageFile]::GetFileFromPathAsync($imagePath)) ([Windows.Storage.StorageFile])
    $stream = Await-RankOcr ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
    try {
        $decoder = Await-RankOcr ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
        $softwareBitmap = Await-RankOcr ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
        try {
            $ocr = Await-RankOcr ($engine.RecognizeAsync($softwareBitmap)) ([Windows.Media.Ocr.OcrResult])
        } finally { if ($null -ne $softwareBitmap) { $softwareBitmap.Dispose() } }
    } finally { if ($null -ne $stream) { $stream.Dispose() } }
    return $ocr
}

function Get-TierChangeOutcome([string[]]$lines) {
    $result = ''
    foreach ($line in $lines) {
        $text = $line -replace '[\s.!。·「」\[\]()]', ''
        $outcome = if ($text -match '^(?:등급)?(승급|승격|강등|잔류)(?:성공|확정|완료)?$') {
            $Matches[1]
        } elseif ($text -match '^(?:(?:슈퍼챔피언스|챔피언스|슈퍼챌린저|챌린저|월드클래스|프로|세미프로|유망주|아마추어)(?:[1-3]부)?(?:등급)?(?:으)?로)?(승급|승격|강등|잔류)(?:을)?(?:축하합니다|했습니다|하였습니다|하셨습니다|되었습니다|됐습니다|되셨습니다)$') {
            $Matches[1]
        }
        if ($outcome -eq '승격') { $outcome = '승급' }
        if ($outcome) {
            if ($result -and $result -ne $outcome) { return '' }
            $result = $outcome
        }
    }
    return $result
}

function Read-TierChangeOutcome($frame) {
    if ($script:tierOcrUnavailable) { return '' }
    if ($null -eq $script:tierOcrEngine) {
        Initialize-ScreenOcr
        $language = [Windows.Globalization.Language]::new('ko-KR')
        $script:tierOcrEngine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($language)
        if ($null -eq $script:tierOcrEngine) {
            $script:tierOcrUnavailable = $true
            Write-Log '승급·강등 알림을 사용하려면 Windows 한국어 OCR 기능을 설치해 주세요.'
            Queue-DiscordNotification '승급·강등 OCR 설정 필요' 'Windows 설정에서 한국어 광학 문자 인식(OCR)을 설치한 뒤 도우미를 다시 실행해 주세요.' 
            return ''
        }
    }

    $bitmap = [FCTemplateMatcher]::ToBitmap($frame.Buffer)
    if ($null -eq $bitmap) { return '' }
    $imagePath = $null
    try {
        # Read the result content without the game chrome or confirmation button.
        $cropRect = [Drawing.Rectangle]::new(
            [int]($bitmap.Width * 0.15), [int]($bitmap.Height * 0.19),
            [int]($bitmap.Width * 0.70), [int]($bitmap.Height * 0.66))
        $crop = $bitmap.Clone($cropRect, [Drawing.Imaging.PixelFormat]::Format32bppArgb)
        try {
            $width = [Math]::Min(2000, 2 * $crop.Width)
            $height = [int]($crop.Height * $width / $crop.Width)
            $enlarged = [Drawing.Bitmap]::new($crop, $width, $height)
            try {
                $imagePath = Join-Path ([IO.Path]::GetTempPath()) ("fc-rank-{0:N}.png" -f [Guid]::NewGuid())
                $enlarged.Save($imagePath, [Drawing.Imaging.ImageFormat]::Png)
            } finally { $enlarged.Dispose() }
        } finally { $crop.Dispose() }
        $ocr = Read-ScreenOcr $imagePath $script:tierOcrEngine
        return Get-TierChangeOutcome @($ocr.Lines | ForEach-Object { $_.Text })
    } finally {
        $bitmap.Dispose()
        if ($imagePath) { Remove-Item -LiteralPath $imagePath -ErrorAction SilentlyContinue }
    }
}

function Save-UnclassifiedTierFrame($frame) {
    if ($script:tierDiagnosticMatchCount -eq $script:sessionMatchCount -or $script:tierDiagnosticCount -ge 5) { return }
    $script:tierDiagnosticMatchCount = $script:sessionMatchCount
    $script:tierDiagnosticCount++
    try {
        $bitmap = [FCTemplateMatcher]::ToBitmap($frame.Buffer)
        if ($null -eq $bitmap) { return }
        try {
            $name = 'tier_result_unknown_{0}.png' -f (Get-Date -Format 'yyyyMMdd_HHmmss_fff')
            $bitmap.Save((Join-Path $script:captureDir $name), [Drawing.Imaging.ImageFormat]::Png)
            Write-Log "등급 결과 미분류 · 진단 화면 저장: $name"
        } finally { $bitmap.Dispose() }
    } catch { Write-Log '등급 결과 진단 화면을 저장하지 못했습니다.' }
}

function Send-TierChangeNotice([string]$outcome) {
    if ($outcome -notin @('승급','강등') -or $script:tierNoticeMatchCount -eq $script:sessionMatchCount) { return }
    $script:tierNoticeMatchCount = $script:sessionMatchCount
    Queue-DiscordNotification "감독모드 $outcome" "$outcome 결과가 확인되었습니다.`n$(Get-MatchSummary)"
}

function Read-StartingRankPoints($frame) {
    $notFound = [PSCustomObject]@{ Found = $false; Points = 0; Reason = '챔피언스 감독 랭킹 화면이 아닙니다.' }
    $bitmap = [FCTemplateMatcher]::ToBitmap($frame.Buffer)
    if ($null -eq $bitmap) { return $notFound }
    try {
        $normalized = New-Object Drawing.Bitmap(1296, ([int][Math]::Round($bitmap.Height * 1296.0 / $bitmap.Width)))
        try {
            $graphics = [Drawing.Graphics]::FromImage($normalized)
            try { $graphics.DrawImage($bitmap, 0, 0, $normalized.Width, $normalized.Height) }
            finally { $graphics.Dispose() }
            if ($normalized.Height -lt 720) { return $notFound }
            # Official-match lobby tab and the purple Champions ranking banner.
            $tab = $normalized.GetPixel(250, 135)
            $banner = $normalized.GetPixel(500, 245)
            if ($tab.R -lt 225 -or $tab.G -lt 225 -or $tab.B -lt 225 -or
                $banner.B -lt ($banner.R + 25) -or $banner.B -lt ($banner.G + 25)) {
                return $notFound
            }
            $crop = $normalized.Clone((New-Object Drawing.Rectangle(235, 274, 120, 56)), [Drawing.Imaging.PixelFormat]::Format32bppArgb)
            try {
                $enlarged = New-Object Drawing.Bitmap($crop, (New-Object Drawing.Size(480, 224)))
                try {
                    $rankPath = Join-Path $script:captureDir ('rank_start_{0}.png' -f (Get-Date -Format 'yyyyMMdd_HHmmss_fff'))
                    $enlarged.Save($rankPath, [Drawing.Imaging.ImageFormat]::Png)
                } finally { $enlarged.Dispose() }
            } finally { $crop.Dispose() }
        } finally { $normalized.Dispose() }
    } finally { $bitmap.Dispose() }

    Initialize-RankOcr
    $ocr = Read-ScreenOcr $rankPath $script:rankOcrEngine
    $matches = [regex]::Matches($ocr.Text, '(?<!\d)(?:\d,\d{3}|\d{4})(?!\d)')
    if ($matches.Count -ne 1) {
        return [PSCustomObject]@{ Found = $false; Points = 0; Reason = "시작점수 숫자 인식 실패: $($ocr.Text)" }
    }
    $points = [int]($matches[0].Value -replace ',', '')
    if ($points -lt 1000 -or $points -gt 9999) {
        return [PSCustomObject]@{ Found = $false; Points = 0; Reason = '챔피언스 점수 범위를 벗어났습니다.' }
    }
    return [PSCustomObject]@{ Found = $true; Points = $points; Reason = '확인' }
}

function Invoke-KeyTap([System.UInt16]$scanCode, [int]$holdMilliseconds = 65) {
    if (-not [FCNative]::SendScanCode($scanCode, $false)) {
        throw "키 누르기 입력에 실패했습니다. Windows 오류: $([FCNative]::LastInputError)"
    }
    Start-Sleep -Milliseconds ([Math]::Max(50, $holdMilliseconds))
    if (-not [FCNative]::SendScanCode($scanCode, $true)) {
        throw "키 떼기 입력에 실패했습니다. Windows 오류: $([FCNative]::LastInputError)"
    }
}

function Invoke-ReliableSTap {
    # FC occasionally ignores a very short scan-code-only S press on SKIP
    # screens. Hold it longer, then send one virtual-key S pulse as a fallback.
    Invoke-KeyTap 0x1F 140
    Start-Sleep -Milliseconds 80
    if (-not [FCNative]::SendVirtualKey(0x53, $false)) {
        throw "S 보강 입력 누르기에 실패했습니다. Windows 오류: $([FCNative]::LastInputError)"
    }
    Start-Sleep -Milliseconds 100
    if (-not [FCNative]::SendVirtualKey(0x53, $true)) {
        throw "S 보강 입력 떼기에 실패했습니다. Windows 오류: $([FCNative]::LastInputError)"
    }
}

function Test-RewardScreen($frame) { return [FCContextScreens]::IsReward($frame.Buffer) }

function Find-ContextAction($frame) {
    $spec = if ([FCContextScreens]::IsNetworkError($frame.Buffer)) {
        @{ Asset='network_confirm.png'; File='network_confirm.png'; Label='연결·게임 오류 확인'; Action='click'; X1=0.49; Y1=0.57; X2=0.64; Y2=0.65 }
    } elseif ([FCContextScreens]::IsLevelUp($frame.Buffer)) {
        @{ Asset='levelup_confirm.png'; File='levelup_confirm.png'; Label='레벨업 보상 확인'; Action='click'; X1=0.75; Y1=0.90; X2=0.90; Y2=0.99 }
    } elseif (Test-RewardScreen $frame) {
        @{ Asset='reward_next.png'; File='space_3.png'; Label='경기 보상 다음'; Action='space'; X1=0.74; Y1=0.90; X2=0.89; Y2=0.99 }
    } else { return $null }
    if ($script:lastTemplateActions.ContainsKey($spec.File) -and
        ([DateTime]::Now - [DateTime]$script:lastTemplateActions[$spec.File]).TotalMilliseconds -lt 1800) { return $null }
    if ($null -eq $script:contextBuffers) { $script:contextBuffers=@{} }
    if (-not $script:contextBuffers.ContainsKey($spec.Asset)) {
        $bitmap=[Drawing.Bitmap]::new((Join-Path $script:templateDir $spec.Asset))
        try { $script:contextBuffers[$spec.Asset]=[FCTemplateMatcher]::FromBitmap($bitmap) } finally { $bitmap.Dispose() }
    }
    $buffer=$script:contextBuffers[$spec.Asset]
    $screenBuffer=[FCContextScreens]::NormalizeGreen($frame.Buffer)
    $buttonBuffer=[FCContextScreens]::NormalizeGreen($buffer)
    $match=[FCTemplateMatcher]::FindMultiScale($screenBuffer,$buttonBuffer,$spec.X1,$spec.Y1,$spec.X2,$spec.Y2,5.0,([double[]]@([double]$frame.Buffer.Width/1296.0)),$false,$false)
    if (-not $match.Found) { return $null }
    $definition=[PSCustomObject]@{File=$spec.File;Action=$spec.Action;Label=$spec.Label;Cooldown=1800}
    return [PSCustomObject]@{Template=[PSCustomObject]@{Definition=$definition;Buffer=$buffer};Match=$match;Source='context'}
}

function Find-TemplateAction($frame) {
    $context = Find-ContextAction $frame
    if ($null -ne $context) { return $context }
    # Never let generic confirm/proceed templates skip a result or dismiss an
    # unrecognized network error. Context actions alone handle these screens.
    if ((Test-RewardScreen $frame) -or [FCContextScreens]::IsLevelUp($frame.Buffer) -or
        [FCContextScreens]::IsNetworkError($frame.Buffer)) { return $null }

    # Uniform confirmation is checked first because the same screen also
    # contains the opponent's '준비 완료' indicator.
    # ESC is allowed only when both the bottom-right key icon and its adjacent
    # SKIP caption are present. A lone ESC icon may open the settings menu.
    $priority = @("tier_popup.png", "tier_result.png", "space_2.png", "space_1.png", "space_3.png", "click_1.png", "click_2.png",
                  "click_3.png", "click_4.png", "skip.png", "s.png", "esc.png", "client.png")

    foreach ($fileName in $priority) {
        if ($fileName -eq 'space_3.png' -and -not (Test-RewardScreen $frame)) { continue }

        $lowTemplate = $script:templates | Where-Object { $_.Definition.File -eq $fileName } | Select-Object -First 1
        if ($null -eq $lowTemplate) { continue }

        $definition = $lowTemplate.Definition
        if ($fileName -eq "tier_popup.png" -and -not [FCRewardLabels]::IsTierPopup($frame.Buffer)) { continue }
        if ($script:lastTemplateActions.ContainsKey($definition.File)) {
            $lastTime = [DateTime]$script:lastTemplateActions[$definition.File]
            if (([DateTime]::Now - $lastTime).TotalMilliseconds -lt $definition.Cooldown) {
                continue
            }
        }

        # Prefer the supplied 2560x1440 source images in scaled environments.
        # They retain the text edges that were lost when the 1280 templates
        # were enlarged and prevent a green uniform screen from looking like
        # the green result-screen 'Next' button.
        $widthScale = [double]$frame.Buffer.Width / 1282.0
        $scaledMode = [Math]::Abs($widthScale - 1.0) -gt 0.08
        $template = $lowTemplate
        $templateSource = "1280"
        $effectiveThreshold = [double]$definition.Threshold

        if ($fileName -like "tier_*") {
            [double[]]$scaleCandidates = @([double]$frame.Buffer.Width / 1296.0)
            if ($scaledMode) { $effectiveThreshold = [double]$definition.ScaledThreshold }
        } elseif ($scaledMode -and $definition.File -ne "click_1.png") {
            $hdTemplate = $script:hdTemplates | Where-Object { $_.Definition.File -eq $fileName } | Select-Object -First 1
            if ($null -ne $hdTemplate) {
                $template = $hdTemplate
                $templateSource = "2560"
                [double[]]$scaleCandidates = @([double]$frame.Buffer.Width / 2560.0)
            } else {
                [double[]]$scaleCandidates = @($widthScale)
            }
            $effectiveThreshold = [double]$definition.ScaledThreshold
        } elseif ($definition.File -eq "click_1.png") {
            # The rank lobby can also be borderless, so keep height and native
            # size as safe fallbacks for this tightly-scoped bottom-right item.
            $heightScale = [double]$frame.Buffer.Height / 752.0
            [double[]]$scaleCandidates = @($widthScale, $heightScale, 1.0)
            if ($scaledMode) { $effectiveThreshold = [double]$definition.ScaledThreshold }
        } else {
            # FHD/QHD does not always produce the exact same outer window
            # size even when FC is set to 1280x720. Windows title bars and
            # borders observed in diagnostics ranged around 1282x752 to
            # 1296x759, so compare the small width/height corrections too.
            $heightScale = [double]$frame.Buffer.Height / 752.0
            [double[]]$scaleCandidates = @($widthScale, $heightScale, 1.0)
        }
        $screenBuffer = $frame.Buffer
        $templateBuffer = $template.Buffer
        if ($fileName -eq 'tier_result.png') {
            # Rank confirmation shares the green hover effect with reward buttons.
            $screenBuffer = [FCContextScreens]::NormalizeGreen($screenBuffer)
            $templateBuffer = [FCContextScreens]::NormalizeGreen($templateBuffer)
        }
        $match = [FCTemplateMatcher]::FindMultiScale(
            $screenBuffer,
            $templateBuffer,
            $definition.X1,
            $definition.Y1,
            $definition.X2,
            $definition.Y2,
            $effectiveThreshold,
            $scaleCandidates,
            ($fileName -eq "s.png"),
            ($fileName -eq "esc.png")
        )
        if (-not $match.Found) { continue }
        if ($fileName -like 'tier_*') {
            $front = Get-ForegroundInfo
            if ($front.Process -ne 'fczf' -or $front.Handle -ne $frame.Handle) { return $null }
            $isResult = $fileName -eq 'tier_result.png'
            $hasResultHeader = $isResult -and [FCRewardLabels]::IsTierResult($frame.Buffer)
            $outcome = ''
            if ($script:discordEnabled -or ($isResult -and -not $hasResultHeader)) {
                try { $outcome = Read-TierChangeOutcome $frame }
                catch { Write-Log "등급 결과 판독 실패: $($_.Exception.Message)" }
            }
            if ($isResult -and -not ($hasResultHeader -or $outcome)) { continue }
            if ($script:discordEnabled) {
                Send-TierChangeNotice $outcome
                if ($hasResultHeader -and -not $outcome -and -not $script:tierOcrUnavailable) {
                    Save-UnclassifiedTierFrame $frame
                }
            }
        }
        return [PSCustomObject]@{ Template = $template; Match = $match; Source = $templateSource }
    }
    return $null
}

function Invoke-TemplateAction($recognized, $frame) {
    $definition = $recognized.Template.Definition
    $match = $recognized.Match
    if ($definition.File -eq 'click_1.png' -and $script:parkingMode -and $script:rankResyncRequired) {
        if (-not (Sync-ParkingRank $frame)) { return }
        # The OCR wait may have changed focus; never click another window.
        $verified = Get-ForegroundInfo
        if (-not $verified.Allowed -or $verified.Handle -ne $frame.Handle) { return }
    }
    $actionText = ""
    $stopAfterThisAction = $false

    # Recognition can take long enough for the user to switch windows.
    $foreground = Get-ForegroundInfo
    if (($onlyFcCheck.Checked -or $definition.File -like 'tier_*') -and
        (-not $foreground.Allowed -or $foreground.Handle -ne $frame.Handle)) {
        $script:paused = $true
        $script:resumeStableSince = $null
        return
    }


    if ($definition.File -ne "space_3.png" -and $definition.Action -ne "none") {
        $script:resultScreenCounted = $false
    }

    switch ($definition.Action) {
        "click" {
            $matchedWidth = if ($match.MatchWidth -gt 0) { $match.MatchWidth } else { $recognized.Template.Buffer.Width }
            $matchedHeight = if ($match.MatchHeight -gt 0) { $match.MatchHeight } else { $recognized.Template.Buffer.Height }
            $screenX = $frame.Rect.Left + $match.X + [int]($matchedWidth / 2)
            $screenY = $frame.Rect.Top + $match.Y + [int]($matchedHeight / 2)
            if (-not [FCNative]::SendLeftClick($screenX, $screenY)) {
                throw "마우스 클릭 입력에 실패했습니다. Windows 오류: $([FCNative]::LastInputError)"
            }
            if ([FCNative]::LastClickUsedFallback) {
                $actionText = "클릭(호환 입력)"
                Write-Log "기본 마우스 입력이 거부되어 호환 입력으로 다시 시도했습니다."
            } else {
                $actionText = "클릭"
            }
        }
        "space" {
            if ($definition.File -eq "space_3.png") {
                if (-not (Register-CompletedMatch $frame)) { return }
                $stopAfterThisAction = $script:stopAfterCurrentMatch
                $infoAfterCapture = Get-ForegroundInfo
                if ($onlyFcCheck.Checked -and
                    (-not $infoAfterCapture.Allowed -or $infoAfterCapture.Handle -ne $frame.Handle)) {
                    $script:paused = $true
                    $script:resumeStableSince = $null
                    $windowLabel.Text = "점수 화면 저장 완료 · FC 창 복귀 대기"
                    Write-Log "점수 화면 저장 중 창이 바뀌어 Space 입력을 안전하게 보류했습니다."
                    return
                }
            }
            Invoke-KeyTap 0x39
            $actionText = "Space"
        }
        "esc" {
            Invoke-KeyTap 0x01
            $actionText = "Esc"
        }
        "s" {
            Invoke-ReliableSTap
            $actionText = "S 보강 입력"
        }
        "none" {
            $actionText = "입력 없음"
        }
    }

    $script:lastTemplateActions[$definition.File] = [DateTime]::Now
    if ($definition.Action -ne "none") {
        Mark-AutomationProgress $definition.File $definition.Label
        $script:actionCount++
        Update-Counters
    }
    $windowLabel.Text = "인식 화면: $($definition.Label) · 동작: $actionText"
    $sourceText = if ([string]::IsNullOrWhiteSpace($recognized.Source)) { "1280" } else { $recognized.Source }
    Write-Log ("화면 인식[{0}]: {1} -> {2} (차이 {3:N1})" -f $sourceText, $definition.File, $actionText, $match.MeanDifference)

    if ($stopAfterThisAction) {
        $reason = if ((Get-RunMatchProgress).Reached) { "설정 $($script:runMatchLimit)판 완료" } else { '이번 판 완료' }
        Stop-Automation $reason
        Set-Status "이번 판 완료 · 자동 진행 중지" ([Drawing.Color]::FromArgb(150, 156, 166))
        $windowLabel.Text = "경기 결과 저장 및 다음 화면 이동 완료"
        Write-Log "예약한 이번 경기를 완료하여 자동 진행을 중지했습니다."
    }
}

function Set-Status([string]$text, [Drawing.Color]$color) {
    $statusLabel.Text = $text
    $statusDot.ForeColor = $color
}

function Update-Counters {
    $counterLabel.Text = "화면 동작: $($script:actionCount)회   |   자동 일시정지: $($script:pauseCount)회"
}

function Get-ClubClientFrame($handle) {
    $rect=New-Object FCNative+RECT
    $origin=New-Object FCNative+POINT
    if(-not [FCNative]::GetClientRect($handle,[ref]$rect) -or
       -not [FCNative]::ClientToScreen($handle,[ref]$origin)){return}
    $w=$rect.Right;$h=$rect.Bottom
    if($w -lt 640 -or [Math]::Abs($w/[double][Math]::Max(1,$h)-16/9) -gt 0.035){return}
    $bmp=[Drawing.Bitmap]::new($w,$h)
    try {
        $g=[Drawing.Graphics]::FromImage($bmp)
        try{$g.CopyFromScreen($origin.X,$origin.Y,0,0,$bmp.Size)}finally{$g.Dispose()}
        $source=[FCTemplateMatcher]::FromBitmap($bmp)
        $frame=[PSCustomObject]@{Buffer=[FCTemplateMatcher]::Resize($source,960.0/$w);Origin=$origin;Width=$w;Height=$h}
        return $frame
    } finally {$bmp.Dispose()}
}

function Find-ClubMarker($buffer,[string]$name) {
    return (Test-ClientMarker $buffer "club_$name" $script:clubRegions[$name])
}

function Test-ClientMarker($buffer,[string]$name,$r,[int]$margin = 3) {
    if($null -eq $script:clientMarkers){$script:clientMarkers=@{}}
    if(-not $script:clientMarkers.ContainsKey($name)){
        $b=[Drawing.Bitmap]::new((Join-Path $script:templateDir "$name.png"))
        try{$script:clientMarkers[$name]=[FCTemplateMatcher]::FromBitmap($b)}finally{$b.Dispose()}
    }
    $t=$script:clientMarkers[$name]
    $m=[FCTemplateMatcher]::Find($buffer,$t,($r[0]-$margin)/960,($r[1]-$margin)/540,($r[0]+$t.Width+$margin)/960,($r[1]+$t.Height+$margin)/540,[double]$r[2])
    return $m.Found
}

function Get-RewardRecoveryStep($screen) {
    if ($screen.Reward -or $screen.Confirm) { return 'Wait' }
    if ($screen.LobbyHub -and $screen.LobbyHubClose -and $screen.LobbyHubCenter) { return 'CloseLobbyHub' }
    if ($screen.Hub -and $screen.HubClose -and $screen.HubCenter) { return 'CloseMatchHub' }
    if ($screen.LobbyHub -or $screen.Hub) { return 'Wait' }
    if ($screen.Club) {
        if ($screen.Close) { return 'CloseClub' }
        return 'Wait'
    }
    if ($screen.Lobby -and $screen.Exit) { return 'Complete' }
    if ($screen.Menu -and $screen.ClubTab) { return 'ReturnManager' }
    return 'Wait'
}

function Start-RewardRecovery([string]$feature, [string]$state, [datetime]$utc, [string]$detail) {
    if ($script:rewardRecoveryDeadline) { return }
    $script:rewardRecoveryDeadline = $utc.AddSeconds(15)
    $script:rewardRecoveryLastStep = ''
    $steps = @{
        Lobby='감독모드 로비에서 나가기'; Open='메뉴 열기'; Donate='기부 버튼 확인'
        Claim='보상 버튼 확인'; Verify='수령 또는 기부 완료 확인'; Finish='기부 완료 확인'
        Return='로비 복귀'; Home='감독모드 로비 확인'
    }
    $step = $steps[$state]
    if (-not $step) { $step = $state }
    Queue-OperatorReport "$feature 확인 실패 · $step · $detail"
    Queue-DiscordNotification "$feature 확인 실패" "실패 단계: $step`n원인: $detail`n감독모드 로비 복귀를 시도합니다."
    Write-Log "$feature 확인 실패 ($state): $detail · 로비 복귀 시도"
    Set-Status '감독모드 로비 복귀 중' ([Drawing.Color]::Orange)
}

function Stop-ExpiredRewardRecovery([datetime]$utc) {
    if (-not $script:rewardRecoveryDeadline -or $utc -lt $script:rewardRecoveryDeadline) { return $false }
    Queue-OperatorReport '감독모드 로비 복귀 실패'
    Queue-DiscordNotification '감독모드 로비 복귀 실패' '15초 안에 로비로 돌아오지 못해 자동 진행을 중지했습니다. 게임 화면을 확인해 주세요.'
    Stop-Automation '보상 확인 후 감독모드 복귀 실패'
    Set-Status '로비 복귀 실패 · 자동 진행 중지' ([Drawing.Color]::Orange)
    return $true
}

function Complete-RewardRecovery {
    $script:rewardRecoveryDeadline = $null
    $script:clubState = ''
    $script:missionState = ''
    # Give the game the next match before starting another scheduled reward check.
    $script:rewardRecoveryMatchCount = $script:sessionMatchCount
    $script:lastProgressAt = [DateTime]::Now
    Update-RewardButton
    Set-Status '감독모드 진행 재개' ([Drawing.Color]::FromArgb(83,220,120))
    Write-Log '감독모드 로비를 확인해 자동 진행을 재개합니다.'
}

function Invoke-RewardRecovery($info) {
    if (-not $info.Allowed) { return }
    $frame = Get-ClubClientFrame $info.Handle
    if (-not $frame) { return }
    $screen = @{}
    foreach ($name in @('Lobby','Exit','Menu','ClubTab','Club','Close','Confirm','Reward',
                       'Hub','HubClose','HubCenter','LobbyHub','LobbyHubClose','LobbyHubCenter')) {
        $screen[$name] = Find-ClubMarker $frame.Buffer $name
    }
    $step = Get-RewardRecoveryStep $screen
    if ($step -eq 'Wait') { return }

    $front = Get-ForegroundInfo
    if (-not $front.Allowed -or $front.Handle -ne $info.Handle) { return }
    if ($step -eq 'Complete') {
        Complete-RewardRecovery
        return
    }
    if ($step -eq $script:rewardRecoveryLastStep) { return }
    $x, $y = switch ($step) {
        'CloseLobbyHub' { 827, 37 }
        'CloseMatchHub' { 827, 50 }
        'CloseClub' { 827, 37 }
        'ReturnManager' { 208, 161 }
    }
    $script:nextScanDue = [DateTime]::Now.AddMilliseconds(900)
    if ([FCNative]::SendLeftClick(($frame.Origin.X+[int]($x*$frame.Width/960)), ($frame.Origin.Y+[int]($y*$frame.Height/540)))) {
        $script:rewardRecoveryLastStep = $step
    }
}

function Get-ClubStep([string]$state,$screen,[bool]$submitted) {
    switch($state){
        'Lobby' {if($screen.Lobby -and $screen.Exit){return 'ExitLobby'}}
        'Open' {if($screen.Menu -and $screen.ClubTab){return 'OpenClub'}}
        'Donate' {
            if($screen.Club -and $screen.Disabled -and $screen.Zero -and $screen.Close){return 'CloseEmpty'}
            if(!$submitted -and $screen.Club -and $screen.Enabled -and !$screen.Zero){return 'DonateOnce'}
        }
        'Verify' {
            if($screen.Reward -and $screen.Confirm){return 'ConfirmReward'}
            if($screen.Club -and $screen.Disabled -and $screen.Zero -and $screen.Close){return 'CloseDone'}
        }
        'Finish' {if($screen.Club -and $screen.Disabled -and $screen.Zero -and $screen.Close){return 'CloseDone'}}
        'Return' {if($screen.Menu -and $screen.ClubTab){return 'ReturnManager'}}
        'Home' {if($screen.Lobby -and $screen.Exit){return 'Complete'}}
    }
    return 'Wait'
}

function Invoke-ClubFlow($info) {
    $front=Get-ForegroundInfo
    if(!$front.Allowed -or $front.Handle -ne $info.Handle){return}
    if([DateTime]::UtcNow -gt $script:clubDeadline){
        Start-RewardRecovery '클럽 기부' $script:clubState ([DateTime]::UtcNow) '화면 확인 제한시간 초과'
        return
    }
    $frame=Get-ClubClientFrame $info.Handle
    if(!$frame){return}
    # Only compare markers relevant to the current transition.
    $keys=switch($script:clubState){
        {$_ -in @('Lobby','Home')}{'Lobby';'Exit';break}
        {$_ -in @('Open','Return')}{'Menu';'ClubTab';break}
        'Donate' {'Club';'Enabled';'Disabled';'Zero';'Close'}
        'Verify' {'Reward';'Confirm';'Club';'Disabled';'Zero';'Close'}
        'Finish' {'Club';'Disabled';'Zero';'Close'}
    }
    $screen=@{}
    foreach($key in $keys){$screen[$key]=Find-ClubMarker $frame.Buffer $key}
    $step=Get-ClubStep $script:clubState $screen $script:clubSubmitted
    if($step -eq 'Wait'){return}
    if($step -eq 'Complete'){
        $script:clubState=''
        Update-RewardButton
        $script:lastProgressAt=[DateTime]::Now
        Write-Log '클럽 확인 후 감독모드로 복귀했습니다.'
        return
    }
    $action=switch($step){
        'ExitLobby' {@{X=827;Y=37;Next='Open'}}
        'OpenClub' {@{X=604;Y=525;Next='Donate'}}
        'DonateOnce' {@{X=782;Y=294;Next='Verify'}}
        'ConfirmReward' {@{X=543;Y=390;Next='Finish'}}
        {$_ -in @('CloseEmpty','CloseDone')} {@{X=827;Y=37;Next='Return'};break}
        'ReturnManager' {@{X=208;Y=161;Next='Home'}}
    }
    $front=Get-ForegroundInfo
    if(!$front.Allowed -or $front.Handle -ne $info.Handle){return}
    if($step -eq 'DonateOnce' -and !$script:rewardFlowManual -and !(Test-RewardWindow ([DateTime]::UtcNow))){
        Start-RewardRecovery '클럽 기부' $script:clubState ([DateTime]::UtcNow) '자동 보상 확인 시간 종료'
        return
    }
    if($step -eq 'DonateOnce'){$script:clubSubmitted=$true}
    $stage=$script:clubState
    $script:clubState=$action.Next
    $script:clubDeadline=[DateTime]::UtcNow.AddSeconds(15)
    $script:nextScanDue=[DateTime]::Now.AddMilliseconds(900)
    if(-not [FCNative]::SendLeftClick(($frame.Origin.X+[int]($action.X*$frame.Width/960)),($frame.Origin.Y+[int]($action.Y*$frame.Height/540)))){
        Start-RewardRecovery '클럽 기부' $stage ([DateTime]::UtcNow) '클럽 화면 입력 실패'
        return
    }
    if($step -eq 'CloseDone'){Write-Log '클럽 기부 완료: 미기부 0P와 버튼 비활성 상태를 확인했습니다.'}
    if($step -eq 'CloseEmpty'){Write-Log '클럽 미기부 포인트가 없어 건너뜁니다.'}
}

$script:clubRegions=@{
    LobbyHub=@(452,29,17)
    LobbyHubClose=@(818,27,20)
    LobbyHubCenter=@(588,235,15)
    LobbyClaimEnabled=@(698,96,13)
    LobbyClaimDisabled=@(693,94,5)
    MissionNav=@(211,520,16)
    Hub=@(451,40,16)
    HubClose=@(818,41,16)
    HubCenter=@(529,236,11)
    ClaimEnabled=@(701,110,13)
    ClaimDisabled=@(701,110,13)
    Lobby=@(120,63,20)
    Exit=@(816,27,29)
    Menu=@(160,153,34)
    ClubTab=@(598,521,25)
    Club=@(465,27,30)
    Enabled=@(752,287,21)
    Disabled=@(752,287,17)
    Zero=@(678,465,15)
    Close=@(819,27,30)
    Reward=@(459,145,18)
    Confirm=@(504,383,20)
}

function Get-MissionStep([string]$state,$screen) {
    switch($state){
        'Open' {if($screen.Lobby -and $screen.MissionNav){return 'OpenHub'}}
        'Claim' {
            if($screen.Hub -and $screen.HubCenter -and $screen.HubClose -and $screen.ClaimEnabled -and !$screen.ClaimDisabled){return 'ClaimOnce'}
            if($screen.Hub -and $screen.HubCenter -and $screen.HubClose -and $screen.ClaimDisabled -and !$screen.ClaimEnabled){return 'CloseEmpty'}
        }
        'Verify' {if($screen.Hub -and $screen.HubCenter -and $screen.HubClose -and $screen.ClaimDisabled -and !$screen.ClaimEnabled){return 'CloseClaimed'}}
        'Return' {
            if($screen.Lobby -and !$screen.Hub){return 'Complete'}
            if($screen.Menu -and $screen.ClubTab -and !$screen.Hub){return 'ReturnManager'}
        }
        'Home' {if($screen.Lobby -and !$screen.Hub){return 'Complete'}}
    }
    return 'Wait'
}

function Get-MissionHubReading($buffer) {
    $m=@{}
    foreach($name in @('LobbyHub','LobbyHubClose','LobbyHubCenter')){
        $m[$name]=Find-ClubMarker $buffer $name
    }
    if($m.LobbyHub -and $m.LobbyHubClose -and $m.LobbyHubCenter){
        $enabled=Find-ClubMarker $buffer 'LobbyClaimEnabled'
        $disabled=Find-ClubMarker $buffer 'LobbyClaimDisabled'
        return @{Layout='Lobby';Hub=$true;HubClose=$true;HubCenter=$true;ClaimEnabled=$enabled;ClaimDisabled=$disabled}
    }
    foreach($name in @('Hub','HubClose','HubCenter','ClaimEnabled','ClaimDisabled')){
        $m[$name]=Find-ClubMarker $buffer $name
    }
    $m.Layout='Match'
    return $m
}

function Write-MissionTimeout([IntPtr]$handle) {
    $stage=$script:missionState
    Write-Log "미션 허브 확인 제한시간 초과: 단계=$stage · 인식=$($script:missionObserved)"
    try {
        $frame=Get-FCFrame $handle
        if($frame){
            $image=[FCTemplateMatcher]::ToBitmap($frame.Buffer)
            try{
                $name='mission_{0}_{1}.png' -f (Get-Date -Format 'yyyyMMdd_HHmmss_fff'),$stage
                $image.Save((Join-Path $script:captureDir $name),[Drawing.Imaging.ImageFormat]::Png)
                Write-Log "미션 허브 진단 화면 저장: $name"
            }finally{$image.Dispose()}
        }
    } catch {Write-Log "미션 허브 화면 저장 실패: $($_.Exception.Message)"}
}

function Invoke-MissionFlow($info) {
    $front=Get-ForegroundInfo
    if(!$front.Allowed -or $front.Handle -ne $info.Handle){return}
    if([DateTime]::UtcNow -gt $script:missionDeadline){
        Write-MissionTimeout $info.Handle
        Start-RewardRecovery '미션 허브' $script:missionState ([DateTime]::UtcNow) '화면 확인 제한시간 초과'
        return
    }
    $frame=Get-ClubClientFrame $info.Handle
    if(!$frame){return}
    $keys=switch($script:missionState){
        'Open' {'Lobby';'MissionNav'}
        'Return' {'Hub';'LobbyHub';'Lobby';'Menu';'ClubTab'}
        'Home' {'Hub';'LobbyHub';'Lobby'}
    }
    if($script:missionState -in @('Claim','Verify')){
        $screen=Get-MissionHubReading $frame.Buffer
    } else {
        $screen=@{}
        foreach($key in $keys){$screen[$key]=Find-ClubMarker $frame.Buffer $key}
        $screen.Hub=$screen.Hub -or $screen.LobbyHub
    }
    $script:missionObserved=($screen.GetEnumerator() | Sort-Object Name | ForEach-Object {"$($_.Name)=$($_.Value)"}) -join ', '
    $step=Get-MissionStep $script:missionState $screen
    if($step -eq 'Wait'){return}
    if($step -eq 'Complete'){
        $script:missionState=''
        $script:lastProgressAt=[DateTime]::Now
        Update-RewardButton
        Write-Log '미션 허브 확인 후 감독모드로 복귀했습니다.'
        return
    }
    $action=switch($step){
        'OpenHub' {@{X=228;Y=525;Next='Claim'}}
        'ClaimOnce' {@{X=740;Y=$(if($screen.Layout -eq 'Lobby'){106}else{119});Next='Verify'}}
        {$_ -in @('CloseEmpty','CloseClaimed')} {@{X=827;Y=$(if($screen.Layout -eq 'Lobby'){37}else{50});Next='Return'};break}
        'ReturnManager' {@{X=208;Y=161;Next='Home'}}
    }
    $front=Get-ForegroundInfo
    if(!$front.Allowed -or $front.Handle -ne $info.Handle){return}
    if($step -eq 'ClaimOnce' -and !$script:rewardFlowManual -and !(Test-RewardWindow ([DateTime]::UtcNow))){
        Start-RewardRecovery '미션 허브' $script:missionState ([DateTime]::UtcNow) '자동 보상 확인 시간 종료'
        return
    }
    # Advance before input: a failed or delayed click cannot retry a claim.
    $stage=$script:missionState
    $script:missionState=$action.Next
    $script:missionDeadline=[DateTime]::UtcNow.AddSeconds(15)
    $script:nextScanDue=[DateTime]::Now.AddMilliseconds(900)
    if(-not [FCNative]::SendLeftClick(($frame.Origin.X+[int]($action.X*$frame.Width/960)),($frame.Origin.Y+[int]($action.Y*$frame.Height/540)))){
        Start-RewardRecovery '미션 허브' $stage ([DateTime]::UtcNow) '미션 허브 입력 실패'
        return
    }
    if($step -eq 'CloseClaimed'){Write-Log '미션 허브: 보상 수령 버튼 비활성화를 확인했습니다.'}
    if($step -eq 'CloseEmpty'){Write-Log '미션 허브: 받을 보상이 없어 건너뜁니다.'}
}

function Initialize-MissionOption {
    $script:missionCheck=[Windows.Forms.CheckBox]::new()
    $script:missionCheck.Text='20경기마다 미션 허브 보상 받기'
    $script:missionCheck.SetBounds(18,271,880,30)
    $script:missionCheck.Font=[Drawing.Font]::new('Malgun Gothic',11.5)
    $script:runSettingsPage.Controls.Add($script:missionCheck)
}

function Get-RewardDay([datetime]$utc) {
    return $utc.AddHours(9).ToString('yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture)
}
function Test-RewardWindow([datetime]$utc) {
    $kst=$utc.AddHours(9)
    return ($kst.Hour -eq 23 -and $kst.Minute -ge 30)
}
function Reserve-DailyReward([string]$kind,[datetime]$utc) {
    if($kind -notin @('club','mission') -or !(Test-RewardWindow $utc)){return $false}
    $day=Get-RewardDay $utc
    $dir=Join-Path $script:appDir '.reward-checks'
    $path=Join-Path $dir "$day-$kind"
    try {
        [void][IO.Directory]::CreateDirectory($dir)
        $file=[IO.File]::Open($path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
        $file.Dispose()
        return $true
    } catch {
        if(![IO.File]::Exists($path)){Write-Log "보상 확인 기록을 저장하지 못해 자동 확인을 건너뜁니다: $kind"}
        return $false
    }
}
function Update-RewardButton {
    if(!$script:rewardNextButton){return}
    $busy=!!($script:missionState -or $script:clubState -or $script:manualMission -or $script:manualClub)
    $script:rewardNextButton.Enabled=$script:running -and !$busy
    $script:rewardNextButton.Text=if($busy){'기부·보상 확인 중'}elseif($null -ne $script:rewardAfterMatch){'다음 경기 확인 예약 취소'}else{'다음 경기 후 기부·보상 확인'}
}
function Initialize-DailyRewardOption {
    $script:clubCheck.Text='클럽 기부 자동 확인'
    $script:clubCheck.SetBounds(440,236,230,30)
    $script:missionCheck.Text='미션 허브 자동 확인'
    $script:missionCheck.SetBounds(672,236,248,30)
    $hint=[Windows.Forms.Label]::new()
    $hint.Text='자동 확인: 한국 시간 23:30~자정 · 항목별 하루 1회'
    $hint.SetBounds(18,274,532,26)
    $script:runSettingsPage.Controls.Add($hint)
    $script:rewardNextButton=[Windows.Forms.Button]::new()
    $script:rewardNextButton.SetBounds(566,269,340,35)
    $script:rewardNextButton.FlatStyle='Flat'
    $script:rewardNextButton.BackColor=[Drawing.ColorTranslator]::FromHtml('#263240')
    $script:rewardNextButton.ForeColor=[Drawing.Color]::White
    $script:runSettingsPage.Controls.Add($script:rewardNextButton)
    $script:rewardNextButton.Add_Click({
        if(!$script:running -or $script:missionState -or $script:clubState -or $script:manualMission -or $script:manualClub){return}
        if($null -ne $script:rewardAfterMatch){$script:rewardAfterMatch=$null}
        else{$script:rewardAfterMatch=$script:sessionMatchCount+1}
        Update-RewardButton
    })
    Update-RewardButton
}

function Start-ScheduledRewardCheck($recognized,[datetime]$utc) {
    if($script:rewardRecoveryMatchCount -eq $script:sessionMatchCount -or
       $recognized.Template.Definition.File -ne 'click_1.png' -or
       $script:stopAfterCurrentMatch -or $script:requiredStopAfterMatch -or
       ($script:parkingMode -and $script:rankResyncRequired)){return $false}
    if($null -ne $script:rewardAfterMatch -and $script:sessionMatchCount -ge $script:rewardAfterMatch){
        $script:rewardAfterMatch=$null
        $script:manualMission=$true
        $script:manualClub=$true
    }
    if($script:manualMission -or (!$script:manualClub -and $script:missionCheck.Checked -and (Reserve-DailyReward 'mission' $utc))){
        $script:rewardFlowManual=$script:manualMission
        if($script:manualMission){[void](Reserve-DailyReward 'mission' $utc)}
        $script:manualMission=$false
        $script:missionObserved='미확인'
        $script:missionState='Open'
        $script:missionDeadline=$utc.AddSeconds(15)
        Set-Status '미션 허브 보상 확인 중' ([Drawing.Color]::FromArgb(120,180,235))
    } elseif($script:manualClub -or ($script:clubCheck.Checked -and (Reserve-DailyReward 'club' $utc))){
        $script:rewardFlowManual=$script:manualClub
        if($script:manualClub){[void](Reserve-DailyReward 'club' $utc)}
        $script:manualClub=$false
        $script:clubState='Lobby'
        $script:clubSubmitted=$false
        $script:clubDeadline=$utc.AddSeconds(15)
        Set-Status '클럽 기부 확인 중' ([Drawing.Color]::FromArgb(120,180,235))
    } else {return $false}
    Update-RewardButton
    return $true
}

function Initialize-ClubOption {
    $script:clubCheck=[Windows.Forms.CheckBox]::new()
    $script:clubCheck.Text='경기 사이 클럽 자동 기부 및 보상 수령'
    $script:clubCheck.SetBounds(425,236,480,30)
    $script:clubCheck.Font=[Drawing.Font]::new('Malgun Gothic',11.5)
    $onlyFcCheck.Width=380
    $script:runSettingsPage.Controls.Add($script:clubCheck)
}

function Get-MaintenanceAction($plan, [datetime]$utc, [bool]$gamePresent, [string]$gameView) {
    if ($utc -ge $plan.EndAt) { return 'Expire' }
    if ($utc -lt $plan.StartAt) { return 'Wait' }
    if (-not $gamePresent) {
        if ($utc -ge $plan.NextLaunch) { return 'Launch' }
        return 'Wait'
    }
    if ($gameView -eq 'Lobby') { return 'Resume' }
    if ($gameView -eq 'Menu') { return 'EnterManager' }
    return 'Wait'
}

function Select-NexonStartControl($candidates) {
    $matches = @($candidates | Where-Object {
        $_.Visible -and $_.Game -match '^(?:FC ONLINE|FC 온라인)$' -and $_.Name -match '^(?:(?:FC ONLINE|FC 온라인)\s*)?게임\s*시작$'
    })
    if ($matches.Count -eq 1 -and $matches[0].Enabled) { return $matches[0].Control }
    return $null
}

function Get-NexonStartControls($root, $buttonFilter) {
    $descendants = [Windows.Automation.TreeScope]::Descendants
    foreach ($button in $root.FindAll($descendants, $buttonFilter)) {
        $name = $button.Current.Name
        if ($name -notmatch '^(?:(?:FC ONLINE|FC 온라인)\s*)?게임\s*시작$') { continue }
        if ($button.Current.IsOffscreen) { continue }

        # Another title may still be shown in the launcher sidebar. Scope an
        # unnamed game-start button to its own card, not the whole launcher.
        $game = if ($name -match '^FC (?:ONLINE|온라인)') { 'FC ONLINE' }
        $card = $button
        for ($level = 0; -not $game -and $level -lt 3; $level++) {
            $card = [Windows.Automation.TreeWalker]::ControlViewWalker.GetParent($card)
            if ($null -eq $card -or [Windows.Automation.Automation]::Compare($card, $root)) { break }
            if ($card.Current.ControlType -notin @([Windows.Automation.ControlType]::Group, [Windows.Automation.ControlType]::Pane, [Windows.Automation.ControlType]::Custom)) { continue }
            $startButtons = @($card.FindAll($descendants, $buttonFilter) | Where-Object {
                -not $_.Current.IsOffscreen -and $_.Current.Name -match '게임\s*시작$'
            })
            if ($startButtons.Count -ne 1) { break }
            if ($card.Current.Name -match '^(?:FC ONLINE|FC 온라인)$') {
                $game = $card.Current.Name
                break
            }
            foreach ($label in $card.FindAll([Windows.Automation.TreeScope]::Children, [Windows.Automation.Condition]::TrueCondition)) {
                if (-not $label.Current.IsOffscreen -and $label.Current.ControlType -eq [Windows.Automation.ControlType]::Text -and
                    $label.Current.Name -match '^(?:FC ONLINE|FC 온라인)$') {
                    $game = $label.Current.Name
                    break
                }
            }
        }
        if ($game) {
            [PSCustomObject]@{Game=$game;Name=$name;Enabled=$button.Current.IsEnabled;Visible=$true;Control=$button}
        }
    }
}

function Invoke-NexonPlugStart {
    Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes
    $buttons = [Windows.Automation.PropertyCondition]::new(
        [Windows.Automation.AutomationElement]::ControlTypeProperty, [Windows.Automation.ControlType]::Button)
    $processes = [Diagnostics.Process]::GetProcessesByName('NexonPlug')
    $candidates = @(
        foreach ($process in $processes) {
            try {
                if ($process.MainWindowHandle -eq [IntPtr]::Zero) { continue }
                $root = [Windows.Automation.AutomationElement]::FromHandle($process.MainWindowHandle)
                if ($root) { Get-NexonStartControls $root $buttons }
            } finally { $process.Dispose() }
        }
    )
    $target = Select-NexonStartControl $candidates
    if (-not $target) { return $false }
    if ($target.Current.IsOffscreen -or -not $target.Current.IsEnabled -or (Test-GameProcessPresent)) { return $false }
    $pattern = $null
    if (-not $target.TryGetCurrentPattern([Windows.Automation.InvokePattern]::Pattern, [ref]$pattern)) { return $false }
    $pattern.Invoke()
    return $true
}

function Get-MaintenanceGameView($info) {
    if ($info.Process -ne 'fczf' -or $info.Handle -eq [IntPtr]::Zero) { return $null }
    $frame = Get-ClubClientFrame $info.Handle
    if (-not $frame) { return $null }
    $screen = @{}
    foreach ($name in @('Lobby','Exit','Menu','ClubTab','Club','Confirm','Reward','Hub','LobbyHub')) {
        $screen[$name] = Find-ClubMarker $frame.Buffer $name
    }
    if ($screen.Club -or $screen.Confirm -or $screen.Reward -or $screen.Hub -or $screen.LobbyHub) { return $null }
    if ($screen.Lobby -and $screen.Exit) { return @{View='Lobby';Frame=$frame} }
    if ($screen.Menu -and $screen.ClubTab) { return @{View='Menu';Frame=$frame} }
    return $null
}

function Set-MaintenanceStatus([string]$message) {
    $script:maintenanceStatus.Text = $message
    $armed = $null -ne $script:maintenancePlan
    $script:maintenanceArm.Enabled = -not $armed
    $script:maintenanceTime.Enabled = -not $armed
    $script:maintenanceCancel.Enabled = $armed
}

function Cancel-MaintenanceStart([string]$message) {
    if (-not $script:maintenancePlan) { return }
    $script:maintenancePlan = $null
    Set-MaintenanceStatus $message
}

function Read-ConfirmedStartingRank([IntPtr]$handle) {
    $frame = Get-FCFrame $handle
    if ($null -eq $frame) { throw '게임 화면을 캡처하지 못했습니다.' }
    $rank = Read-StartingRankPoints $frame
    if (-not $rank.Found) { throw $rank.Reason }
    Start-Sleep -Milliseconds 350
    $front = Get-ForegroundInfo
    if ($front.Process -ne 'fczf' -or $front.Handle -ne $handle) { throw 'FC ONLINE 창이 변경됐습니다.' }
    $secondFrame = Get-FCFrame $handle
    if ($null -eq $secondFrame) { throw '시작점수 재확인용 화면을 캡처하지 못했습니다.' }
    $secondRank = Read-StartingRankPoints $secondFrame
    if (-not $secondRank.Found -or $secondRank.Points -ne $rank.Points) {
        throw '두 번 읽은 시작점수가 일치하지 않습니다. 랭킹 화면을 다시 확인해 주세요.'
    }
    return [int]$rank.Points
}

function Set-ConfirmedStartingRank([int]$points) {
    $script:startingRankPoints = $points
    $script:currentRankPoints = $points
    $script:startingRankReadAt = [DateTime]::Now
    $rankPointsLabel.Text = "시작점수: ${points}점 · 화면에서 인식됨"
    Write-Log "주차 시작점수 화면 인식: ${points}점"
}

function Complete-MaintenanceStart {
    $script:maintenancePlan = $null
    if ($script:running) {
        $script:paused = $false
        $script:resumeStableSince = $null
        $script:nextScanDue = [DateTime]::Now
        $script:lastProgressAt = [DateTime]::Now
        $script:previousVisualFrame = $null
        $script:lastVisualChangeAt = [DateTime]::Now
        $script:stuckAlertActive = $false
        if ($script:parkingMode) { $script:rankResyncRequired = $true }
    } else {
        Start-Automation
    }
    Set-MaintenanceStatus '감독모드 로비 확인 · 자동 진행 시작'
    Queue-DiscordNotification '점검 후 감독모드 시작' 'FC 온라인 감독모드 로비를 확인해 자동 진행을 시작했습니다.'
    Write-Log '점검 후 자동 시작 예약을 완료했습니다.'
}

function Invoke-MaintenanceStart($info, [datetime]$utc, [bool]$gamePresent) {
    $plan = $script:maintenancePlan
    if (-not $plan) { return $false }
    if ($utc -ge $plan.EndAt) {
        Cancel-MaintenanceStart '예약 만료 · 감독모드 로비를 확인하지 못했습니다.'
        Queue-OperatorReport '점검 후 자동 시작 실패'
        Queue-DiscordNotification '점검 후 자동 시작 실패' '예약된 시간에 감독모드 로비를 확인하지 못했습니다.'
        if ($plan.Interrupted) { Stop-Automation '점검 후 자동 시작 예약 만료' }
        return $true
    }
    if ($utc -lt $plan.StartAt -or $utc -lt $plan.NextProbe) { return [bool]$plan.Interrupted }
    $plan.NextProbe = $utc.AddSeconds(2)

    $gameView = if ($gamePresent) { Get-MaintenanceGameView $info }
    if ($gamePresent -and $info.Process -ne 'fczf' -and
        ($info.Process -eq 'NexonPlug' -or $info.Handle -eq $form.Handle)) {
        $gameWindow = Get-FCWindowInfo
        if ($gameWindow) { [void][FCNative]::SetForegroundWindow($gameWindow.Handle) }
    }
    $action = Get-MaintenanceAction $plan $utc $gamePresent $gameView.View
    switch ($action) {
        'Launch' {
            $plan.NextLaunch = $utc.AddSeconds(20)
            try {
                if (Invoke-NexonPlugStart) {
                    $plan.NextLaunch = $utc.AddMinutes(2)
                    $plan.Interrupted = $script:running
                    Set-MaintenanceStatus 'FC 온라인 실행 요청 · 게임 창 대기 중'
                    Write-Log '점검 후 자동 시작: 넥슨플러그 게임시작 실행'
                } else {
                    Set-MaintenanceStatus '넥슨플러그의 FC 온라인 게임시작 버튼 활성화 대기 중'
                }
            } catch {
                Set-MaintenanceStatus '넥슨플러그 버튼 확인 실패 · 다시 확인합니다.'
                if (-not $plan.LauncherErrorLogged) {
                    Write-Log "넥슨플러그 버튼 확인 실패: $($_.Exception.GetType().Name)"
                    $plan.LauncherErrorLogged = $true
                }
            }
            return $true
        }
        'EnterManager' {
            if ($utc -lt $plan.NextMenuClick) { return $true }
            $plan.Interrupted = $script:running
            $front = Get-ForegroundInfo
            if ($front.Process -ne 'fczf' -or $front.Handle -ne $info.Handle) { return $true }
            $frame = $gameView.Frame
            $plan.NextMenuClick = $utc.AddSeconds(15)
            $x = $frame.Origin.X + [int](208 * $frame.Width / 960)
            $y = $frame.Origin.Y + [int](161 * $frame.Height / 540)
            [void][FCNative]::SendLeftClick($x, $y)
            Set-MaintenanceStatus '감독모드 메뉴 진입 · 로비 확인 중'
            return $true
        }
        'Resume' {
            if (-not $script:running -and $parkingModeRadio.Checked) {
                if ($utc -lt $plan.NextRankRead) { return $true }
                $plan.NextRankRead = $utc.AddSeconds(20)
                try { $points = Read-ConfirmedStartingRank $info.Handle }
                catch {
                    Set-MaintenanceStatus '주차 모드 · 챔피언스 랭킹 시작점수 확인 중'
                    return $true
                }
                if ([int]$targetPointsBox.Value -le $points -or
                    ($minimumPointsCheck.Checked -and [int]$minimumPointsBox.Value -ge $points)) {
                    Cancel-MaintenanceStart '확인된 점수가 주차 범위를 벗어나 자동 시작을 취소했습니다.'
                    Queue-DiscordNotification '점검 후 주차 시작 취소' "확인된 점수: ${points}점 · 주차 조건을 확인해 주세요."
                    return $true
                }
                Set-ConfirmedStartingRank $points
            }
            Complete-MaintenanceStart
            return $true
        }
        default {
            if ($gamePresent) { Set-MaintenanceStatus 'FC 온라인 실행됨 · 감독모드 로비 확인 중' }
            return ([bool]$plan.Interrupted -or -not $script:running)
        }
    }
}

function Update-ClientLifecycle($info, [datetime]$utc) {
    if (-not ($script:running -or $script:maintenancePlan)) { return $false }
    if ($utc -lt $script:nextClientPoll) {
        return ($script:clientInputBlocked -or [bool]$script:maintenancePlan.Interrupted)
    }
    $script:nextClientPoll = $utc.AddSeconds(1)
    $present = Test-GameProcessPresent
    $script:clientInputBlocked = -not $present
    if ((Update-GamePresence $script:gamePresence $present $utc) -eq 'Exited') {
        Queue-DiscordNotification 'FC 온라인 종료 감지' "FC 온라인 프로세스가 종료됐습니다.`n$(Get-MatchSummary)"
        Write-Log 'FC 온라인 프로세스 종료를 감지했습니다.'
        if (-not $script:maintenancePlan) {
            Stop-Automation 'FC 온라인 종료'
            Set-Status 'FC 온라인 종료 · 자동 진행 중지' ([Drawing.Color]::Orange)
            return $true
        }
        $script:maintenancePlan.Interrupted = $script:running
        $script:clubState = ''
        $script:missionState = ''
        $script:rewardRecoveryDeadline = $null
        Set-Status 'FC 온라인 종료 · 점검 후 시작 대기' ([Drawing.Color]::Orange)
    }

    if (Invoke-MaintenanceStart $info $utc $present) { return $true }
    return (-not $present)
}

function Initialize-MaintenanceView {
    $page = [Windows.Forms.TabPage]::new('자동 시작')
    $page.BackColor = [Drawing.ColorTranslator]::FromHtml('#19212C')
    $page.ForeColor = $form.ForeColor
    $titleLabel = [Windows.Forms.Label]::new()
    $titleLabel.Text = '점검 종료 후 자동 시작'
    $titleLabel.SetBounds(22,18,700,34)
    $titleLabel.Font = [Drawing.Font]::new('Malgun Gothic',14,[Drawing.FontStyle]::Bold)
    $hint = [Windows.Forms.Label]::new()
    $hint.Text = "넥슨플러그에 로그인하고 FC 온라인 화면을 열어 두세요.`r`n예약 시각 이후 게임시작 버튼이 활성화되면 실행합니다."
    $hint.SetBounds(22,60,870,56)
    $dateLabel = [Windows.Forms.Label]::new()
    $dateLabel.Text = '점검 종료 예정 (한국 시간)'
    $dateLabel.SetBounds(22,134,240,32)
    $script:maintenanceTime = [Windows.Forms.DateTimePicker]::new()
    $script:maintenanceTime.Format = 'Custom'
    $script:maintenanceTime.CustomFormat = 'yyyy-MM-dd HH:mm'
    $script:maintenanceTime.Value = [DateTime]::UtcNow.AddHours(9).AddMinutes(15)
    $script:maintenanceTime.SetBounds(270,133,242,32)
    $script:maintenanceArm = [Windows.Forms.Button]::new()
    $script:maintenanceArm.Text = '자동 시작 예약'
    $script:maintenanceArm.SetBounds(534,130,145,39)
    $script:maintenanceCancel = [Windows.Forms.Button]::new()
    $script:maintenanceCancel.Text = '예약 취소'
    $script:maintenanceCancel.SetBounds(691,130,116,39)
    foreach ($button in @($script:maintenanceArm,$script:maintenanceCancel)) {
        $button.FlatStyle = 'Flat'
        $button.FlatAppearance.BorderSize = 0
        $button.BackColor = [Drawing.ColorTranslator]::FromHtml('#263240')
        $button.ForeColor = [Drawing.Color]::White
    }
    $script:maintenanceArm.BackColor = [Drawing.ColorTranslator]::FromHtml('#147C76')
    $script:maintenanceStatus = [Windows.Forms.Label]::new()
    $script:maintenanceStatus.SetBounds(22,192,880,50)
    $script:maintenanceArm.Add_Click({
        if ($script:updateInstalling -or $script:coachRun -or $script:bpRun) { return }
        $now = [DateTime]::UtcNow
        $selection = $script:maintenanceTime.Value
        $start = [DateTime]::SpecifyKind($selection.Date.AddHours($selection.Hour - 9).AddMinutes($selection.Minute), [DateTimeKind]::Utc)
        if ($start.AddMinutes(1) -le $now) {
            Set-MaintenanceStatus '현재 또는 이후의 점검 종료 예정 시각을 입력해 주세요.'
            return
        }
        $present = Test-GameProcessPresent
        $script:maintenancePlan = @{
            StartAt=$start; EndAt=$start.AddHours(6); NextLaunch=$start
            NextProbe=$start; NextMenuClick=$start; NextRankRead=$start
            Interrupted=($script:running -and -not $present)
        }
        $script:gamePresence = @{Observed=$present}
        $script:clientInputBlocked = -not $present
        $script:nextClientPoll = $now
        Set-MaintenanceStatus "예약됨 · 한국 시간 $($start.AddHours(9).ToString('yyyy-MM-dd HH:mm'))"
    })
    $script:maintenanceCancel.Add_Click({
        $interrupted = $script:maintenancePlan.Interrupted
        Cancel-MaintenanceStart '자동 시작 예약이 취소되었습니다.'
        if ($interrupted) { Stop-Automation '점검 후 자동 시작 예약 취소' }
    })
    foreach ($control in @($titleLabel,$hint,$dateLabel,$script:maintenanceTime,$script:maintenanceArm,$script:maintenanceCancel,$script:maintenanceStatus)) {
        $page.Controls.Add($control)
    }
    $script:settingsTabs.TabPages.Add($page)
    $nav = [Windows.Forms.Button]::new()
    $nav.Text = '자동 시작'
    $nav.Tag = $script:settingsTabs.TabPages.Count - 1
    $nav.SetBounds(24,482,140,40)
    $nav.FlatStyle = 'Flat'
    $nav.FlatAppearance.BorderSize = 0
    $nav.TextAlign = 'MiddleLeft'
    $nav.Padding = [Windows.Forms.Padding]::new(12,0,0,0)
    $nav.BackColor = [Drawing.ColorTranslator]::FromHtml('#10151C')
    $nav.ForeColor = [Drawing.ColorTranslator]::FromHtml('#AAB9C8')
    $nav.Font = [Drawing.Font]::new('Malgun Gothic',11.5,[Drawing.FontStyle]::Bold)
    $nav.Cursor = [Windows.Forms.Cursors]::Hand
    $nav.Add_Click({param($sender,$e) $script:settingsTabs.SelectedIndex = [int]$sender.Tag})
    $script:tabNav += ,$nav
    $form.Controls.Add($nav)
    Set-MaintenanceStatus '예약 없음'
}

$script:bpRegions = @{
    Open = @(492, 472, 12)
    Label = @(139, 343, 8)
    Applied = @(313, 340, 9)
    Tab = @(438, 103, 12)
    ZeroTab = @(438, 103, 12)
    Slider = @(436, 276, 11)
    Max = @(637, 295, 10)
    Empty = @(692, 326, 10)
    Checked = @(692, 326, 12)
    Confirm = @(526, 417, 12)
}

function Test-BPMarker($buffer, [string]$name) {
    return (Test-ClientMarker $buffer "bp_$name" $script:bpRegions[$name] 2)
}

function Get-BPProtectionAction([string]$stage, $screen) {
    if ($stage -eq 'Verify') {
        if ($screen.Ready -and $screen.Applied) { return 'Done' }
        return
    }
    if ($screen.Dialog) {
        if (-not $screen.Max) {
            if ($stage -in @('Start','Opened')) { return 'SetMax' }
            return
        }
        if ($screen.Checked -and $screen.Confirm) { return 'Confirm' }
        if ($screen.Empty -and -not $screen.Checked -and $stage -ne 'Checked') { return 'Check' }
        return
    }
    if ($stage -eq 'Start' -and $screen.Ready) { return 'Open' }
}

function Stop-BPProtection([string]$message, [bool]$completed = $false) {
    $script:bpRun = $null
    $script:bpButton.Enabled = $true
    $stopButton.Enabled = $script:running
    $color = if ($completed) { [Drawing.Color]::LightGreen } else { [Drawing.Color]::Orange }
    Set-Status $message $color
    Write-Log $message
}

function Invoke-BPProtectionTick($info, [datetime]$now) {
    $run = $script:bpRun
    if ($now -ge $run.Deadline) {
        Stop-BPProtection "강화 보호 중지 · 화면 확인 시간 초과 ($($run.Stage))"
        Queue-OperatorReport "강화 보호 중지 · 화면 확인 시간 초과 ($($run.Stage))"
        return
    }
    if ($now -lt $run.NextProbe) { return }
    $run.NextProbe = $now.AddMilliseconds(300)
    if ($info.Process -ne 'fczf' -or $info.Handle -ne $run.Handle) {
        Stop-BPProtection '강화 보호 중지 · FC 온라인 창을 선택한 뒤 다시 실행하세요.'
        Queue-OperatorReport '강화 보호 중지 · FC 온라인 창을 선택한 뒤 다시 실행하세요.'
        return
    }
    $frame = Get-ClubClientFrame $run.Handle
    if (-not $frame) {
        Stop-BPProtection '강화 보호 중지 · 16:9 게임 화면을 확인하세요.'
        Queue-OperatorReport '강화 보호 중지 · 16:9 게임 화면을 확인하세요.'
        return
    }
    $b = $frame.Buffer
    $screen = @{ Dialog = ((Test-BPMarker $b 'Slider') -and ((Test-BPMarker $b 'Tab') -or (Test-BPMarker $b 'ZeroTab'))) }
    if ($screen.Dialog) {
        $screen.Max = Test-BPMarker $b 'Max'
        $screen.Empty = Test-BPMarker $b 'Empty'
        $screen.Checked = Test-BPMarker $b 'Checked'
        $screen.Confirm = Test-BPMarker $b 'Confirm'
    } else {
        $screen.Ready = (Test-BPMarker $b 'Open') -and (Test-BPMarker $b 'Label')
        $screen.Applied = Test-BPMarker $b 'Applied'
    }
    $action = Get-BPProtectionAction $run.Stage $screen
    if (-not $action) { return }
    if ($action -eq 'Done') {
        Stop-BPProtection 'BP 강화 등급 보호 100% 적용 확인' $true
        return
    }
    $x, $y, $next = switch ($action) {
        'Open'    { 516, 477, 'Opened' }
        'SetMax'  { 610, 305, 'MaxRequested' }
        'Check'   { 698, 333, 'Checked' }
        'Confirm' { 548, 426, 'Verify' }
    }
    # The captured client may have moved or lost focus during recognition.
    $origin = New-Object FCNative+POINT
    $rect = New-Object FCNative+RECT
    if (-not [FCNative]::ClientToScreen($run.Handle,[ref]$origin) -or
        -not [FCNative]::GetClientRect($run.Handle,[ref]$rect) -or
        $origin.X -ne $frame.Origin.X -or $origin.Y -ne $frame.Origin.Y -or
        $rect.Right -ne $frame.Width -or $rect.Bottom -ne $frame.Height -or
        [FCNative]::GetForegroundWindow() -ne $run.Handle) {
        Stop-BPProtection '강화 보호 중지 · 게임 창이 변경됐습니다.'
        Queue-OperatorReport '강화 보호 중지 · 게임 창이 변경됐습니다.'
        return
    }
    if (-not [FCNative]::SendLeftClick(($origin.X + [int]($x*$frame.Width/960)), ($origin.Y + [int]($y*$frame.Height/540)))) {
        Stop-BPProtection '강화 보호 중지 · 게임 입력 실패'
        Queue-OperatorReport '강화 보호 중지 · 게임 입력 실패'
        return
    }
    $run.Stage = $next
    $run.NextProbe = $now.AddMilliseconds(550)
    $run.Deadline = $now.AddSeconds(8)
}

function Initialize-BPProtectionButton {
    $script:bpButton = [Windows.Forms.Button]::new()
    $script:bpButton.Text = 'BP 강화 보호 100%'
    $script:bpButton.SetBounds(590,238,205,42)
    $script:bpButton.FlatStyle = 'Flat'
    $script:bpButton.FlatAppearance.BorderSize = 0
    $script:bpButton.BackColor = [Drawing.ColorTranslator]::FromHtml('#263240')
    $script:bpButton.ForeColor = $captureButton.ForeColor
    $script:bpButton.Font = $captureButton.Font
    $script:bpButton.Add_Click({
        if ($script:running -or $script:coachRun -or $script:maintenancePlan -or $script:updateInstalling) {
            Write-Log '자동 진행, 시작 예약 또는 업데이트 종료 후 강화 보호를 실행하세요.'
            Set-Status '자동 진행·예약·업데이트 종료 후 사용하세요.' ([Drawing.Color]::Orange)
            return
        }
        $game = Get-FCWindowInfo
        if (-not $game) {
            Set-Status '강화 대상 선수를 선택하고 다시 실행하세요.' ([Drawing.Color]::Orange)
            return
        }
        $now = [DateTime]::UtcNow
        [void][FCNative]::SetForegroundWindow($game.Handle)
        $script:bpRun = @{ Handle=$game.Handle; Stage='Start'; NextProbe=$now.AddMilliseconds(500); Deadline=$now.AddSeconds(8) }
        $script:bpButton.Enabled = $false
        $stopButton.Enabled = $true
        Set-Status 'BP 강화 보호 설정 중 · F12 중지' ([Drawing.Color]::LightBlue)
    })
    $form.Controls.Add($script:bpButton)
}

$script:coachIds = [int[]]@(0,1,2,3,4,5,6,7,8,9,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,28,29,30,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51)
$script:coachTraits = @(
    '근거리 슛 향상',
    '근거리 슛 방어 (GK 전용)',
    '중거리 슛 향상',
    '중거리 슛 방어 (GK 전용)',
    '낮은 슛 향상',
    '낮은 슛 방어 (GK 전용)',
    '감아차기 향상',
    '감아차기 방어 (GK 전용)',
    '프리킥 향상',
    '프리킥 방어 (GK 전용)',
    '능숙한 몸 싸움',
    '스탠딩 태클 향상',
    '스탠딩 태클 회피',
    '슬라이딩 태클 향상',
    '슬라이딩 태클 회피',
    '높은 크로스 향상',
    '땅볼 크로스 향상',
    '크로스 향상',
    '로빙 쓰루 패스 향상',
    '쓰루 패스 향상',
    '침투 쓰루 패스 향상',
    '드라이브 땅볼 패스 향상',
    '로빙 패스 향상',
    '플레어 패스 향상',
    '스로우 향상 (GK 전용)',
    '침투 요청에 즉각 반응',
    '침투 패스 후 바로 침투',
    '퍼스트 터치 후 바로 이동',
    '페이스 업 드리블 향상',
    '전력 질주 숙달',
    '능숙한 압박',
    '중원을 지배하라',
    '안정적인 빌드업',
    '다이렉트 패스 전술 이해',
    '티키타카 전술 이해',
    '왼쪽 측면을 노려라',
    '오른쪽 측면을 노려라',
    '침착하게 골 찬스 만들기',
    '빠른 템포 공격',
    '역 압박',
    '재정비',
    '수비 진영에서 역습 전개',
    '타겟맨 특화',
    '빠른 볼 배급',
    '전진 압박 이해',
    '가로채기 노리기',
    '좌측 수비 강화',
    '우측 수비 강화'
)
$script:coachRegions = @{
    Tab = @(150,75,10)
    RefreshText = @(706,471,13)
    Refresh50 = @(780,472,10)
    Cost300 = @(288,314,10)
    Empty = @(192,285,5)
    LowerEmpty = @(192,381,5)
    Prompt = @(440,297,9)
    Approve300 = @(644,253,10)
    Enabled = @(482,382,10)
    Success = @(422,277,9)
}
function Test-CoachMarker($buffer,[string]$name,[int]$column=0) {
    $r = $script:coachRegions[$name]
    $region = @(($r[0]+238*$column),$r[1],$r[2])
    return (Test-ClientMarker $buffer "coach_$name" $region 2)
}

function Get-CoachColumnState($buffer,[int]$column) {
    if ((Test-CoachMarker $buffer 'Cost300' $column) -or [FCCoachVision]::HasTraitIcons($buffer,$column)) { return 'Candidate' }
    if (Test-CoachMarker $buffer 'Empty' $column) { return 'Empty' }
    return 'Unknown'
}

function Save-CoachBoardDiagnostic($buffer) {
    if (-not $buffer) { return }
    try {
        $bitmap=[FCTemplateMatcher]::ToBitmap($buffer)
        try {
            $area=[Drawing.Rectangle]::new(120,69,720,428)
            $crop=$bitmap.Clone($area,[Drawing.Imaging.PixelFormat]::Format32bppArgb)
            try { $path=Join-Path $script:captureDir 'coach-board.png'; $crop.Save($path,[Drawing.Imaging.ImageFormat]::Png); return $path }
            finally { $crop.Dispose() }
        } finally { $bitmap.Dispose() }
    } catch { Write-Log '훈련코치 판독 진단 화면을 저장하지 못했습니다.' }
}

function Read-CoachReference([byte[]]$bytes) {
    if ($bytes.Length -lt 24 -or $bytes.Length -gt 262144 -or
        [BitConverter]::ToString($bytes,0,8) -ne '89-50-4E-47-0D-0A-1A-0A') { throw '기준 PNG 형식 오류' }
    foreach ($offset in 16,20) {
        $size=[Net.IPAddress]::NetworkToHostOrder([BitConverter]::ToInt32($bytes,$offset))
        if ($size -lt 12 -or $size -gt 512) { throw '기준 PNG 크기 오류' }
    }
    $stream=[IO.MemoryStream]::new($bytes)
    try {
        $image=[Drawing.Bitmap]::new($stream)
        try { $signature=[FCCoachVision]::Reference([FCTemplateMatcher]::FromBitmap($image)) }
        finally { $image.Dispose() }
    } finally { $stream.Dispose() }
    if (-not $signature) { throw '기준 아이콘 판독 실패' }
    return ,$signature
}

function Update-CoachCatalog($run) {
    if (-not $script:coachCatalog) {
        $script:coachCatalog=[Collections.Generic.Dictionary[int,double[]]]::new()
    }
    $dir=Join-Path $script:appDir '.coach-icons'
    [void][IO.Directory]::CreateDirectory($dir)
    foreach ($id in $script:coachIds) {
        if ($script:coachCatalog.ContainsKey($id)) { continue }
        $file='training_trait_icon_{0:000}.png' -f $id
        $path=Join-Path $dir $file
        if (-not $run.IconTask -and [IO.File]::Exists($path)) {
            try { $script:coachCatalog.Add($id,(Read-CoachReference ([IO.File]::ReadAllBytes($path)))); continue }
            catch { Write-Log "기준 아이콘 다시 받기 · $file" }
        }
        if (-not $run.IconTask) {
            $run.IconTask=$run.IconHttp.GetByteArrayAsync("https://fco.dn.nexoncdn.co.kr/live/externalAssets/common/trainingTrait/$file")
            $script:coachStatus.Text="기준 아이콘 준비 · $($script:coachCatalog.Count) / $($script:coachIds.Count)"
            return
        }
        if (-not $run.IconTask.IsCompleted) { return }
        try {
            $bytes=$run.IconTask.GetAwaiter().GetResult()
            $sig=Read-CoachReference $bytes
            $tmp=$path+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
            try {
                [IO.File]::WriteAllBytes($tmp,$bytes)
                if ([IO.File]::Exists($path)) { [IO.File]::Replace($tmp,$path,[System.Management.Automation.Language.NullString]::Value) }
                else { [IO.File]::Move($tmp,$path) }
            } finally { [IO.File]::Delete($tmp) }
            $script:coachCatalog.Add($id,$sig)
        } catch { throw "기준 아이콘 준비 실패 · $file (넥슨 CDN 연결 또는 캐시 파일 확인)" }
        $run.IconTask=$null
    }
    [void][FCNative]::SetForegroundWindow($run.Handle)
    Set-CoachStage $run 'Prepare' 550
    $script:coachStatus.Text='후보 특성 이미지 비교 중 · F12 중지'
}

function Find-CoachImageCombination($rows,[int[]]$ids) {
    for ($i=0;$i -lt $rows.Count;$i++) {
        $wanted=@($rows[$i].ids)
        if ($wanted.Count -and @($wanted | Where-Object { $_ -notin $ids }).Count -eq 0) { return ($i+1) }
    }
    return 0
}

function Send-CoachInput($run,$frame,[int]$x,[int]$y,[switch]$Click) {
    $origin = New-Object FCNative+POINT
    $rect = New-Object FCNative+RECT
    if ([FCNative]::GetForegroundWindow() -ne $run.Handle -or
        -not [FCNative]::ClientToScreen($run.Handle,[ref]$origin) -or
        -not [FCNative]::GetClientRect($run.Handle,[ref]$rect) -or
        $origin.X -ne $frame.Origin.X -or $origin.Y -ne $frame.Origin.Y -or
        $rect.Right -ne $frame.Width -or $rect.Bottom -ne $frame.Height) { throw '게임 창이 변경되었습니다.' }
    $sx=$origin.X+[int]($x*$frame.Width/960)
    $sy=$origin.Y+[int]($y*$frame.Height/540)
    $ok=if ($Click) { [FCNative]::SendLeftClick($sx,$sy) } else { [FCNative]::SetCursorPos($sx,$sy) }
    if (-not $ok) { throw '마우스 입력에 실패했습니다.' }
}

function Stop-CoachRun([string]$message) {
    if ($script:coachRun.IconHttp) { $script:coachRun.IconHttp.Dispose() }
    $script:coachRun=$null
    $script:coachControls.Enabled=$true
    $stopButton.Enabled=$false
    $script:coachStatus.Text=$message
    Set-Status $message ([Drawing.Color]::LightBlue)
    Write-Log $message
}

function Set-CoachStage($run,[string]$stage,[int]$delay=250) {
    $now=[datetime]::UtcNow
    $run.Stage=$stage
    $run.BoardWait=''
    $run.Next=$now.AddMilliseconds($delay)
    $run.Deadline=$now.AddSeconds(8)
}

# All paid actions are single transitions. A delayed redraw cannot repeat a click.
function Invoke-CoachTick($info) {
    $r=$script:coachRun
    $now=[datetime]::UtcNow
    if ($now -lt $r.Next) { return }
    $r.Next=$now.AddMilliseconds(350)
    try {
        if ($r.Stage -eq 'Icons') { Update-CoachCatalog $r; return }
        if ($now -gt $r.Deadline) {
            if ($r.Stage -eq 'Board') {
                throw "모집 목록 확인 시간 초과 · $($r.BoardWait)"
            }
            throw "화면 판독 시간 초과 ($($r.Stage))"
        }
        if ($info.Process -ne 'fczf' -or $info.Handle -ne $r.Handle) { throw 'FC 온라인 창이 비활성 상태입니다.' }
        $frame=Get-ClubClientFrame $r.Handle
        if (-not $frame) { throw '16:9 게임 화면을 확인하세요.' }
        $b=$frame.Buffer
        $r.DiagnosticFrame=$b
        if ($r.Stage -eq 'Prepare') {
            if (-not (Test-CoachMarker $b 'Tab')) { return }
            Send-CoachInput $r $frame 665 452
            Set-CoachStage $r 'Board' 450
            return
        }
        if ($r.Stage -eq 'Success') {
            if (Test-CoachMarker $b 'Success') { Stop-CoachRun "조합 $($r.Match) 코치 고용 성공 · 사용 $($r.Spent) CP" }
            return
        }
        if ($r.Stage -eq 'Confirm') {
            if (-not (Test-CoachMarker $b 'Prompt')) { return }
            if (-not (Test-CoachMarker $b 'Approve300') -or
                -not [FCCoachVision]::SameCard($r.Board,$b,$r.Column,$true)) { throw '확인창의 특성 또는 고용 비용이 다릅니다.' }
            if (-not (Test-CoachMarker $b 'Enabled')) { return }
            if ($r.Spent+300 -gt $r.Limit) { throw '고용 CP 한도에 도달했습니다.' }
            Send-CoachInput $r $frame 526 389 -Click
            $r.Spent+=300
            Set-CoachStage $r 'Success'
            return
        }
        if (-not (Test-CoachMarker $b 'Tab')) { $r.BoardWait='훈련 코치 모집 탭 미인식'; return }
        switch ($r.Stage) {
            'Board' {
                $present=@()
                foreach ($col in 0..2) {
                    if (-not (Test-CoachMarker $b 'LowerEmpty' $col)) { throw '추가 후보가 있는 모집 화면은 지원하지 않습니다.' }
                    $state=Get-CoachColumnState $b $col
                    if ($state -eq 'Candidate') { $present+= $col }
                    elseif ($state -eq 'Unknown') { $r.BoardWait="후보 $('ABC'[$col]) 특성 아이콘 또는 빈 칸 미인식"; return }
                }
                if ($r.Board -and ($present -join ',') -eq ($r.Candidates -join ',')) {
                    $changed=$false
                    foreach ($col in $present) {
                        if (-not [FCCoachVision]::SameCard($r.Board,$b,$col,$false)) { $changed=$true; break }
                    }
                    if (-not $changed) { $r.BoardWait='새로 모집 후 후보 변경 미확인'; return }
                }
                $r.Match=0
                foreach ($col in $present) {
                    $ids=@(foreach ($slot in 0..2) { [FCCoachVision]::Identify($b,$col,$slot,$script:coachCatalog) })
                    if (-1 -in $ids -or @($ids | Select-Object -Unique).Count -ne 3) {
                        $r.BoardWait="후보 $('ABC'[$col])의 특성 이미지 구분 불가"
                        return
                    }
                    $r.Match=Find-CoachImageCombination $r.Rows $ids
                    if ($r.Match) { $r.Column=$col; break }
                }
                $r.Board=$b; $r.Candidates=$present
                Set-CoachStage $r 'Decide'
            }
            'Decide' {
                foreach ($col in 0..2) {
                    if (-not (Test-CoachMarker $b 'LowerEmpty' $col)) { throw '후보 목록이 변경되었습니다.' }
                    if ($col -in $r.Candidates) {
                        if ((Get-CoachColumnState $b $col) -ne 'Candidate' -or
                            -not [FCCoachVision]::SameCard($r.Board,$b,$col,$false)) { throw '후보 목록이 변경되었습니다.' }
                    } elseif (-not (Test-CoachMarker $b 'Empty' $col)) { throw '후보 목록이 변경되었습니다.' }
                }
                if ($r.Match) {
                    if ($r.Spent+300 -gt $r.Limit) { throw '고용 CP 한도에 도달했습니다.' }
                    if (-not (Test-CoachMarker $b 'Cost300' $r.Column)) { throw "후보 $('ABC'[$r.Column])의 고용 비용 300 CP를 확인하지 못했습니다." }
                    Send-CoachInput $r $frame (305+238*$r.Column) 320 -Click
                    Set-CoachStage $r 'Confirm' 450
                } else {
                    if ($r.Spent+50+300 -gt $r.Limit) { Stop-CoachRun "새로 모집 후 고용할 CP 한도가 부족합니다. 사용 $($r.Spent) CP"; return }
                    if (-not (Test-CoachMarker $b 'RefreshText') -or -not (Test-CoachMarker $b 'Refresh50')) { throw '새로 모집 버튼의 50 CP를 확인하지 못했습니다.' }
                    Send-CoachInput $r $frame 759 479 -Click
                    $r.Spent+=50
                    $script:coachStatus.Text="새로 모집 · 사용 $($r.Spent) / $($r.Limit) CP"
                    Set-CoachStage $r 'Board' 950
                }
            }
        }
    } catch {
        $reason="코치 모집 중지 · $($_.Exception.Message)"
        $capture=Save-CoachBoardDiagnostic $r.DiagnosticFrame
        Stop-CoachRun $reason
        Queue-OperatorReport $reason $capture
    }
}

function Get-CoachPreferences {
    $rows=@()
    for ($row=0;$row -lt 4;$row++) {
        $traits=@(foreach ($slot in 0..2) {
            $box=$script:coachBoxes[$row*3+$slot]
            if ($box.SelectedIndex -gt 0) { [string]$box.SelectedItem }
        })
        if (@($traits | Select-Object -Unique).Count -ne $traits.Count) { throw "조합 $($row+1)에 중복 특성이 있습니다." }
        $rows+=@{traits=$traits}
    }
    return @{rows=$rows;limit=[int]$script:coachBudget.Value}
}

function Save-CoachPreferences($prefs) {
    $temp=$script:coachPath+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
    try {
        [IO.File]::WriteAllText($temp,($prefs | ConvertTo-Json -Depth 5))
        if ([IO.File]::Exists($script:coachPath)) { [IO.File]::Replace($temp,$script:coachPath,[System.Management.Automation.Language.NullString]::Value) }
        else { [IO.File]::Move($temp,$script:coachPath) }
    } finally { [IO.File]::Delete($temp) }
}

function Start-CoachRun {
    try {
        if ($script:running -or $script:coachRun -or $script:bpRun -or $script:maintenancePlan -or $script:updateInstalling) {
            throw '자동 진행·예약·업데이트 종료 후 실행하세요.'
        }
        $prefs=Get-CoachPreferences
        if (-not @($prefs.rows | Where-Object { $_.traits.Count }).Count) { throw '원하는 조합을 하나 이상 입력하세요.' }
        Save-CoachPreferences $prefs
        $game=Get-FCWindowInfo
        if (-not $game) { throw 'FC 온라인의 훈련 코치 모집 화면을 여세요.' }
        $mapped=@(foreach ($row in $prefs.rows) {
            @{ids=@(foreach ($trait in $row.traits) { $script:coachIds[[Array]::IndexOf($script:coachTraits,$trait)] })}
        })
        [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
        $client=[Net.Http.HttpClient]::new()
        $client.Timeout=[TimeSpan]::FromSeconds(10)
        $client.MaxResponseContentBufferSize=262144
        $script:coachRun=@{Handle=$game.Handle;Rows=$mapped;Limit=$prefs.limit;Spent=0;IconHttp=$client}
        Set-CoachStage $script:coachRun 'Icons' 0
        $script:coachControls.Enabled=$false
        $stopButton.Enabled=$true
        $script:coachStatus.Text='모집 후보 확인 중 · F12 중지'
        Set-Status $script:coachStatus.Text ([Drawing.Color]::LightBlue)
    } catch { $script:coachStatus.Text=$_.Exception.Message }
}

function Initialize-CoachView {
    $page=[Windows.Forms.TabPage]::new('훈련코치')
    $page.BackColor=$script:runSettingsPage.BackColor
    $page.ForeColor=$form.ForeColor
    $script:settingsTabs.TabPages.Add($page)
    $nav=[Windows.Forms.Button]::new()
    $nav.Text='훈련코치'
    $nav.Tag=$script:settingsTabs.TabPages.Count-1
    $nav.SetBounds(24,528,140,40)
    $nav.FlatStyle='Flat'
    $nav.FlatAppearance.BorderSize=0
    $nav.BackColor=$form.BackColor
    $nav.ForeColor=$script:tabNav[1].ForeColor
    $nav.Font=$script:tabNav[1].Font
    $nav.TextAlign='MiddleLeft'
    $nav.Padding=[Windows.Forms.Padding]::new(12,0,0,0)
    $nav.Add_Click({param($sender,$e) $script:settingsTabs.SelectedIndex=[int]$sender.Tag})
    $script:tabNav+=,$nav
    $form.Controls.Add($nav)

    $panel=[Windows.Forms.Panel]::new()
    $panel.SetBounds(12,3,915,260)
    $page.Controls.Add($panel)
    $script:coachControls=$panel
    $hint=[Windows.Forms.Label]::new()
    $hint.SetBounds(7,4,900,32)
    $hint.Text='한 줄에 원하는 특성 1~3개를 선택하세요. 어느 한 줄을 모두 갖춘 코치 1명을 고용합니다.'
    $panel.Controls.Add($hint)
    $script:coachBoxes=@()
    for ($row=0;$row -lt 4;$row++) {
        $y=40+40*$row
        $label=[Windows.Forms.Label]::new()
        $label.SetBounds(8,$y,78,31)
        $label.Text="조합 $($row+1)"
        $panel.Controls.Add($label)
        for ($slot=0;$slot -lt 3;$slot++) {
            $box=[Windows.Forms.ComboBox]::new()
            $box.DropDownStyle='DropDownList'
            $box.SetBounds((85+273*$slot),$y,263,32)
            [void]$box.Items.Add('선택 안 함')
            $box.Items.AddRange([object[]]$script:coachTraits)
            $box.SelectedIndex=0
            $panel.Controls.Add($box)
            $script:coachBoxes+=,$box
        }
    }
    $caption=[Windows.Forms.Label]::new()
    $caption.Text='총 CP 한도'
    $caption.SetBounds(8,212,112,34)
    $panel.Controls.Add($caption)
    $script:coachBudget=[Windows.Forms.NumericUpDown]::new()
    $script:coachBudget.SetBounds(123,209,135,32)
    $script:coachBudget.Maximum=1000000
    $script:coachBudget.Minimum=300
    $script:coachBudget.Value=300
    $script:coachBudget.Increment=50
    $panel.Controls.Add($script:coachBudget)
    $save=[Windows.Forms.Button]::new()
    $save.Text='조합 저장'
    $save.SetBounds(300,203,152,41)
    $save.Add_Click({
        try { Save-CoachPreferences (Get-CoachPreferences); $script:coachStatus.Text='조합과 CP 한도를 저장했습니다.' }
        catch { $script:coachStatus.Text=$_.Exception.Message }
    })
    $start=[Windows.Forms.Button]::new()
    $start.Text='자동 모집 시작'
    $start.SetBounds(467,203,188,41)
    $start.Add_Click({Start-CoachRun})
    foreach ($button in @($save,$start)) {
        $button.BackColor=[Drawing.ColorTranslator]::FromHtml('#263240')
        $button.FlatStyle='Flat'
        $panel.Controls.Add($button)
    }
    $script:coachStatus=[Windows.Forms.Label]::new()
    $script:coachStatus.SetBounds(18,265,894,55)
    $script:coachStatus.Text='새로 모집 50 CP · 고용 300 CP · 게임의 훈련 코치 모집 탭에서 시작하세요.'
    $page.Controls.Add($script:coachStatus)
    $script:coachPath=Join-Path $script:appDir 'coach-preferences.json'
    if ([IO.File]::Exists($script:coachPath)) {
        try {
            $saved=[IO.File]::ReadAllText($script:coachPath) | ConvertFrom-Json
            if ($saved.rows.Count -ne 4 -or $saved.limit -lt 300 -or $saved.limit -gt 1000000) {throw 'invalid'}
            for ($row=0;$row -lt 4;$row++) {
                $traits=@($saved.rows[$row].traits)
                if ($traits.Count -gt 3) {throw 'invalid'}
                for ($slot=0;$slot -lt $traits.Count;$slot++) {
                    if ($traits[$slot] -notin $script:coachTraits) {throw 'invalid'}
                    $script:coachBoxes[$row*3+$slot].SelectedItem=$traits[$slot]
                }
            }
            $script:coachBudget.Value=$saved.limit
        } catch {
            foreach ($box in $script:coachBoxes) {$box.SelectedIndex=0}
            $script:coachStatus.Text='저장된 설정을 읽지 못했습니다. 조합을 다시 선택하세요.'
        }
    }
}

function Get-RemotePairLink([string]$inputText) {
    $link = $null
    if (-not [Uri]::TryCreate($inputText.Trim(), [UriKind]::Absolute, [ref]$link) -or
        $link.Scheme -ne 'https' -or $link.UserInfo -or $link.Query -or $link.AbsolutePath -ne '/' -or
        $link.Fragment -cnotmatch '^#[A-Za-z0-9_-]{43}$') { return }
    return @{Origin=$link.GetLeftPart([UriPartial]::Authority); Code=$link.Fragment.Substring(1)}
}

function Get-RemoteControlStatus {
    $mode = if ($script:coachRun) { '훈련코치 모집 중' } elseif ($script:bpRun) { '강화 보호 설정 중' } elseif ($script:running) {
        if ($script:paused) { '자동 진행 일시정지' } else { '자동 진행 중' }
    } else { '자동 진행 중지' }
    if ($script:running -and $script:stopAfterCurrentMatch) { $mode += ' · 이번 판 후 중지 예약' }
    if ($script:maintenancePlan) { $mode += ' · 점검 후 시작 예약' }
    return "$mode · $(Get-MatchSummary)"
}

function Invoke-RemoteControlCommand([string]$command) {
    switch -CaseSensitive ($command) {
        'start' {
            if ($script:running) { return '이미 자동 진행 중입니다.' }
            if ($script:updateInstalling -or $script:coachRun -or $script:bpRun) { return '코치 모집, 업데이트 또는 강화 보호 설정 중입니다.' }
            if (-not (Test-GameProcessPresent)) { return 'FC 온라인을 먼저 실행하세요.' }
            Start-Automation -Remote
            if ($script:running) { return '자동 진행을 시작했습니다.' }
            return '자동 진행을 시작할 수 없습니다.'
        }
        'finish' {
            if (-not $script:running) { return '자동 진행이 중지되어 있습니다.' }
            if (-not $script:stopAfterCurrentMatch) { Toggle-FinishMatchReservation }
            return '이번 판 완료 후 중지 예약됨'
        }
        'stop' {
            Stop-Automation 'Discord 원격 중지'
            return '자동 진행 중지됨'
        }
        default { return '지원하지 않는 명령입니다.' }
    }
}

function Start-RemoteRequest([string]$operation, [string]$origin, $body) {
    $request = [Net.Http.HttpRequestMessage]::new([Net.Http.HttpMethod]::Post, "$origin/$operation")
    try {
        if ($operation -eq 'poll') {
            $request.Headers.Authorization = [Net.Http.Headers.AuthenticationHeaderValue]::new('Bearer',$script:remoteDevice.token)
        }
        $request.Content = [Net.Http.StringContent]::new(($body | ConvertTo-Json -Compress),[Text.Encoding]::UTF8,'application/json')
        $script:remotePending = @{Kind=$operation; Origin=$origin; Request=$request; Task=$script:remoteHttp.SendAsync($request)}
    } catch { $request.Dispose(); throw }
}

function Clear-RemoteDevice {
    # Stop dispatching before touching disk, including when cleanup fails.
    $script:remoteDevice = $null
    $script:remoteAck = ''
    $script:remoteResult = ''
    $script:remoteSession = [Guid]::NewGuid().ToString('N')
    [IO.File]::Delete($script:remotePath)
}

function Update-RemoteControl {
    if ($null -eq $script:remoteDevice -and $null -eq $script:remotePending) { return }
    $now = [datetime]::UtcNow
    $pending = $script:remotePending
    try {
        if (-not $pending) {
            if ($now -lt $script:remoteDue) { return }
            $body = @{session=$script:remoteSession; status=(Get-RemoteControlStatus); ack=$script:remoteAck; result=$script:remoteResult}
            Start-RemoteRequest 'poll' $script:remoteDevice.origin $body
            return
        }
        if (-not $pending.Task.IsCompleted) { return }
        $script:remotePending = $null
        $response = $null
        try {
            $response = $pending.Task.GetAwaiter().GetResult()
            if (-not $response.IsSuccessStatusCode) {
                if ($response.StatusCode -eq [Net.HttpStatusCode]::Unauthorized -and $pending.Kind -eq 'poll') {
                    Clear-RemoteDevice
                    $script:remoteLabel.Text = '연결 해제됨 · /연결 링크로 다시 연결하세요.'
                    return
                }
                throw 'HTTP 요청 실패'
            }
            $data = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult() | ConvertFrom-Json
        } finally {
            if ($response) { $response.Dispose() }
            $pending.Request.Dispose()
        }
        if ($pending.Kind -eq 'pair') {
            if ($data.token -cnotmatch '^[A-Za-z0-9_-]{43}$' -or $data.owner -notmatch '^\d{17,20}$') { throw '잘못된 연결 응답' }
            $device = @{origin=$pending.Origin; token=$data.token; owner=$data.owner}
            $cipher = Protect-DiscordWebhook ($device | ConvertTo-Json -Compress)
            $tmpPath = "$($script:remotePath).$($script:remoteSession).tmp"
            try {
                [IO.File]::WriteAllText($tmpPath,$cipher)
                if ([IO.File]::Exists($script:remotePath)) { [IO.File]::Replace($tmpPath,$script:remotePath,$null) }
                else { [IO.File]::Move($tmpPath,$script:remotePath) }
            } finally { [IO.File]::Delete($tmpPath) }
            $script:remoteDevice = $device
            $script:remoteLabel.Text = "연결됨 · Discord ID $($device.owner)"
            $script:remoteDue = $now
            return
        }
        if (-not $script:remoteDevice) { return }
        $script:remoteLabel.Text = "연결됨 · Discord ID $($script:remoteDevice.owner)"
        $script:remoteDue = $now.AddSeconds(2)
        $cmd = $data.command
        if ($null -ne $cmd -and $cmd.id -match '^\d{17,20}$' -and $cmd.id -ne $script:remoteAck) {
            $script:remoteAck = [string]$cmd.id
            if ([long]$cmd.expires -le [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()) {
                $script:remoteResult = '명령 유효 시간이 지났습니다.'
            } else {
                try { $script:remoteResult = Invoke-RemoteControlCommand $cmd.name }
                catch { $script:remoteResult = if ($_.Exception -is [InvalidOperationException]) { $_.Exception.Message } else { '실행 실패 · PC에서 실행 기록을 확인하세요.' } }
            }
            Write-Log "Discord 원격 조작 · $($script:remoteResult)"
            $script:remoteDue = $now
        }
    } catch {
        if ($pending.Kind -eq 'pair') { $script:remoteLabel.Text = '연결 실패 · /연결에서 새 링크를 받아 다시 입력하세요.' }
        else {
            $script:remoteLabel.Text = '원격 연결 대기 · 5초 후 재시도합니다.'
            $script:remoteDue = $now.AddSeconds(5)
        }
    }
}

function Initialize-RemoteControl {
    $handler = [Net.Http.HttpClientHandler]::new()
    $handler.AllowAutoRedirect = $false
    $script:remoteHttp = [Net.Http.HttpClient]::new($handler)
    $script:remoteHttp.Timeout = [TimeSpan]::FromSeconds(6)
    $script:remoteHttp.MaxResponseContentBufferSize = 16384
    $script:remoteSession = [Guid]::NewGuid().ToString('N')
    $script:remotePath = Join-Path $script:appDir 'discord-device.dat'
    $script:remoteDue = [datetime]::MinValue
    $group = [Windows.Forms.GroupBox]::new()
    $group.Text = '원격 조작 · 내 Discord 계정'
    $group.SetBounds(14,170,908,144)
    $group.ForeColor = $form.ForeColor
    $script:notifyPage.Controls.Add($group)
    $script:remoteLink = [Windows.Forms.TextBox]::new()
    $script:remoteLink.SetBounds(18,36,545,32)
    $script:remoteLink.UseSystemPasswordChar = $true
    $connect = [Windows.Forms.Button]::new()
    $connect.Text = '계정 연결'
    $connect.SetBounds(575,32,125,39)
    $forget = [Windows.Forms.Button]::new()
    $forget.Text = '이 PC 연결 지우기'
    $forget.SetBounds(709,32,178,39)
    foreach ($button in @($connect,$forget)) {
        $button.FlatStyle = 'Flat'
        $button.BackColor = [Drawing.ColorTranslator]::FromHtml('#263240')
    }
    $script:remoteLabel = [Windows.Forms.Label]::new()
    $script:operatorOpt=[Windows.Forms.CheckBox]::new()
    $script:operatorOpt.Text='운영자에게 오류 자동 전송 (진단정보, 최근 로그 40줄, 해당 오류 캡처)'
    $script:operatorOpt.SetBounds(18,72,870,30)
    $script:operatorOpt.Add_Click({ Save-DiscordSettings })
    $group.Controls.Add($script:operatorOpt)
    $script:operatorQueue=[Collections.Queue]::new()
    $reportHandler=[Net.Http.HttpClientHandler]::new()
    $reportHandler.AllowAutoRedirect=$false
    $script:operatorHttp=[Net.Http.HttpClient]::new($reportHandler)
    $script:operatorHttp.Timeout=[TimeSpan]::FromSeconds(14)
    $script:operatorHttp.MaxResponseContentBufferSize=16384
    $script:remoteLabel.SetBounds(18,103,860,38)
    $script:remoteLabel.Text = 'Discord에서 /연결 실행 후 본인의 비공개 링크를 붙여 넣으세요.'
    foreach ($item in @($script:remoteLink,$connect,$forget,$script:remoteLabel)) { $group.Controls.Add($item) }
    $connect.Add_Click({
        if ($script:remoteDevice) { $script:remoteLabel.Text='계정을 변경하려면 이 PC 연결을 먼저 지우세요.'; return }
        if ($script:remotePending) { return }
        $link = Get-RemotePairLink $script:remoteLink.Text
        if (-not $link) { $script:remoteLabel.Text='본인의 /연결 응답에서 HTTPS 링크 전체를 복사하세요.'; return }
        $script:remoteLink.Clear()
        try {
            Start-RemoteRequest 'pair' $link.Origin @{code=$link.Code}
            $script:remoteLabel.Text = '계정 연결 중…'
        } catch { $script:remoteLabel.Text = '연결 요청 실패 · 다시 시도하세요.' }
    })
    $forget.Add_Click({
        if ($script:remotePending -and $script:remotePending.Kind -eq 'pair') { return }
        try {
            Clear-RemoteDevice
            $script:remoteLabel.Text = '이 PC 연결을 지웠습니다. 서버 연결은 Discord /연결해제로 삭제할 수 있습니다.'
        } catch { $script:remoteLabel.Text='이 PC에서 저장한 연결 정보를 삭제하지 못했습니다.' }
    })
    if ([IO.File]::Exists($script:remotePath)) {
        try {
            $secure = ConvertTo-SecureString ([IO.File]::ReadAllText($script:remotePath))
            $cred = [Net.NetworkCredential]::new('device',$secure)
            $saved = $cred.Password | ConvertFrom-Json
            if ($saved.token -cnotmatch '^[A-Za-z0-9_-]{43}$' -or $saved.owner -notmatch '^\d{17,20}$' -or
                -not (Get-RemotePairLink "$($saved.origin)/#$($saved.token)")) { throw 'invalid' }
            $script:remoteDevice = $saved
            $script:remoteLabel.Text = '저장한 계정으로 연결 중…'
        } catch { $script:remoteLabel.Text='연결 정보를 읽지 못했습니다. /연결 링크를 다시 입력하세요.' }
    }
}

function Start-Automation([switch]$Remote) {
    if ($script:running -or $script:coachRun -or $script:bpRun -or $script:updateInstalling) { return }
    $script:parkingMode = $parkingModeRadio.Checked
    if ($script:parkingMode) {
        if ($null -eq $script:startingRankPoints -or $null -eq $script:startingRankReadAt -or
            ([DateTime]::Now - $script:startingRankReadAt).TotalMinutes -gt 5) {
            if ($Remote) { throw [InvalidOperationException]::new('먼저 챔피언스 감독 랭킹 화면에서 시작점수를 읽어 주세요. 인식 후 5분 안에 시작해야 합니다.') }
            Show-TopmostError '먼저 챔피언스 감독 랭킹 화면에서 시작점수를 읽어 주세요. 인식 후 5분 안에 시작해야 합니다.' '주차 시작점수 미확인'
            return
        }
        if ([int]$targetPointsBox.Value -le [int]$script:startingRankPoints) {
            if ($Remote) { throw [InvalidOperationException]::new('목표점수는 시작점수보다 커야 합니다.') }
            Show-TopmostError '목표점수는 시작점수보다 커야 합니다.' '주차 목표점수 확인'
            return
        }
        if ($minimumPointsCheck.Checked -and [int]$minimumPointsBox.Value -ge [int]$script:startingRankPoints) {
            if ($Remote) { throw [InvalidOperationException]::new('최저점수는 시작점수보다 작아야 합니다.') }
            Show-TopmostError '최저점수는 시작점수보다 작아야 합니다.' '주차 최저점수 확인'
            return
        }
        $script:currentRankPoints = [int]$script:startingRankPoints
        $script:rankResyncRequired = $false
    }
    $script:runStartMatchCount = [int]$script:sessionMatchCount
    $script:runMatchLimit = if ($script:runLimitCheck.Checked) { [int]$script:runLimitBox.Value } else { 0 }
    $info = Get-ForegroundInfo
    # A rank reading authorizes one run only. After stopping, the game may
    # have advanced, so restarting requires another confirmed reading.
    $script:startingRankReadAt = $null
    $script:running = $true
    $script:gamePresence = @{Observed=(Test-GameProcessPresent)}
    $script:clientInputBlocked = -not $script:gamePresence.Observed
    if ($script:maintenancePlan -and $script:clientInputBlocked) { $script:maintenancePlan.Interrupted = $true }
    $script:nextClientPoll = [DateTime]::MinValue
    $script:paused = $onlyFcCheck.Checked -and -not $info.Allowed
    $script:nextScanDue = [DateTime]::Now.AddMilliseconds(500)
    $script:resumeStableSince = $null
    $script:lastTemplateActions.Clear()
    $script:lastRecognizedFile = ""
    $script:sameScreenActionCount = 0
    $script:sameScreenSince = [DateTime]::Now
    $script:previousVisualFrame = $null
    $script:lastVisualChangeAt = [DateTime]::Now
    $script:lastProgressAt = [DateTime]::Now
    $script:stuckAlertActive = $false
    $script:stopAfterCurrentMatch = $false
    $script:requiredStopAfterMatch = $false
    $script:clubState=''
    $script:missionState=''
    $script:rewardRecoveryDeadline=$null
    $script:rewardRecoveryMatchCount=$null
    $script:tierNoticeMatchCount=$null
    $script:rewardAfterMatch=$null
    $script:manualClub=$false
    $script:manualMission=$false
    if($script:missionCheck){$script:missionCheck.Enabled=$false}
    if($script:clubCheck){$script:clubCheck.Enabled=$false}
    Update-RewardButton
    $script:runLimitCheck.Enabled = $false
    $script:runLimitBox.Enabled = $false
    Update-RunProgress
    $startButton.Enabled = $false
    $stopButton.Enabled = $true
    $finishMatchButton.Enabled = $true
    $generalModeRadio.Enabled = $false
    $parkingModeRadio.Enabled = $false
    $readRankButton.Enabled = $false
    $targetPointsBox.Enabled = $false
    $minimumPointsCheck.Enabled = $false
    $minimumPointsBox.Enabled = $false
    $finishMatchButton.Text = "이번 판까지만 (F8)"
    $finishMatchButton.BackColor = [Drawing.ColorTranslator]::FromHtml('#263240')
    if ($script:paused) {
        Set-Status "FC 창 대기 중" ([Drawing.Color]::FromArgb(236, 190, 86))
        Write-Log "자동 진행을 준비했습니다. FC ONLINE 창을 선택하면 시작합니다."
    } else {
        Set-Status "화면 인식 중" ([Drawing.Color]::FromArgb(83, 220, 120))
        Write-Log "화면 인식 자동 진행을 시작했습니다."
    }
}

function Stop-Automation([string]$reason) {
    if ($script:coachRun) { Stop-CoachRun "코치 모집 중지 · $reason"; return }
    if ($script:bpRun) { Stop-BPProtection "강화 보호 중지 · $reason"; return }
    Cancel-MaintenanceStart "자동 시작 예약 취소 ($reason)"
    if (-not $script:running) { return }
    # Release all mapped keys defensively.
    [void][FCNative]::SendScanCode(0x39, $true)
    [void][FCNative]::SendScanCode(0x1F, $true)
    [void][FCNative]::SendVirtualKey(0x53, $true)
    [void][FCNative]::SendScanCode(0x01, $true)
    $script:running = $false
    $script:paused = $false
    $script:stopAfterCurrentMatch = $false
    $script:requiredStopAfterMatch = $false
    $script:clubState=''
    $script:missionState=''
    $script:rewardRecoveryDeadline=$null
    $script:rewardRecoveryMatchCount=$null
    $script:tierNoticeMatchCount=$null
    $script:rewardAfterMatch=$null
    $script:manualClub=$false
    $script:manualMission=$false
    Update-RewardButton
    if($script:missionCheck){$script:missionCheck.Enabled=$true}
    if($script:clubCheck){$script:clubCheck.Enabled=$true}
    $script:runLimitCheck.Enabled = $true
    $script:runLimitBox.Enabled = $script:runLimitCheck.Checked
    Update-RunProgress
    $startButton.Enabled = $true
    $stopButton.Enabled = $false
    $finishMatchButton.Enabled = $false
    $generalModeRadio.Enabled = $true
    $parkingModeRadio.Enabled = $true
    $readRankButton.Enabled = $parkingModeRadio.Checked
    $targetPointsBox.Enabled = $parkingModeRadio.Checked
    $minimumPointsCheck.Enabled = $parkingModeRadio.Checked
    $minimumPointsBox.Enabled = $parkingModeRadio.Checked -and $minimumPointsCheck.Checked
    $finishMatchButton.Text = "이번 판까지만 (F8)"
    $finishMatchButton.BackColor = [Drawing.ColorTranslator]::FromHtml('#263240')
    Set-Status "대기 중" ([Drawing.Color]::FromArgb(150, 156, 166))
    Write-Log "자동 진행을 중지했습니다. ($reason)"
    Save-DiagnosticInfo "자동 진행 중지: $reason"
}

function Toggle-FinishMatchReservation {
    if (-not $script:running) { return }
    if ($script:requiredStopAfterMatch) {
        Write-Log "자동 중지 조건을 충족해 예약을 취소할 수 없습니다. 설정 판수 또는 주차 점수를 확인해 주세요."
        return
    }
    $script:stopAfterCurrentMatch = -not $script:stopAfterCurrentMatch
    if ($script:stopAfterCurrentMatch) {
        $finishMatchButton.Text = "예약 취소 (F8)"
        $finishMatchButton.BackColor = [Drawing.ColorTranslator]::FromHtml('#4A3D28')
        Set-Status "경기 종료 후 중지 예약" ([Drawing.Color]::FromArgb(236, 190, 86))
        Write-Log "이번 판 완료 후 자동 진행 중지를 예약했습니다. (버튼/F8)"
    } else {
        $finishMatchButton.Text = "이번 판까지만 (F8)"
        $finishMatchButton.BackColor = [Drawing.ColorTranslator]::FromHtml('#263240')
        Set-Status "화면 인식 중" ([Drawing.Color]::FromArgb(83, 220, 120))
        Write-Log "이번 판 완료 후 중지 예약을 취소했습니다. (버튼/F8)"
    }
}

function Save-FCScreenshot {
    $info = Get-FCWindowInfo
    if ($null -eq $info) {
        [System.Windows.Forms.MessageBox]::Show("실행 중인 FC ONLINE 창을 찾지 못했습니다.", "화면 저장") | Out-Null
        return
    }
    $rect = New-Object FCNative+RECT
    if (-not [FCNative]::GetWindowRect($info.Handle, [ref]$rect)) {
        [System.Windows.Forms.MessageBox]::Show("FC ONLINE 창 크기를 확인하지 못했습니다.", "화면 저장") | Out-Null
        return
    }
    $width = $rect.Right - $rect.Left
    $height = $rect.Bottom - $rect.Top
    if ($width -le 0 -or $height -le 0) { return }
    $form.Hide()
    [System.Windows.Forms.Application]::DoEvents()
    Start-Sleep -Milliseconds 300
    $bitmap = New-Object Drawing.Bitmap($width, $height)
    $graphics = [Drawing.Graphics]::FromImage($bitmap)
    try {
        $graphics.CopyFromScreen($rect.Left, $rect.Top, 0, 0, (New-Object Drawing.Size($width, $height)))
        $path = Join-Path $script:captureDir ("FC_{0}.png" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
        $bitmap.Save($path, [Drawing.Imaging.ImageFormat]::Png)
        Write-Log "FC 화면을 저장했습니다: $([IO.Path]::GetFileName($path)) ($($width)x$($height), DPI $script:dpiAwarenessMode)"
        [System.Windows.Forms.MessageBox]::Show("화면을 오류확인용_보내기\\captures 폴더에 저장했습니다.", "화면 저장") | Out-Null
    } finally {
        $graphics.Dispose()
        $bitmap.Dispose()
        $form.Show()
        $form.Activate()
    }
}

function Update-ParkingAppearance {
    $isParking = $parkingModeRadio.Checked
    $form.BackColor = [Drawing.ColorTranslator]::FromHtml('#10151C')
    $modeGroup.BackColor = [Drawing.ColorTranslator]::FromHtml('#19212C')
    $readRankButton.Enabled = $isParking -and -not $script:running
    $targetPointsBox.Enabled = $isParking -and -not $script:running
    $minimumPointsCheck.Enabled = $isParking -and -not $script:running
    $minimumPointsBox.Enabled = $isParking -and $minimumPointsCheck.Checked -and -not $script:running
}

$generalModeRadio.Add_CheckedChanged({ Update-ParkingAppearance })
$parkingModeRadio.Add_CheckedChanged({ Update-ParkingAppearance })
$minimumPointsCheck.Add_CheckedChanged({ Update-ParkingAppearance })
$readRankButton.Add_Click({
    try {
        if ($script:running) { return }
        $info = Get-FCWindowInfo
        if ($null -eq $info) { throw 'FC ONLINE 창을 찾지 못했습니다.' }
        $form.Hide()
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 350
        $foreground = Get-ForegroundInfo
        if (-not $foreground.Allowed -or $foreground.Handle -ne $info.Handle) {
            throw 'FC ONLINE 창을 맨 앞에 놓고 챔피언스 감독 랭킹 화면에서 다시 시도해 주세요.'
        }
        Set-ConfirmedStartingRank (Read-ConfirmedStartingRank $info.Handle)
    } catch {
        $script:startingRankPoints = $null
        $script:startingRankReadAt = $null
        Write-Log "시작점수 인식 실패: $($_.Exception.Message)"
        Show-TopmostError $_.Exception.Message '시작점수 인식 실패'
    } finally {
        $form.Show()
        $form.Activate()
    }
})
Update-ParkingAppearance

$startButton.Add_Click({ Start-Automation })
$stopButton.Add_Click({ Stop-Automation "중지 버튼" })
$finishMatchButton.Add_Click({ Toggle-FinishMatchReservation })
$captureButton.Add_Click({
    try {
        Save-FCScreenshot
    } catch {
        Write-Log "화면 저장 오류: $($_.Exception.Message)"
        Show-TopmostError $_.Exception.Message "FC 화면 저장 오류"
    }
})

$saveWebhookButton.Add_Click({
    try {
        Save-DiscordSettingsFromUi
        [System.Windows.Forms.MessageBox]::Show("Discord 알림 설정을 저장했습니다.", "설정 저장") | Out-Null
    } catch {
        Show-TopmostError $_.Exception.Message "Discord 설정 오류"
    }
})

$testWebhookButton.Add_Click({
    try {
        Save-DiscordSettingsFromUi
        Queue-DiscordNotification "FC 감독모드 테스트 알림" "Discord 직접 알림이 정상적으로 연결되었습니다." $true
        $discordStatus.Text = "테스트 알림 전송 중..."
    } catch {
        Show-TopmostError $_.Exception.Message "Discord 테스트 오류"
    }
})

Add-Type -ReferencedAssemblies "System.Windows.Forms" -TypeDefinition @"
using System;
using System.Threading;
using System.Windows.Forms;
public sealed class FCF8MessageFilter : IMessageFilter
{
    private int pending;
    public bool PreFilterMessage(ref Message message)
    {
        if (message.Msg != 0x0312 || message.WParam.ToInt64() != 0xFC08) return false;
        Interlocked.Increment(ref pending);
        return true;
    }
    public bool ConsumePress() { return Interlocked.Exchange(ref pending, 0) > 0; }
}
"@

$script:f8MessageFilter = New-Object FCF8MessageFilter
[System.Windows.Forms.Application]::AddMessageFilter($script:f8MessageFilter)
$script:f8HotkeyActive = [FCNative]::RegisterHotKey($form.Handle, $script:f8HotkeyId, 0x4000, 0x77)
if (-not $script:f8HotkeyActive) {
    Write-Log "F8 전역 단축키를 등록할 수 없어 키 상태 확인으로 대체합니다. 필요하면 화면 버튼을 사용하세요."
}

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 25
$timer.Add_Tick({
    try {
        Process-UpdateTask
        Process-DiscordQueue
        Update-OperatorReports
        Update-RemoteControl
        $f9Down = (([FCNative]::GetAsyncKeyState(0x78) -band 0x8000) -ne 0)
        $f8Down = if ($script:f8HotkeyActive) {
            $script:f8MessageFilter.ConsumePress()
        } else {
            (([FCNative]::GetAsyncKeyState(0x77) -band 0x8000) -ne 0)
        }
        $f12Down = (([FCNative]::GetAsyncKeyState(0x7B) -band 0x8000) -ne 0)
        if ($f9Down -and -not $script:f9WasDown) { Start-Automation }
        if ($script:f8HotkeyActive) {
            if ($f8Down) { Toggle-FinishMatchReservation }
        } elseif ($f8Down -and -not $script:f8WasDown) {
            Toggle-FinishMatchReservation
        }
        if ($f12Down -and -not $script:f12WasDown) { Stop-Automation "F12" }
        $script:f9WasDown = $f9Down
        $script:f8WasDown = $f8Down
        $script:f12WasDown = $f12Down

        $info = Get-ForegroundInfo
        $shownTitle = if ([string]::IsNullOrWhiteSpace($info.Title)) { $info.Process } else { $info.Title }
        if ([string]::IsNullOrWhiteSpace($shownTitle)) { $shownTitle = "확인 불가" }
        if ($shownTitle.Length -gt 70) { $shownTitle = $shownTitle.Substring(0, 70) + "..." }
        $windowLabel.Text = "현재 창: $shownTitle"

        if ($script:coachRun) { Invoke-CoachTick $info; return }
        if ($script:bpRun) { Invoke-BPProtectionTick $info ([DateTime]::UtcNow); return }
        if (Update-ClientLifecycle $info ([DateTime]::UtcNow)) { return }
        if (-not $script:running) { return }

        if (Stop-ExpiredRewardRecovery ([DateTime]::UtcNow)) { return }

        $allowedNow = (-not $onlyFcCheck.Checked) -or $info.Allowed
        if (-not $allowedNow) {
            if (-not $script:paused) {
                $script:paused = $true
                $script:previousVisualFrame = $null
                $script:pauseCount++
                $script:resumeStableSince = $null
                [void][FCNative]::SendScanCode(0x39, $true)
                [void][FCNative]::SendScanCode(0x1F, $true)
                [void][FCNative]::SendVirtualKey(0x53, $true)
                [void][FCNative]::SendScanCode(0x01, $true)
                Update-Counters
                Set-Status "자동 일시정지" ([Drawing.Color]::FromArgb(236, 190, 86))
                Write-Log "다른 창이 선택되어 입력을 멈췄습니다."
            }
            return
        }

        if ($script:paused) {
            if ($null -eq $script:resumeStableSince) {
                $script:resumeStableSince = [DateTime]::Now
                Set-Status "FC 창 복귀 확인 중" ([Drawing.Color]::FromArgb(236, 190, 86))
                return
            }
            if (([DateTime]::Now - $script:resumeStableSince).TotalMilliseconds -lt 1500) { return }
            $script:paused = $false
            $script:previousVisualFrame = $null
            $script:lastVisualChangeAt = [DateTime]::Now
            $script:nextScanDue = [DateTime]::Now.AddMilliseconds(300)
            $script:lastTemplateActions.Clear()
            Set-Status "화면 인식 중" ([Drawing.Color]::FromArgb(83, 220, 120))
            Write-Log "FC ONLINE 창으로 돌아와 화면 인식을 재개합니다."
        }

        if ([DateTime]::Now -lt $script:nextScanDue) { return }
        $script:nextScanDue = [DateTime]::Now.AddMilliseconds(650)
        if ($script:rewardRecoveryDeadline) {
            Invoke-RewardRecovery $info
            return
        }

        if($script:missionState){
            Invoke-MissionFlow $info
            return
        }
        if($script:clubState){
            Invoke-ClubFlow $info
            return
        }
        $frame = Get-FCFrame $info.Handle
        if ($null -eq $frame) {
            Set-Status "FC 화면 캡처 대기" ([Drawing.Color]::FromArgb(236, 190, 86))
            return
        }

        if ($null -ne $script:previousVisualFrame) {
            if ([FCTemplateMatcher]::VisualChangeFraction($script:previousVisualFrame, $frame.Buffer) -ge 0.01) {
                $script:lastVisualChangeAt = [DateTime]::Now
            }
        } else {
            $script:lastVisualChangeAt = [DateTime]::Now
        }
        $script:previousVisualFrame = $frame.Buffer

        $recognized = Find-TemplateAction $frame
        if(Start-ScheduledRewardCheck $recognized ([DateTime]::UtcNow)){return}
        if ($null -ne $recognized) {
            Invoke-TemplateAction $recognized $frame
            if ($script:running) {
                Set-Status "화면 인식 작동 중" ([Drawing.Color]::FromArgb(83, 220, 120))
            }
        } else {
            Set-Status "등록 화면 대기 중" ([Drawing.Color]::FromArgb(120, 180, 235))
            if (([DateTime]::Now - $script:lastProgressAt).TotalMinutes -ge 20) {
                Send-StuckAlert "자동 진행 중 20분 동안 다음 조작 화면을 인식하지 못했습니다."
            }
        }
    } catch {
        $message = $_.Exception.Message
        Queue-DiscordNotification "FC 감독모드 프로그램 오류" "자동 진행이 오류로 중지되었습니다: $message`n$(Get-MatchSummary)"
        Stop-Automation "오류"
        Write-Log "오류: $message"
        Save-DiagnosticInfo "프로그램 오류: $message"
        Queue-OperatorReport "프로그램 오류 · $message"
        Show-TopmostError $message
    }
})

$form.Add_FormClosing({
    if ($script:helperExitMarker) {
        try { [IO.File]::WriteAllText($script:helperExitMarker, 'closed') }
        catch { Write-Log '정상 종료 확인 파일을 기록하지 못했습니다.' }
    }
    if ($script:running) { Stop-Automation "프로그램 종료" }
    $timer.Stop()
    if ($script:operatorHttp) { $script:operatorHttp.Dispose() }
    if ($script:remoteHttp) { $script:remoteHttp.Dispose() }
    if ($null -ne $script:updateClient) { $script:updateClient.Dispose() }
    if ($script:f8HotkeyActive) {
        [void][FCNative]::UnregisterHotKey($form.Handle, $script:f8HotkeyId)
    }
    [System.Windows.Forms.Application]::RemoveMessageFilter($script:f8MessageFilter)
    if ($null -ne $script:httpClient) { $script:httpClient.Dispose() }
})

Apply-ModernLayout
Apply-ReadableFonts
Initialize-ClubOption
Initialize-MissionOption
Initialize-DailyRewardOption
Initialize-DailyStatsView
Initialize-MaintenanceView
Initialize-CoachView
Initialize-BPProtectionButton
Initialize-UpdateUI
Initialize-RemoteControl
Load-DiscordSettings
Start-HelperExitWatcher
Load-MatchStats
Write-Log "Windows DPI 인식 모드: $script:dpiAwarenessMode"
Write-Log "프로그램을 실행했습니다. FC ONLINE 창을 선택한 뒤 F9를 눌러주세요."
Save-DiagnosticInfo "프로그램 시작"
$timer.Start()
[void]$form.ShowDialog()
