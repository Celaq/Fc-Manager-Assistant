﻿$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Net.Http

Add-Type @"
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

public static class FCNative
{
    [StructLayout(LayoutKind.Sequential)]
    public struct INPUT
    {
        public uint type;
        public InputUnion U;
    }

    [StructLayout(LayoutKind.Explicit)]
    public struct InputUnion
    {
        [FieldOffset(0)] public KEYBDINPUT ki;
        [FieldOffset(0)] public MOUSEINPUT mi;
        [FieldOffset(0)] public HARDWAREINPUT hi;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct KEYBDINPUT
    {
        public ushort wVk;
        public ushort wScan;
        public uint dwFlags;
        public uint time;
        public UIntPtr dwExtraInfo;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct MOUSEINPUT
    {
        public int dx;
        public int dy;
        public uint mouseData;
        public uint dwFlags;
        public uint time;
        public UIntPtr dwExtraInfo;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct HARDWAREINPUT
    {
        public uint uMsg;
        public ushort wParamL;
        public ushort wParamH;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct RECT
    {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct POINT
    {
        public int X;
        public int Y;
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

    public static int LastInputError { get; private set; }

    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);

    [DllImport("user32.dll")]
    public static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);

    [DllImport("user32.dll")]
    public static extern short GetAsyncKeyState(int virtualKey);

    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool RegisterHotKey(IntPtr hWnd, int id, uint modifiers, uint virtualKey);

    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool UnregisterHotKey(IntPtr hWnd, int id);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool SetProcessDpiAwarenessContext(IntPtr dpiContext);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool SetProcessDPIAware();

    [DllImport("user32.dll")]
    private static extern bool GetCursorPos(out POINT point);

    [DllImport("user32.dll")]
    private static extern bool SetCursorPos(int x, int y);

    [DllImport("user32.dll")]
    private static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);

    public static bool LastClickUsedFallback { get; private set; }

    public static bool SendScanCode(ushort scanCode, bool keyUp)
    {
        const uint INPUT_KEYBOARD = 1;
        const uint KEYEVENTF_KEYUP = 0x0002;
        const uint KEYEVENTF_SCANCODE = 0x0008;

        INPUT input = new INPUT();
        input.type = INPUT_KEYBOARD;
        input.U.ki.wVk = 0;
        input.U.ki.wScan = scanCode;
        input.U.ki.dwFlags = KEYEVENTF_SCANCODE | (keyUp ? KEYEVENTF_KEYUP : 0);
        input.U.ki.time = 0;
        input.U.ki.dwExtraInfo = UIntPtr.Zero;
        uint sent = SendInput(1, new INPUT[] { input }, Marshal.SizeOf(typeof(INPUT)));
        LastInputError = sent == 1 ? 0 : Marshal.GetLastWin32Error();
        return sent == 1;
    }

    public static bool SendVirtualKey(ushort virtualKey, bool keyUp)
    {
        const uint INPUT_KEYBOARD = 1;
        const uint KEYEVENTF_KEYUP = 0x0002;

        INPUT input = new INPUT();
        input.type = INPUT_KEYBOARD;
        input.U.ki.wVk = virtualKey;
        input.U.ki.wScan = 0;
        input.U.ki.dwFlags = keyUp ? KEYEVENTF_KEYUP : 0;
        input.U.ki.time = 0;
        input.U.ki.dwExtraInfo = UIntPtr.Zero;
        uint sent = SendInput(1, new INPUT[] { input }, Marshal.SizeOf(typeof(INPUT)));
        LastInputError = sent == 1 ? 0 : Marshal.GetLastWin32Error();
        return sent == 1;
    }

    public static bool SendLeftClick(int screenX, int screenY)
    {
        const uint INPUT_MOUSE = 0;
        const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
        const uint MOUSEEVENTF_LEFTUP = 0x0004;

        LastClickUsedFallback = false;
        POINT oldPoint;
        bool haveOldPoint = GetCursorPos(out oldPoint);
        if (!SetCursorPos(screenX, screenY)) return false;

        // Give FC ONLINE a short moment to observe the new cursor position.
        // Sending movement and a click in the same instant was intermittently
        // returning zero inputs with no Windows error on some systems.
        System.Threading.Thread.Sleep(60);

        INPUT down = new INPUT();
        down.type = INPUT_MOUSE;
        down.U.mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
        INPUT up = new INPUT();
        up.type = INPUT_MOUSE;
        up.U.mi.dwFlags = MOUSEEVENTF_LEFTUP;

        uint sent = SendInput(2, new INPUT[] { down, up }, Marshal.SizeOf(typeof(INPUT)));
        LastInputError = sent == 2 ? 0 : Marshal.GetLastWin32Error();

        if (sent != 2)
        {
            // Legacy mouse_event is retained only as a compatibility fallback.
            // The next recognition cycle confirms whether the screen changed,
            // so a blocked fallback cannot silently advance the state machine.
            LastClickUsedFallback = true;
            mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, UIntPtr.Zero);
            System.Threading.Thread.Sleep(80);
            mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, UIntPtr.Zero);
            LastInputError = 0;
        }

        System.Threading.Thread.Sleep(80);
        if (haveOldPoint) SetCursorPos(oldPoint.X, oldPoint.Y);
        return true;
    }

    public static string GetTitle(IntPtr hWnd)
    {
        StringBuilder builder = new StringBuilder(512);
        GetWindowText(hWnd, builder, builder.Capacity);
        return builder.ToString();
    }

    public static string GetProcessName(IntPtr hWnd)
    {
        uint pid;
        GetWindowThreadProcessId(hWnd, out pid);
        if (pid == 0) return "";
        try { return Process.GetProcessById((int)pid).ProcessName; }
        catch { return ""; }
    }

    public static string EnableDpiAwareness()
    {
        try
        {
            // DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2. This makes
            // GetWindowRect, CopyFromScreen and SendInput share physical
            // pixel coordinates even when Windows scaling is above 100%.
            if (SetProcessDpiAwarenessContext(new IntPtr(-4)))
                return "Per-monitor V2";

            // ERROR_ACCESS_DENIED means the host already selected a DPI mode.
            if (Marshal.GetLastWin32Error() == 5)
                return "Already configured";
        }
        catch (EntryPointNotFoundException) { }

        try
        {
            if (SetProcessDPIAware()) return "System aware";
            if (Marshal.GetLastWin32Error() == 5) return "Already configured";
        }
        catch (EntryPointNotFoundException) { }
        return "Unavailable";
    }
}
"@

$script:dpiAwarenessMode = [FCNative]::EnableDpiAwareness()

Add-Type -ReferencedAssemblies "System.Drawing" -TypeDefinition @"
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Collections.Generic;

public sealed class FCPixelBuffer
{
    public int Width;
    public int Height;
    public int Stride;
    public byte[] Data;
}

public sealed class FCTemplateResult
{
    public bool Found;
    public int X;
    public int Y;
    public int MatchWidth;
    public int MatchHeight;
    public double MeanDifference;
}

public sealed class FCScoreResult
{
    public bool Found;
    public int LeftScore;
    public int RightScore;
    public double Confidence;
    public string Reason;
}

public static class FCTemplateMatcher
{
    public static FCPixelBuffer FromBitmap(Bitmap source)
    {
        Bitmap converted = new Bitmap(source.Width, source.Height, PixelFormat.Format32bppArgb);
        using (Graphics graphics = Graphics.FromImage(converted))
        {
            graphics.DrawImage(source, 0, 0, source.Width, source.Height);
        }

        Rectangle rect = new Rectangle(0, 0, converted.Width, converted.Height);
        BitmapData data = converted.LockBits(rect, ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        try
        {
            int byteCount = Math.Abs(data.Stride) * data.Height;
            byte[] bytes = new byte[byteCount];
            Marshal.Copy(data.Scan0, bytes, 0, byteCount);
            return new FCPixelBuffer {
                Width = converted.Width,
                Height = converted.Height,
                Stride = Math.Abs(data.Stride),
                Data = bytes
            };
        }
        finally
        {
            converted.UnlockBits(data);
            converted.Dispose();
        }
    }

    public static Bitmap ToBitmap(FCPixelBuffer source)
    {
        if (source == null) return null;
        Bitmap bitmap = new Bitmap(source.Width, source.Height, PixelFormat.Format32bppArgb);
        Rectangle rect = new Rectangle(0, 0, bitmap.Width, bitmap.Height);
        BitmapData data = bitmap.LockBits(rect, ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
        try
        {
            int targetStride = Math.Abs(data.Stride);
            if (targetStride == source.Stride)
            {
                Marshal.Copy(source.Data, 0, data.Scan0, Math.Min(source.Data.Length, targetStride * source.Height));
            }
            else
            {
                for (int y = 0; y < source.Height; y++)
                {
                    IntPtr row = new IntPtr(data.Scan0.ToInt64() + (long)y * targetStride);
                    Marshal.Copy(source.Data, y * source.Stride, row, Math.Min(source.Stride, targetStride));
                }
            }
        }
        finally
        {
            bitmap.UnlockBits(data);
        }
        return bitmap;
    }

    public static FCPixelBuffer Resize(FCPixelBuffer source, double scale)
    {
        if (source == null || scale <= 0.0) return null;
        int width = Math.Max(1, (int)Math.Round(source.Width * scale));
        int height = Math.Max(1, (int)Math.Round(source.Height * scale));
        if (width == source.Width && height == source.Height) return source;

        using (Bitmap original = ToBitmap(source))
        using (Bitmap resized = new Bitmap(width, height, PixelFormat.Format32bppArgb))
        {
            using (Graphics graphics = Graphics.FromImage(resized))
            {
                graphics.CompositingMode = CompositingMode.SourceCopy;
                graphics.CompositingQuality = CompositingQuality.HighQuality;
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
                graphics.SmoothingMode = SmoothingMode.HighQuality;
                graphics.DrawImage(original, new Rectangle(0, 0, width, height));
            }
            return FromBitmap(resized);
        }
    }

    private static long DifferenceAt(FCPixelBuffer screen, FCPixelBuffer template,
        int left, int top, int stepX, int stepY, long stopAt, out int sampleChannels)
    {
        long difference = 0;
        sampleChannels = 0;
        for (int ty = 0; ty < template.Height; ty += stepY)
        {
            int screenRow = (top + ty) * screen.Stride;
            int templateRow = ty * template.Stride;
            for (int tx = 0; tx < template.Width; tx += stepX)
            {
                int si = screenRow + (left + tx) * 4;
                int ti = templateRow + tx * 4;
                difference += Math.Abs(screen.Data[si] - template.Data[ti]);
                difference += Math.Abs(screen.Data[si + 1] - template.Data[ti + 1]);
                difference += Math.Abs(screen.Data[si + 2] - template.Data[ti + 2]);
                sampleChannels += 3;
                if (difference > stopAt) return difference;
            }
        }
        return difference;
    }

    public static FCTemplateResult Find(FCPixelBuffer screen, FCPixelBuffer template,
        double x1, double y1, double x2, double y2, double maximumMeanDifference)
    {
        FCTemplateResult result = new FCTemplateResult {
            Found = false,
            MeanDifference = 999.0,
            MatchWidth = template == null ? 0 : template.Width,
            MatchHeight = template == null ? 0 : template.Height
        };
        if (screen == null || template == null || template.Width > screen.Width || template.Height > screen.Height)
            return result;

        int minX = Math.Max(0, (int)Math.Floor(screen.Width * x1));
        int minY = Math.Max(0, (int)Math.Floor(screen.Height * y1));
        int maxX = Math.Min(screen.Width - template.Width, (int)Math.Ceiling(screen.Width * x2) - template.Width);
        int maxY = Math.Min(screen.Height - template.Height, (int)Math.Ceiling(screen.Height * y2) - template.Height);
        if (maxX < minX || maxY < minY) return result;

        int sampleStepX = Math.Max(2, template.Width / 12);
        int sampleStepY = Math.Max(2, template.Height / 6);
        int sampleColumns = (template.Width + sampleStepX - 1) / sampleStepX;
        int sampleRows = (template.Height + sampleStepY - 1) / sampleStepY;
        // Coarse candidates may be one pixel away from the true location.
        // Use a wider coarse allowance, then enforce the requested threshold
        // after the one-pixel refinement pass.
        long allowed = (long)Math.Ceiling(maximumMeanDifference * 2.5 * sampleColumns * sampleRows * 3.0);
        long best = allowed;
        int bestX = -1, bestY = -1;

        for (int y = minY; y <= maxY; y += 2)
        {
            for (int x = minX; x <= maxX; x += 2)
            {
                int channels;
                long value = DifferenceAt(screen, template, x, y, sampleStepX, sampleStepY, best, out channels);
                if (value < best)
                {
                    best = value;
                    bestX = x;
                    bestY = y;
                }
            }
        }

        if (bestX < 0) return result;

        int refineMinX = Math.Max(minX, bestX - 3);
        int refineMaxX = Math.Min(maxX, bestX + 3);
        int refineMinY = Math.Max(minY, bestY - 3);
        int refineMaxY = Math.Min(maxY, bestY + 3);
        for (int y = refineMinY; y <= refineMaxY; y++)
        {
            for (int x = refineMinX; x <= refineMaxX; x++)
            {
                int channels;
                long value = DifferenceAt(screen, template, x, y, sampleStepX, sampleStepY, best, out channels);
                if (value < best)
                {
                    best = value;
                    bestX = x;
                    bestY = y;
                }
            }
        }

        int finalChannels;
        long finalDifference = DifferenceAt(screen, template, bestX, bestY, 2, 2, long.MaxValue, out finalChannels);
        double finalMean = finalChannels > 0 ? finalDifference / (double)finalChannels : 999.0;
        result.Found = finalMean <= maximumMeanDifference;
        result.X = bestX;
        result.Y = bestY;
        result.MeanDifference = finalMean;
        return result;
    }

    // Compare the light S glyph, since the background changes every frame.
    public static FCTemplateResult FindForegroundGlyph(FCPixelBuffer screen, FCPixelBuffer template,
        double x1, double y1, double x2, double y2, double maximumMeanDifference)
    {
        FCTemplateResult result = new FCTemplateResult { Found = false, MeanDifference = 999.0 };
        if (screen == null || template == null || template.Width > screen.Width || template.Height > screen.Height) return result;
        List<int> offsets = new List<int>();
        for (int ty = 0; ty < template.Height; ty++)
            for (int tx = 0; tx < template.Width; tx++)
            {
                if (((tx + ty) & 1) != 0) continue;
                int ti = ty * template.Stride + tx * 4;
                if (template.Data[ti] >= 190 && template.Data[ti + 1] >= 190 && template.Data[ti + 2] >= 190)
                    offsets.Add(ty * template.Width + tx);
            }
        if (offsets.Count < 30) return result;
        int minX = Math.Max(0, (int)Math.Floor(screen.Width * x1));
        int minY = Math.Max(0, (int)Math.Floor(screen.Height * y1));
        int maxX = Math.Min(screen.Width - template.Width, (int)Math.Ceiling(screen.Width * x2) - template.Width);
        int maxY = Math.Min(screen.Height - template.Height, (int)Math.Ceiling(screen.Height * y2) - template.Height);
        long best = long.MaxValue;
        for (int y = minY; y <= maxY; y++)
            for (int x = minX; x <= maxX; x++)
            {
                long difference = 0;
                foreach (int offset in offsets)
                {
                    int ti = (offset / template.Width) * template.Stride + (offset % template.Width) * 4;
                    int si = (y + offset / template.Width) * screen.Stride + (x + offset % template.Width) * 4;
                    difference += Math.Abs(screen.Data[si] - template.Data[ti]);
                    difference += Math.Abs(screen.Data[si + 1] - template.Data[ti + 1]);
                    difference += Math.Abs(screen.Data[si + 2] - template.Data[ti + 2]);
                    if (difference >= best) break;
                }
                if (difference < best) { best = difference; result.X = x; result.Y = y; }
            }
        if (best == long.MaxValue) return result;
        result.MeanDifference = best / (double)(offsets.Count * 3);
        result.Found = result.MeanDifference <= maximumMeanDifference;
        return result;
    }

    // ESC alone also occurs in the lobby. Require the light SKIP label to its
    // right, at the bottom of the FC window, before sending any key.
    public static FCTemplateResult FindEscSkip(FCPixelBuffer screen, FCPixelBuffer template,
        double x1, double y1, double x2, double y2, double maximumMeanDifference)
    {
        FCTemplateResult result = FindForegroundGlyph(screen, template, x1, y1, x2, y2, maximumMeanDifference);
        if (!result.Found) return result;
        int firstX = result.X + template.Width + Math.Max(3, template.Width / 9);
        int lastX = Math.Min(screen.Width, firstX + Math.Max(30, template.Width * 13 / 10));
        int firstY = result.Y + Math.Max(2, template.Height / 7);
        int lastY = Math.Min(screen.Height, result.Y + template.Height - Math.Max(2, template.Height / 7));
        if (firstX >= lastX || firstY >= lastY) { result.Found = false; return result; }
        int bright = 0, total = 0;
        for (int y = firstY; y < lastY; y++)
            for (int x = firstX; x < lastX; x++)
            {
                int i = y * screen.Stride + x * 4;
                if (screen.Data[i] >= 175 && screen.Data[i + 1] >= 175 && screen.Data[i + 2] >= 175) bright++;
                total++;
            }
        result.Found = bright >= Math.Max(18, total / 10) && bright <= total / 2;
        return result;
    }

    // Sample the game area, excluding the changing prompts along the edges.
    // Repeated S prompts alone do not imply that the match is frozen.
    public static double VisualChangeFraction(FCPixelBuffer previous, FCPixelBuffer current)
    {
        if (previous == null || current == null || previous.Width != current.Width || previous.Height != current.Height)
            return 1.0;
        int changed = 0, total = 0;
        for (int y = current.Height * 15 / 100; y < current.Height * 78 / 100; y += 16)
            for (int x = current.Width * 15 / 100; x < current.Width * 82 / 100; x += 16)
            {
                int oldIndex = y * previous.Stride + x * 4;
                int newIndex = y * current.Stride + x * 4;
                int difference = Math.Abs(previous.Data[oldIndex] - current.Data[newIndex])
                    + Math.Abs(previous.Data[oldIndex + 1] - current.Data[newIndex + 1])
                    + Math.Abs(previous.Data[oldIndex + 2] - current.Data[newIndex + 2]);
                if (difference > 65) changed++;
                total++;
            }
        return total > 0 ? changed / (double)total : 0.0;
    }

    public static FCTemplateResult FindMultiScale(FCPixelBuffer screen, FCPixelBuffer template,
        double x1, double y1, double x2, double y2, double maximumMeanDifference, double[] scales, bool foregroundGlyph, bool escSkip)
    {
        FCTemplateResult best = new FCTemplateResult { Found = false, MeanDifference = 999.0 };
        if (screen == null || template == null || scales == null) return best;

        List<string> checkedSizes = new List<string>();
        foreach (double requestedScale in scales)
        {
            // High-resolution 2560 sources are intentionally reduced to
            // 1280/1600-class FC windows, so scales below 0.65 are valid.
            double scale = Math.Max(0.35, Math.Min(2.0, requestedScale));
            int width = Math.Max(1, (int)Math.Round(template.Width * scale));
            int height = Math.Max(1, (int)Math.Round(template.Height * scale));
            string sizeKey = width.ToString() + "x" + height.ToString();
            if (checkedSizes.Contains(sizeKey)) continue;
            checkedSizes.Add(sizeKey);

            FCPixelBuffer candidateTemplate = Resize(template, scale);
            FCTemplateResult candidate = escSkip
                ? FindEscSkip(screen, candidateTemplate, x1, y1, x2, y2, maximumMeanDifference)
                : foregroundGlyph
                    ? FindForegroundGlyph(screen, candidateTemplate, x1, y1, x2, y2, maximumMeanDifference)
                    : Find(screen, candidateTemplate, x1, y1, x2, y2, maximumMeanDifference);
            candidate.MatchWidth = candidateTemplate.Width;
            candidate.MatchHeight = candidateTemplate.Height;
            if (candidate.MeanDifference < best.MeanDifference) best = candidate;
            if (candidate.Found) return candidate;
        }
        return best;
    }
}

public static class FCScoreReader
{
    private const int NormalWidth = 28;
    private const int NormalHeight = 56;
    private static readonly string[] EncodedTemplates = new string[] {
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH//4A///wH/n/gf4H+D/AP8P8A/w/gB/D+AH8P4Afw/gB/D+AH8P4Afw/gB/H+AH+f4Af5/gB/n+AH+f4Af5/gB/n+AH+f4Af5/gB/n+AH+f4Af4/gB/D+AH8P4Afw/gB/D+AH8P4Afw/wD/D/gP8H+B/gf+f+A///wB//+AH//4Af//gAf/4AB//gAAfgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
        "AAAAAAA/+AAH/4AA//gAf/+B///4H///gf//+B///4H///gf//+B///4H///gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAAAAA==",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP//8B///4P///w/8P/D/AP8P8A/w/gB/j+AH+P4Af5/gB/n+AH+P4Af4AAD/AAAP8AAA/wAAH/AAA/8AAH/gAAf+AAH/gAA/+AAH/4AA/+AAH/4AB/8AAH/wAA/+AAH/gAAf+AAD/gAAf+AAD/wAAP8AAA////j///+P///5////n///+f///5////n///+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAD///Af//+D/5/4P+D/w/wD/D/AP8P4A/w/gD/D+AP8PwA/wAAD/AAAP8AAB/gAAP+AAB/wAB/+AAH/wAAf/gAB//AAH/8AAf/8AAf/wAAP/AAAP+AAA/4AAB/gAAH+fwAf5/AB/n8AH+f4Af5/gD/j+AP8P8A/w/4H/D/5/8P///gf//8A///wB//+AD//wAH/+AAD/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/gAB/+AAH/4AA//gAH/+AAfv4AB8/gAHz+AA/P4AH4/gAfj+AB8P4APw/gB+D+AH4P4AfA/gD4D+APgP4B+A/gP4D+A/AP4D4B/gfgH+B////n///+f///5////n///+f///5////gAB/gAAH+AAAf4AAB/gAAH+AAAf4AAB/gAAH+AAAf4AAB/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAD///wP///A///8D///wPwAAA/AAAD8AAAfwAAB/AAAH8AAAfgAAB+HwAH7/4Af//4D///gP///A///+D///8P/n/w/wP/D/AP8H4A/4AAD/gAAH+AAAf4AAB/gAAH+AAAf4AAB/n+AH+f4Af5/gD/H/AP8P8A/w/4P/D/5/8H///gf//8A///gB//8AD//gAH/+AAD+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAB///gP///A/5/8H/A/wf4D/D/AP8P8Afw/wAAD/AAAP4AAA/gAAD+AAAf5/4B/v/wH+//gf///B///+H///8f///x/+f/H/AP8f8A/5/wB/n+AH+f4Af5/gA/j+AD+P4AP4/gA/j+AD+P4Af4/wB/j/AP8P8A/wf8H/B/5/8D///gH//8Af//wA//+AB//wAD/+AAB/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH///+f///5////n///+AAAfwAAD+AAAfwAAD+AAAP4AAB/gAAH8AAA/gAAD+AAAf4AAB/AAAP4AAA/gAAD+AAAfwAAB/AAAP4AAB/gAAH8AAAfwAAB/AAAP8AAA/wAAD/AAAf4AAB/gAAH+AAAfwAAB/AAAH8AAAfwAAB/AAAP8AAA/wAAD/AAAP8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP//8B///4H/n/g/4H/D/AP8P8A/w/gB/D+AH8P4Afw/gD/D/AP4H+B/gf8P8A///gB//+AD//gAP//AB///AP//+B///8P/D/w/4H/D+AP8P4Af5/gB/n+AH+f4Af5/gB/n+AH+f4Af4/gB/D/AP8P+B/w/+f/D///4D///AP//4Af//gA//4AB//gAA/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP//4B///wP///A/wH+D/AP4P4A/w/gB/H+AH8f4Afx/gB/H+AH8f4Afx/gB/H+AH8f4Af4/gD/j/Af+P/H/4////h///+D///4H///gf//8Af/fwAfx/AAAH8AAAfwAAB/AAAH8P4A/w/gD+D/Af4P8D/A/8/8B///gD//+AH//wAf/+AA//wAB/+AAA/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=="
    };
    private static readonly bool[][] Templates = DecodeTemplates();

    private static bool[][] DecodeTemplates()
    {
        bool[][] result = new bool[10][];
        for (int d = 0; d < 10; d++)
        {
            byte[] packed = Convert.FromBase64String(EncodedTemplates[d]);
            result[d] = new bool[NormalWidth * NormalHeight];
            for (int i = 0; i < result[d].Length; i++)
                result[d][i] = (packed[i / 8] & (1 << (7 - (i % 8)))) != 0;
        }
        return result;
    }

    private sealed class DigitResult
    {
        public bool Found;
        public int Digit;
        public double Difference;
        public double Gap;
        public string Reason;
    }

    private static DigitResult ReadDigit(FCPixelBuffer screen, double x1, double x2)
    {
        int left = Math.Max(0, (int)(screen.Width * x1));
        int right = Math.Min(screen.Width, (int)(screen.Width * x2));
        int top = Math.Max(0, (int)(screen.Height * 0.11));
        int bottom = Math.Min(screen.Height, (int)(screen.Height * 0.26));
        int width = right - left;
        int height = bottom - top;
        if (width <= 0 || height <= 0)
            return new DigitResult { Found = false, Reason = "점수 영역 없음" };

        int maximum = 0;
        for (int y = top; y < bottom; y++)
        {
            int row = y * screen.Stride;
            for (int x = left; x < right; x++)
            {
                int i = row + x * 4;
                int b = screen.Data[i], g = screen.Data[i + 1], r = screen.Data[i + 2];
                int lum = (r + g + b) / 3;
                if (lum > maximum) maximum = lum;
            }
        }
        if (maximum < 55)
            return new DigitResult { Found = false, Reason = "점수 표시 전환 중" };

        int threshold = Math.Max(38, (int)(maximum * 0.62));
        bool[] mask = new bool[width * height];
        for (int y = 0; y < height; y++)
        {
            int row = (top + y) * screen.Stride;
            for (int x = 0; x < width; x++)
            {
                int i = row + (left + x) * 4;
                int b = screen.Data[i], g = screen.Data[i + 1], r = screen.Data[i + 2];
                int lum = (r + g + b) / 3;
                int hi = Math.Max(r, Math.Max(g, b));
                int lo = Math.Min(r, Math.Min(g, b));
                mask[y * width + x] = lum > threshold && (hi - lo) < 50;
            }
        }

        bool[] visited = new bool[mask.Length];
        List<int> bestPixels = null;
        double bestComponentScore = -1;
        int[] queue = new int[mask.Length];
        int minimumHeight = Math.Max(35, (int)(screen.Height * 0.055));
        int maximumHeight = Math.Max(minimumHeight, (int)(screen.Height * 0.12));
        int minimumWidth = Math.Max(8, (int)(screen.Width * 0.008));
        int maximumWidth = Math.Max(minimumWidth, (int)(screen.Width * 0.06));

        for (int start = 0; start < mask.Length; start++)
        {
            if (!mask[start] || visited[start]) continue;
            int head = 0, tail = 0;
            queue[tail++] = start;
            visited[start] = true;
            List<int> pixels = new List<int>();
            int minX = width, maxX = 0, minY = height, maxY = 0;
            while (head < tail)
            {
                int p = queue[head++];
                pixels.Add(p);
                int px = p % width, py = p / width;
                if (px < minX) minX = px; if (px > maxX) maxX = px;
                if (py < minY) minY = py; if (py > maxY) maxY = py;
                int next;
                if (px > 0) { next = p - 1; if (mask[next] && !visited[next]) { visited[next] = true; queue[tail++] = next; } }
                if (px + 1 < width) { next = p + 1; if (mask[next] && !visited[next]) { visited[next] = true; queue[tail++] = next; } }
                if (py > 0) { next = p - width; if (mask[next] && !visited[next]) { visited[next] = true; queue[tail++] = next; } }
                if (py + 1 < height) { next = p + width; if (mask[next] && !visited[next]) { visited[next] = true; queue[tail++] = next; } }
            }

            int componentWidth = maxX - minX + 1;
            int componentHeight = maxY - minY + 1;
            if (pixels.Count < 80 || componentHeight < minimumHeight || componentHeight > maximumHeight ||
                componentWidth < minimumWidth || componentWidth > maximumWidth) continue;
            double componentScore = componentHeight * 10.0 + pixels.Count;
            if (componentScore > bestComponentScore)
            {
                bestComponentScore = componentScore;
                bestPixels = pixels;
            }
        }

        if (bestPixels == null)
            return new DigitResult { Found = false, Reason = "점수 숫자 없음" };

        int bx0 = width, bx1 = 0, by0 = height, by1 = 0;
        bool[] componentMask = new bool[mask.Length];
        foreach (int p in bestPixels)
        {
            componentMask[p] = true;
            int px = p % width, py = p / width;
            if (px < bx0) bx0 = px; if (px > bx1) bx1 = px;
            if (py < by0) by0 = py; if (py > by1) by1 = py;
        }
        int bw = bx1 - bx0 + 1, bh = by1 - by0 + 1;
        double scale = Math.Min((NormalWidth - 2.0) / bw, (NormalHeight - 2.0) / bh);
        int scaledWidth = Math.Max(1, (int)Math.Round(bw * scale));
        int scaledHeight = Math.Max(1, (int)Math.Round(bh * scale));
        int offsetX = (NormalWidth - scaledWidth) / 2;
        int offsetY = (NormalHeight - scaledHeight) / 2;
        bool[] normalized = new bool[NormalWidth * NormalHeight];
        for (int y = 0; y < scaledHeight; y++)
        {
            int sourceY = Math.Min(bh - 1, (int)((double)y * bh / scaledHeight));
            for (int x = 0; x < scaledWidth; x++)
            {
                int sourceX = Math.Min(bw - 1, (int)((double)x * bw / scaledWidth));
                normalized[(offsetY + y) * NormalWidth + offsetX + x] = componentMask[(by0 + sourceY) * width + bx0 + sourceX];
            }
        }

        int bestDigit = -1;
        double bestDifference = 1.0, secondDifference = 1.0;
        for (int digit = 0; digit < 10; digit++)
        {
            int mismatch = 0;
            for (int i = 0; i < normalized.Length; i++)
                if (normalized[i] != Templates[digit][i]) mismatch++;
            double difference = mismatch / (double)normalized.Length;
            if (difference < bestDifference)
            {
                secondDifference = bestDifference;
                bestDifference = difference;
                bestDigit = digit;
            }
            else if (difference < secondDifference)
            {
                secondDifference = difference;
            }
        }

        double gap = secondDifference - bestDifference;
        bool accepted = bestDifference <= 0.31 && gap >= 0.025;
        return new DigitResult {
            Found = accepted,
            Digit = bestDigit,
            Difference = bestDifference,
            Gap = gap,
            Reason = accepted ? "확인" : "숫자 신뢰도 부족"
        };
    }

    public static FCScoreResult Read(FCPixelBuffer screen)
    {
        if (screen == null)
            return new FCScoreResult { Found = false, Reason = "화면 없음" };
        DigitResult left = ReadDigit(screen, 0.40, 0.50);
        DigitResult right = ReadDigit(screen, 0.50, 0.59);
        if (!left.Found || !right.Found)
            return new FCScoreResult { Found = false, Reason = left.Found ? right.Reason : left.Reason };
        double confidence = 1.0 - Math.Max(left.Difference, right.Difference);
        return new FCScoreResult {
            Found = true,
            LeftScore = left.Digit,
            RightScore = right.Digit,
            Confidence = confidence,
            Reason = "확인"
        };
    }
}

public sealed class FCRankPointResult
{
    public bool Found;
    public int Delta;
    public double Confidence;
    public string Reason;
}


public static class FCRewardLabels
{
    public static bool Matches(FCPixelBuffer original, int x, int y, int width, int height, string encoded)
    {
        if (original == null) return false;
        FCPixelBuffer f = original.Width == 1296 ? original : FCTemplateMatcher.Resize(original, 1296.0 / original.Width);
        if (f.Width < x + width || f.Height < y + height) return false;
        byte[] sample = Convert.FromBase64String(encoded);
        int foreground = 0, missing = 0, extra = 0;
        for (int i = 0; i < width * height; i++) {
            bool expected = (sample[i / 8] & (1 << (i % 8))) != 0;
            int at = (y + i / width) * f.Stride + (x + i % width) * 4;
            bool actual = f.Data[at] >= 140 && f.Data[at+1] >= 140 && f.Data[at+2] >= 140;
            if (expected) { foreground++; if (!actual) missing++; }
            else if (actual) extra++;
        }
        return foreground >= 40 && missing <= foreground * 0.12 && extra <= foreground * 0.35;
    }
    public static bool IsLeague(FCPixelBuffer f) { return Matches(f,513,324,62,18,"AAAAAAAAAAAAAAAAAAAAAKoBQAAAAAAAQAAQIIAPAAAQEASYAAIAAAQEAQCAAAAAAEJAACAAAAAIEYgDBAD4PwCEAAAAAAAAAAAAIAAAAAAAAAAEAEAAABAAQAAAEBAABAEBAAAEAAABAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="); }
    public static bool IsRank(FCPixelBuffer f) { return Matches(f,513,324,62,18,"AAAAAAAAAAAAAAAAAAAAAAABAABB8A8AQQAAABAAAEAQIAAABAAAEAQEAAABAAAIASAAQAAAQEQAAOAQAAAIAAAAEAQAAAAAAAAEAQAAAAAAAAAAAABAAAAAAAACABAAAAAEAAAABAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="); }
    public static bool IsTierResult(FCPixelBuffer f) { return Matches(f,698,306,56,18,"AAAAAAAAAPAQAMFHAAKAGRgBfkACgBgIAUJAAkAYCAFhQAJgHgjBQEAGGBgIAQBIBgAABIF/CALABwMBQAgCIIgBgX/+AiAYAIEAAAJADACBAQACAAAAAAAAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"); }
    public static bool IsTierPopup(FCPixelBuffer original) {
        if (original == null) return false;
        FCPixelBuffer f = original.Width == 1296 ? original : FCTemplateMatcher.Resize(original,1296.0/original.Width);
        if (f.Height < 620) return false;
        int[] xs = {420,870,420,870}; int[] ys = {170,170,550,550};
        for(int k=0;k<4;k++) { int i=ys[k]*f.Stride+xs[k]*4;
            if(f.Data[i]<235 || f.Data[i+1]<235 || f.Data[i+2]<235) return false; }
        return true;
    }
}

public static class FCRankPointsReader
{
    // 20x12 binary digits sampled from the user's reward screens. They carry
    // digit shapes only; no screenshots, account names or game identifiers.
    private static readonly string[] Samples = new string[] {
        "0:MMAP/vEch3M4gzM4gzMwgzM4gzM4h3M4zuEffAAA,OMAP/vEchzM4gzM4gzM4gzM4gzM4g3M4z+EffAAA",
        "1:GMABH/ABGIABGIABGIABGIABGIABGIABGIABAAAA,DMAAD/AADMAADMAADMAADMAADMAADMAADMAAAAAA",
        "2:MMAP/nEchwEYgAEcwAEO4AAHOMABHOAAD/A//wMA,MOAP/nEcgwEYgAEcwAEO4AAHOMABHuAAB/Af/wEA",
        "3:OOAP/nEchwEYgAEc4IAH+AAcgAE4gjM4x+EffAAA,GOAH/nEcgwEYgAEc4IAH+AAcgAEYgjEYx+EffAAA",
        "4:wAEc4AEe8IEbmMEYjGEYhnEY//d/gAEYgAEYAAAA,gAEc4AEe8AEbmIEZjOEYhnE4//d/gAEYgAEYAAAA",
        "5:/uEfBmAABmAAduAPzmE4gAM4gCM4h3Mc/sEPAAAA,/uEfBmAABmAAdvAPx2EYgAE4gCM4g3Ec/sEHAAAA",
        "6:MMAP/nE4hzMAAzAAY7Afx3E4gzMwA3M4xuEf/AAA,MMAP/nE4hzMAAzAAY7Afx3E4gzMwA3M4xuEf/AAA,MMAP/nEcgzEAAzAAc7APxzEYgzM4gzMYx+Ef/AAA",
        "7://M/gAMYwAEM4AAGcAADMIADOIABHMABHMAAAAAA,//M/gAMYwAEM4AAGYAAHMIADOIABHMABHMAAAAAA",
        "8:MMAP7nEch3M4h2EYzsAP/nEYgzM4gzM4x+Ef/AAA,MMAP/nEch3M4h2EYzsAP/nEYgzM4g3M4x+Mf/AAA",
        "9:OOAP/nEcgzM4gzM4h3M8voM4gAM4gDM4x+EffAAA,OMAP/nEcgzM4gzM4h2M8vgMwgAM4gDM4x+EffAAA"
    };

    private static bool Bright(FCPixelBuffer frame, int x, int y)
    {
        int index = y * frame.Stride + x * 4;
        return frame.Data[index] >= 140 && frame.Data[index + 1] >= 140 && frame.Data[index + 2] >= 140;
    }

    private static int Distance(bool[] pixels, byte[] pattern)
    {
        int difference = 0;
        for (int bit = 0; bit < 240; bit++)
            if (pixels[bit] != ((pattern[bit / 8] & (1 << (bit % 8))) != 0)) difference++;
        return difference;
    }

    public static FCRankPointResult Read(FCPixelBuffer original)
    {
        FCRankPointResult result = new FCRankPointResult { Found = false, Reason = "보상 화면 확인 실패" };
        if (original == null || original.Width < 1000 || original.Height < 650) return result;
        FCPixelBuffer frame = original.Width == 1296 ? original : FCTemplateMatcher.Resize(original, 1296.0 / original.Width);
        if (frame.Width < 1296 || frame.Height < 749) return result;

        // This white tab appears on the settled reward panel, not the ranking
        // lobby. Requiring it prevents interpreting a lobby score as a delta.
        if (!Bright(frame, 499, 240) || !Bright(frame, 530, 240) || !Bright(frame, 600, 240)) return result;

        if (FCRewardLabels.IsLeague(frame)) { result.Reason = "등급 승점 화면"; return result; }
        if (!FCRewardLabels.IsRank(frame)) { result.Reason = "랭킹 점수 항목 확인 실패"; return result; }

        const int left = 974, top = 317, width = 55, height = 31;
        bool[] seen = new bool[width * height];
        System.Collections.Generic.List<System.Tuple<int, bool[]>> glyphs =
            new System.Collections.Generic.List<System.Tuple<int, bool[]>>();
        for (int y = 0; y < height; y++) for (int x = 0; x < width; x++)
        {
            int start = y * width + x;
            if (seen[start] || !Bright(frame, left + x, top + y)) continue;
            int[] queue = new int[width * height];
            int count = 1; queue[0] = start; seen[start] = true;
            int minX = x, maxX = x, minY = y, maxY = y;
            for (int head = 0; head < count; head++)
            {
                int at = queue[head], cx = at % width, cy = at / width;
                minX = Math.Min(minX, cx); maxX = Math.Max(maxX, cx);
                minY = Math.Min(minY, cy); maxY = Math.Max(maxY, cy);
                for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++)
                {
                    int nx = cx + dx, ny = cy + dy;
                    if (nx < 0 || nx >= width || ny < 0 || ny >= height) continue;
                    int next = ny * width + nx;
                    if (seen[next] || !Bright(frame, left + nx, top + ny)) continue;
                    seen[next] = true; queue[count++] = next;
                }
            }
            int gw = maxX - minX + 1, gh = maxY - minY + 1;
            if (count < 18 || gh < 13 || gh > 20 || gw > 12) continue;
            if (left + minX < 994 || left + minX > 1016) continue;
            bool[] bits = new bool[240];
            for (int k = 0; k < count; k++)
            {
                int cx = queue[k] % width - minX, cy = queue[k] / width - minY;
                bits[cy * 12 + cx] = true;
            }
            glyphs.Add(System.Tuple.Create(left + minX, bits));
        }
        glyphs.Sort((a, b) => a.Item1.CompareTo(b.Item1));
        if (glyphs.Count < 1 || glyphs.Count > 2) { result.Reason = "보상 점수 숫자 수 불일치"; return result; }
        int signPixels = 0;
        for (int y = 329; y < 340; y++) for (int x = 984; x < 994; x++)
            if (Bright(frame, x, y)) signPixels++;
        if (signPixels > 2 && signPixels < 8) { result.Reason = "부호 신뢰도 부족"; return result; }
        int number = 0, worstDistance = 0, smallestGap = 240;
        foreach (var glyph in glyphs)
        {
            int best = 241, nextBest = 241, digit = -1;
            foreach (string line in Samples)
            {
                int colon = line.IndexOf(':'); int candidate = line[0] - '0';
                int distance = 241;
                foreach (string encoded in line.Substring(colon + 1).Split(','))
                    distance = Math.Min(distance, Distance(glyph.Item2, Convert.FromBase64String(encoded)));
                if (distance < best) { nextBest = best; best = distance; digit = candidate; }
                else if (distance < nextBest) nextBest = distance;
            }
            worstDistance = Math.Max(worstDistance, best);
            smallestGap = Math.Min(smallestGap, nextBest - best);
            if (best > 12 || nextBest - best < 5) { result.Reason = "숫자 모양 신뢰도 부족"; return result; }
            number = number * 10 + digit;
        }
        result.Found = true;
        result.Delta = signPixels >= 8 ? -number : number;
        result.Confidence = 1.0 - worstDistance / 240.0;
        result.Reason = "확인";
        return result;
    }
}
"@

[System.Windows.Forms.Application]::EnableVisualStyles()

# When this file is loaded through the UTF-8 launcher it runs as an in-memory
# script block, so PSScriptRoot can be empty on Windows PowerShell 5.1.
$script:appDir = if ([string]::IsNullOrWhiteSpace($PSScriptRoot)) {
    (Get-Location).Path
} else {
    $PSScriptRoot
}
$script:diagnosticDir = Join-Path $script:appDir "오류확인용_보내기"
$script:logDir = Join-Path $script:diagnosticDir "logs"
$script:captureDir = Join-Path $script:diagnosticDir "captures"
$script:resultSampleDir = Join-Path $script:diagnosticDir "result_samples"
$script:pointSampleDir = Join-Path $script:diagnosticDir "point_samples"
$script:pointSampleFullDir = Join-Path $script:pointSampleDir "full"
$script:pointSampleRoiDir = Join-Path $script:pointSampleDir "score_area"
[IO.Directory]::CreateDirectory($script:diagnosticDir) | Out-Null
[IO.Directory]::CreateDirectory($script:logDir) | Out-Null
[IO.Directory]::CreateDirectory($script:captureDir) | Out-Null
[IO.Directory]::CreateDirectory($script:resultSampleDir) | Out-Null
[IO.Directory]::CreateDirectory($script:pointSampleDir) | Out-Null
[IO.Directory]::CreateDirectory($script:pointSampleFullDir) | Out-Null
[IO.Directory]::CreateDirectory($script:pointSampleRoiDir) | Out-Null
$script:logPath = Join-Path $script:logDir ("FCManager_{0}.log" -f (Get-Date -Format "yyyyMMdd"))
$script:templateDir = Join-Path $script:appDir "templates"
$script:hdTemplateDir = Join-Path $script:appDir "templates_2560"
$script:settingsPath = Join-Path $script:appDir "settings.json"
$script:statsPath = Join-Path $script:appDir "stats.json"

$script:running = $false
$script:paused = $false
$script:actionCount = 0
$script:pauseCount = 0
$script:nextScanDue = [DateTime]::Now
$script:resumeStableSince = $null
$script:f9WasDown = $false
$script:f8WasDown = $false
$script:f8HotkeyActive = $false
$script:f8HotkeyId = 0xFC08
$script:f12WasDown = $false
$script:lastTemplateActions = @{}
$script:lastRecognitionLogAt = [DateTime]::MinValue
$script:templates = New-Object System.Collections.ArrayList
$script:hdTemplates = New-Object System.Collections.ArrayList
$script:lastRecognizedFile = ""
$script:sameScreenActionCount = 0
$script:sameScreenSince = [DateTime]::Now
$script:lastProgressAt = [DateTime]::Now
$script:stuckAlertActive = $false
$script:lastStuckAlertAt = [DateTime]::MinValue
$script:previousVisualFrame = $null
$script:lastVisualChangeAt = [DateTime]::Now
$script:notificationQueue = New-Object System.Collections.Queue
$script:activeNotification = $null
$script:httpClient = New-Object System.Net.Http.HttpClient
$script:httpClient.Timeout = [TimeSpan]::FromSeconds(10)
$script:discordEnabled = $false
$script:encryptedWebhook = ""
$script:sessionMatchCount = 0
$script:todayMatchCount = 0
$script:totalMatchCount = 0
$script:sessionWinCount = 0
$script:sessionDrawCount = 0
$script:sessionLossCount = 0
$script:sessionUnclassifiedCount = 0
$script:todayWinCount = 0
$script:todayDrawCount = 0
$script:todayLossCount = 0
$script:todayUnclassifiedCount = 0
$script:totalWinCount = 0
$script:totalDrawCount = 0
$script:totalLossCount = 0
$script:totalUnclassifiedCount = 0
$script:statsDate = Get-Date -Format "yyyy-MM-dd"
$script:resultScreenCounted = $false
$script:stopAfterCurrentMatch = $false
$script:requiredStopAfterMatch = $false
$script:pointSampleCount = 0
$script:parkingMode = $false
$script:startingRankPoints = $null
$script:currentRankPoints = $null
$script:rankResyncRequired = $false
$script:startingRankReadAt = [DateTime]::MinValue
$script:rankOcrEngine = $null
$script:rankOcrAwaiter = $null

# Template filenames intentionally define their behavior.
$templateDefinitions = @(
    [PSCustomObject]@{ File = "tier_popup.png"; Action = "click"; Label = "등급 변경 안내 확인"; X1 = 0.52; Y1 = 0.73; X2 = 0.66; Y2 = 0.81; Threshold = 4.0; ScaledThreshold = 5.0; Cooldown = 1800 },
    [PSCustomObject]@{ File = "tier_result.png"; Action = "click"; Label = "승급·강등·잔류 결과 확인"; X1 = 0.75; Y1 = 0.90; X2 = 0.89; Y2 = 0.99; Threshold = 4.0; ScaledThreshold = 5.0; Cooldown = 1800 },
    [PSCustomObject]@{ File = "click_1.png"; Action = "click"; Label = "공식경기 (전 등급)"; X1 = 0.70; Y1 = 0.72; X2 = 1.00; Y2 = 1.00; Threshold = 7.5; ScaledThreshold = 7.5; Cooldown = 1800 },
    [PSCustomObject]@{ File = "click_2.png"; Action = "click"; Label = "확인"; X1 = 0.10; Y1 = 0.30; X2 = 1.00; Y2 = 1.00; Threshold = 6.0; ScaledThreshold = 8.0; Cooldown = 1800 },
    [PSCustomObject]@{ File = "click_3.png"; Action = "click"; Label = "확인 화살표"; X1 = 0.10; Y1 = 0.30; X2 = 1.00; Y2 = 1.00; Threshold = 6.0; ScaledThreshold = 8.0; Cooldown = 1800 },
    [PSCustomObject]@{ File = "click_4.png"; Action = "click"; Label = "준비 완료"; X1 = 0.40; Y1 = 0.45; X2 = 0.85; Y2 = 0.80; Threshold = 6.0; ScaledThreshold = 8.5; Cooldown = 1800 },
    [PSCustomObject]@{ File = "client.png"; Action = "none"; Label = "FC 클라이언트"; X1 = 0.00; Y1 = 0.00; X2 = 0.25; Y2 = 0.25; Threshold = 10.0; ScaledThreshold = 12.0; Cooldown = 3000 },
    [PSCustomObject]@{ File = "esc.png"; Action = "esc"; Label = "경기 하이라이트 ESC SKIP"; X1 = 0.80; Y1 = 0.915; X2 = 0.87; Y2 = 0.975; Threshold = 36.0; ScaledThreshold = 36.0; Cooldown = 2200 },
    [PSCustomObject]@{ File = "s.png"; Action = "s"; Label = "S 안내"; X1 = 0.89; Y1 = 0.89; X2 = 0.98; Y2 = 0.99; Threshold = 12.0; ScaledThreshold = 16.0; Cooldown = 900 },
    [PSCustomObject]@{ File = "skip.png"; Action = "s"; Label = "후반 종료 SKIP"; X1 = 0.20; Y1 = 0.60; X2 = 1.00; Y2 = 1.00; Threshold = 16.0; ScaledThreshold = 18.0; Cooldown = 900 },
    [PSCustomObject]@{ File = "space_1.png"; Action = "space"; Label = "진행"; X1 = 0.60; Y1 = 0.70; X2 = 1.00; Y2 = 1.00; Threshold = 6.0; ScaledThreshold = 8.5; Cooldown = 1500 },
    [PSCustomObject]@{ File = "space_2.png"; Action = "space"; Label = "선택 완료"; X1 = 0.25; Y1 = 0.50; X2 = 0.65; Y2 = 0.75; Threshold = 6.0; ScaledThreshold = 7.0; Cooldown = 1500 },
    [PSCustomObject]@{ File = "space_3.png"; Action = "space"; Label = "다음"; X1 = 0.60; Y1 = 0.70; X2 = 1.00; Y2 = 1.00; Threshold = 6.0; ScaledThreshold = 6.0; Cooldown = 1500 }
)

foreach ($definition in $templateDefinitions) {
    $templatePath = Join-Path $script:templateDir $definition.File
    if (-not [IO.File]::Exists($templatePath)) {
        throw "화면 인식 템플릿을 찾지 못했습니다: $($definition.File)"
    }
    $templateBitmap = New-Object Drawing.Bitmap($templatePath)
    try {
        $buffer = [FCTemplateMatcher]::FromBitmap($templateBitmap)
    } finally {
        $templateBitmap.Dispose()
    }
    [void]$script:templates.Add([PSCustomObject]@{
        Definition = $definition
        Buffer = $buffer
    })

    $hdTemplatePath = Join-Path $script:hdTemplateDir $definition.File
    if ([IO.File]::Exists($hdTemplatePath)) {
        $hdTemplateBitmap = New-Object Drawing.Bitmap($hdTemplatePath)
        try {
            $hdBuffer = [FCTemplateMatcher]::FromBitmap($hdTemplateBitmap)
        } finally {
            $hdTemplateBitmap.Dispose()
        }
        [void]$script:hdTemplates.Add([PSCustomObject]@{
            Definition = $definition
            Buffer = $hdBuffer
        })
    }
}

$form = New-Object System.Windows.Forms.Form
$form.Text = "FC 온라인 감독모드 도우미 v3.0.1 일반 / 주차"
$form.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::None
$form.ClientSize = New-Object System.Drawing.Size(720, 880)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox = $false
$form.BackColor = [Drawing.Color]::FromArgb(8, 31, 23)
$form.ForeColor = [Drawing.Color]::White
$form.Font = New-Object Drawing.Font("Malgun Gothic", 9)

$title = New-Object System.Windows.Forms.Label
$title.Text = "FC 온라인 감독모드 도우미 v3.0.1 MATCH CONTROL"
$title.Font = New-Object Drawing.Font("Malgun Gothic", 18, [Drawing.FontStyle]::Bold)
$title.ForeColor = [Drawing.Color]::FromArgb(244, 249, 241)
$title.Location = New-Object Drawing.Point(24, 18)
$title.Size = New-Object Drawing.Size(500, 42)
$form.Controls.Add($title)

$subtitle = New-Object System.Windows.Forms.Label
$subtitle.Text = "일반 모드 · 연속 진행     |     주차 모드 · 목표점수 또는 최저점수에서 중지"
$subtitle.ForeColor = [Drawing.Color]::FromArgb(160, 205, 174)
$subtitle.Location = New-Object Drawing.Point(27, 62)
$subtitle.Size = New-Object Drawing.Size(650, 24)
$form.Controls.Add($subtitle)

$statusPanel = New-Object System.Windows.Forms.Panel
$statusPanel.Location = New-Object Drawing.Point(24, 94)
$statusPanel.Size = New-Object Drawing.Size(672, 94)
$statusPanel.BackColor = [Drawing.Color]::FromArgb(18, 76, 49)
$form.Controls.Add($statusPanel)
$statusPanel.Add_Paint({
    param($sender, $eventArgs)
    $pitchPen = New-Object Drawing.Pen([Drawing.Color]::FromArgb(75, 226, 238, 221), 1)
    try {
        $eventArgs.Graphics.DrawRectangle($pitchPen, 4, 4, $sender.Width - 9, $sender.Height - 9)
        $centerX = [int]($sender.Width / 2)
        $eventArgs.Graphics.DrawLine($pitchPen, $centerX, 4, $centerX, $sender.Height - 5)
        $eventArgs.Graphics.DrawEllipse($pitchPen, $centerX - 22, [int]($sender.Height / 2) - 22, 44, 44)
    } finally {
        $pitchPen.Dispose()
    }
})

$statusDot = New-Object System.Windows.Forms.Label
$statusDot.Text = "●"
$statusDot.Font = New-Object Drawing.Font("Malgun Gothic", 16, [Drawing.FontStyle]::Bold)
$statusDot.ForeColor = [Drawing.Color]::FromArgb(150, 156, 166)
$statusDot.Location = New-Object Drawing.Point(16, 10)
$statusDot.Size = New-Object Drawing.Size(30, 30)
$statusPanel.Controls.Add($statusDot)

$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Text = "대기 중"
$statusLabel.Font = New-Object Drawing.Font("Malgun Gothic", 13, [Drawing.FontStyle]::Bold)
$statusLabel.Location = New-Object Drawing.Point(48, 12)
$statusLabel.Size = New-Object Drawing.Size(330, 30)
$statusPanel.Controls.Add($statusLabel)

$windowLabel = New-Object System.Windows.Forms.Label
$windowLabel.Text = "현재 창: 확인 중"
$windowLabel.ForeColor = [Drawing.Color]::FromArgb(190, 196, 205)
$windowLabel.Location = New-Object Drawing.Point(18, 52)
$windowLabel.Size = New-Object Drawing.Size(620, 24)
$statusPanel.Controls.Add($windowLabel)

$counterLabel = New-Object System.Windows.Forms.Label
$counterLabel.Text = "화면 동작: 0회   |   자동 일시정지: 0회"
$counterLabel.TextAlign = "MiddleRight"
$counterLabel.Location = New-Object Drawing.Point(382, 14)
$counterLabel.Size = New-Object Drawing.Size(270, 28)
$statusPanel.Controls.Add($counterLabel)

$startButton = New-Object System.Windows.Forms.Button
$startButton.Text = "시작  (F9)"
$startButton.Location = New-Object Drawing.Point(24, 204)
$startButton.Size = New-Object Drawing.Size(150, 48)
$startButton.FlatStyle = "Flat"
$startButton.BackColor = [Drawing.Color]::FromArgb(24, 160, 88)
$startButton.ForeColor = [Drawing.Color]::White
$startButton.Font = New-Object Drawing.Font("Malgun Gothic", 11, [Drawing.FontStyle]::Bold)
$form.Controls.Add($startButton)

$stopButton = New-Object System.Windows.Forms.Button
$stopButton.Text = "중지  (F12)"
$stopButton.Location = New-Object Drawing.Point(184, 204)
$stopButton.Size = New-Object Drawing.Size(150, 48)
$stopButton.FlatStyle = "Flat"
$stopButton.BackColor = [Drawing.Color]::FromArgb(184, 55, 62)
$stopButton.ForeColor = [Drawing.Color]::White
$stopButton.Font = New-Object Drawing.Font("Malgun Gothic", 11, [Drawing.FontStyle]::Bold)
$stopButton.Enabled = $false
$form.Controls.Add($stopButton)

$finishMatchButton = New-Object System.Windows.Forms.Button
$finishMatchButton.Text = "이번 판까지만 (F8)"
$finishMatchButton.Location = New-Object Drawing.Point(344, 204)
$finishMatchButton.Size = New-Object Drawing.Size(172, 48)
$finishMatchButton.FlatStyle = "Flat"
$finishMatchButton.BackColor = [Drawing.Color]::FromArgb(184, 126, 45)
$finishMatchButton.ForeColor = [Drawing.Color]::White
$finishMatchButton.Font = New-Object Drawing.Font("Malgun Gothic", 10, [Drawing.FontStyle]::Bold)
$finishMatchButton.Enabled = $false
$form.Controls.Add($finishMatchButton)

$captureButton = New-Object System.Windows.Forms.Button
$captureButton.Text = "FC 화면 저장"
$captureButton.Location = New-Object Drawing.Point(526, 204)
$captureButton.Size = New-Object Drawing.Size(170, 48)
$captureButton.FlatStyle = "Flat"
$captureButton.BackColor = [Drawing.Color]::FromArgb(35, 100, 72)
$captureButton.ForeColor = [Drawing.Color]::White
$form.Controls.Add($captureButton)

$onlyFcCheck = New-Object System.Windows.Forms.CheckBox
$onlyFcCheck.Text = "FC ONLINE 창에서만 입력 (권장)"
$onlyFcCheck.Checked = $true
$onlyFcCheck.Location = New-Object Drawing.Point(30, 264)
$onlyFcCheck.Size = New-Object Drawing.Size(290, 28)
$form.Controls.Add($onlyFcCheck)

$modeGroup = New-Object System.Windows.Forms.GroupBox
$modeGroup.Text = "진행 모드"
$modeGroup.Location = New-Object Drawing.Point(24, 300)
$modeGroup.Size = New-Object Drawing.Size(672, 145)
$modeGroup.ForeColor = [Drawing.Color]::White
$modeGroup.BackColor = [Drawing.Color]::FromArgb(12, 48, 35)
$form.Controls.Add($modeGroup)

$generalModeRadio = New-Object System.Windows.Forms.RadioButton
$generalModeRadio.Text = "일반 모드 · 계속 진행"
$generalModeRadio.Location = New-Object Drawing.Point(16, 23)
$generalModeRadio.Size = New-Object Drawing.Size(225, 25)
$generalModeRadio.Checked = $true
$modeGroup.Controls.Add($generalModeRadio)

$parkingModeRadio = New-Object System.Windows.Forms.RadioButton
$parkingModeRadio.Text = "주차 모드 · 점수 조건에서 중지"
$parkingModeRadio.Location = New-Object Drawing.Point(256, 23)
$parkingModeRadio.Size = New-Object Drawing.Size(290, 25)
$modeGroup.Controls.Add($parkingModeRadio)

$readRankButton = New-Object System.Windows.Forms.Button
$readRankButton.Text = "시작점수 화면 인식"
$readRankButton.Location = New-Object Drawing.Point(16, 58)
$readRankButton.Size = New-Object Drawing.Size(174, 34)
$readRankButton.FlatStyle = "Flat"
$readRankButton.BackColor = [Drawing.Color]::FromArgb(65, 83, 133)
$readRankButton.ForeColor = [Drawing.Color]::White
$modeGroup.Controls.Add($readRankButton)

$rankPointsLabel = New-Object System.Windows.Forms.Label
$rankPointsLabel.Text = "시작점수: 미확인  |  게임의 감독 랭킹 화면에서 읽기"
$rankPointsLabel.Location = New-Object Drawing.Point(199, 64)
$rankPointsLabel.Size = New-Object Drawing.Size(457, 25)
$modeGroup.Controls.Add($rankPointsLabel)

$targetCaption = New-Object System.Windows.Forms.Label
$targetCaption.Text = "목표점수"
$targetCaption.Location = New-Object Drawing.Point(16, 106)
$targetCaption.Size = New-Object Drawing.Size(75, 23)
$modeGroup.Controls.Add($targetCaption)

$targetPointsBox = New-Object System.Windows.Forms.NumericUpDown
$targetPointsBox.Location = New-Object Drawing.Point(91, 104)
$targetPointsBox.Size = New-Object Drawing.Size(105, 24)
$targetPointsBox.Minimum = 0
$targetPointsBox.Maximum = 99999
$targetPointsBox.Value = 4000
$modeGroup.Controls.Add($targetPointsBox)

$minimumPointsCheck = New-Object System.Windows.Forms.CheckBox
$minimumPointsCheck.Text = "최저점수"
$minimumPointsCheck.Location = New-Object Drawing.Point(255, 104)
$minimumPointsCheck.Size = New-Object Drawing.Size(93, 26)
$modeGroup.Controls.Add($minimumPointsCheck)

$minimumPointsBox = New-Object System.Windows.Forms.NumericUpDown
$minimumPointsBox.Location = New-Object Drawing.Point(351, 104)
$minimumPointsBox.Size = New-Object Drawing.Size(105, 24)
$minimumPointsBox.Minimum = 0
$minimumPointsBox.Maximum = 99999
$minimumPointsBox.Value = 3500
$modeGroup.Controls.Add($minimumPointsBox)

$modeHint = New-Object System.Windows.Forms.Label
$modeHint.Text = "주차: 챔피언스 감독 랭킹 화면에서 시작점수를 읽은 뒤 실행"
$modeHint.Location = New-Object Drawing.Point(470, 102)
$modeHint.Size = New-Object Drawing.Size(192, 35)
$modeHint.ForeColor = [Drawing.Color]::FromArgb(205, 184, 243)
$modeGroup.Controls.Add($modeHint)

$matchCounterLabel = New-Object System.Windows.Forms.Label
$matchCounterLabel.Text = "이번 실행 0판 · 0승 0무 0패 (미분류 0)`r`n오늘 0판 · 전체 0판"
$matchCounterLabel.ForeColor = [Drawing.Color]::FromArgb(160, 225, 177)
$matchCounterLabel.Font = New-Object Drawing.Font("Malgun Gothic", 9, [Drawing.FontStyle]::Bold)
$matchCounterLabel.Location = New-Object Drawing.Point(24, 451)
$matchCounterLabel.Size = New-Object Drawing.Size(672, 42)
$matchCounterLabel.TextAlign = "MiddleLeft"
$form.Controls.Add($matchCounterLabel)

$discordGroup = New-Object System.Windows.Forms.GroupBox
$discordGroup.Text = "Discord 멈춤 알림"
$discordGroup.Location = New-Object Drawing.Point(24, 498)
$discordGroup.Size = New-Object Drawing.Size(672, 112)
$discordGroup.ForeColor = [Drawing.Color]::White
$discordGroup.BackColor = [Drawing.Color]::FromArgb(12, 48, 35)
$form.Controls.Add($discordGroup)

$webhookLabel = New-Object System.Windows.Forms.Label
$webhookLabel.Text = "웹훅 주소"
$webhookLabel.Location = New-Object Drawing.Point(14, 28)
$webhookLabel.Size = New-Object Drawing.Size(70, 24)
$discordGroup.Controls.Add($webhookLabel)

$webhookBox = New-Object System.Windows.Forms.TextBox
$webhookBox.Location = New-Object Drawing.Point(86, 25)
$webhookBox.Size = New-Object Drawing.Size(392, 24)
$webhookBox.UseSystemPasswordChar = $true
$discordGroup.Controls.Add($webhookBox)

$saveWebhookButton = New-Object System.Windows.Forms.Button
$saveWebhookButton.Text = "저장"
$saveWebhookButton.Location = New-Object Drawing.Point(486, 23)
$saveWebhookButton.Size = New-Object Drawing.Size(78, 29)
$saveWebhookButton.FlatStyle = "Flat"
$saveWebhookButton.BackColor = [Drawing.Color]::FromArgb(35, 100, 72)
$saveWebhookButton.ForeColor = [Drawing.Color]::White
$discordGroup.Controls.Add($saveWebhookButton)

$testWebhookButton = New-Object System.Windows.Forms.Button
$testWebhookButton.Text = "테스트"
$testWebhookButton.Location = New-Object Drawing.Point(572, 23)
$testWebhookButton.Size = New-Object Drawing.Size(82, 29)
$testWebhookButton.FlatStyle = "Flat"
$testWebhookButton.BackColor = [Drawing.Color]::FromArgb(24, 160, 88)
$testWebhookButton.ForeColor = [Drawing.Color]::White
$discordGroup.Controls.Add($testWebhookButton)

$discordCheck = New-Object System.Windows.Forms.CheckBox
$discordCheck.Text = "멈춤·오류·복구 알림 사용"
$discordCheck.Location = New-Object Drawing.Point(18, 64)
$discordCheck.Size = New-Object Drawing.Size(220, 26)
$discordGroup.Controls.Add($discordCheck)

$discordStatus = New-Object System.Windows.Forms.Label
$discordStatus.Text = "웹훅을 입력하고 저장해 주세요."
$discordStatus.ForeColor = [Drawing.Color]::FromArgb(190, 196, 205)
$discordStatus.Location = New-Object Drawing.Point(244, 67)
$discordStatus.Size = New-Object Drawing.Size(410, 24)
$discordStatus.TextAlign = "MiddleRight"
$discordGroup.Controls.Add($discordStatus)

$note = New-Object System.Windows.Forms.Label
$note.Text = "사용법: F9 시작 · F8 이번 판까지만 예약/취소 · F12 즉시 중지"
$note.ForeColor = [Drawing.Color]::FromArgb(236, 190, 86)
$note.Location = New-Object Drawing.Point(27, 624)
$note.Size = New-Object Drawing.Size(665, 26)
$form.Controls.Add($note)

$logBox = New-Object System.Windows.Forms.RichTextBox
$logBox.Location = New-Object Drawing.Point(24, 658)
$logBox.Size = New-Object Drawing.Size(672, 172)
$logBox.ReadOnly = $true
$logBox.BackColor = [Drawing.Color]::FromArgb(5, 22, 16)
$logBox.ForeColor = [Drawing.Color]::FromArgb(210, 231, 216)
$logBox.BorderStyle = "FixedSingle"
$logBox.Font = New-Object Drawing.Font("Consolas", 9)
$form.Controls.Add($logBox)

$footer = New-Object System.Windows.Forms.Label
$footer.Text = "외부 자동 입력은 게임 운영정책에 따라 제한될 수 있습니다. 사용 책임은 사용자에게 있습니다."
$footer.ForeColor = [Drawing.Color]::FromArgb(145, 150, 158)
$footer.Location = New-Object Drawing.Point(27, 846)
$footer.Size = New-Object Drawing.Size(665, 22)
$form.Controls.Add($footer)

function Write-Log([string]$message) {
    $line = "[{0}] {1}" -f (Get-Date -Format "HH:mm:ss"), $message
    $logBox.AppendText($line + [Environment]::NewLine)
    $logBox.SelectionStart = $logBox.TextLength
    $logBox.ScrollToCaret()
    try { Add-Content -LiteralPath $script:logPath -Value $line -Encoding UTF8 } catch {}
}

function Save-DiagnosticInfo([string]$lastEvent) {
    try {
        $bounds = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
        $fcWindowText = "찾지 못함"
        $fcInfo = Get-FCWindowInfo
        if ($null -ne $fcInfo) {
            $fcRect = New-Object FCNative+RECT
            if ([FCNative]::GetWindowRect($fcInfo.Handle, [ref]$fcRect)) {
                $fcWidth = $fcRect.Right - $fcRect.Left
                $fcHeight = $fcRect.Bottom - $fcRect.Top
                $fcWindowText = "$($fcWidth)x$($fcHeight) / 위치 $($fcRect.Left),$($fcRect.Top)"
            }
        }
        $lines = @(
            "FC 온라인 감독모드 도우미 v3.0.1 일반·주차 베타 진단정보",
            "생성 시각: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')",
            "마지막 상태: $lastEvent",
            "Windows: $([Environment]::OSVersion.VersionString)",
            "PowerShell: $($PSVersionTable.PSVersion.ToString())",
            "DPI 인식: $script:dpiAwarenessMode",
            "주 모니터: $($bounds.Width)x$($bounds.Height)",
            "FC 창: $fcWindowText",
            "FC 권장 설정: 1280x720 창모드 / Windows 배율 100%",
            "전적: $(Get-MatchSummary)",
            "",
            "이 폴더에는 Discord 웹훅과 settings.json이 포함되지 않습니다."
        )
        $lines | Set-Content -LiteralPath (Join-Path $script:diagnosticDir "진단정보.txt") -Encoding UTF8
    } catch {}
}

function Update-MatchCounter {
    $matchCounterLabel.Text = "이번 실행 $($script:sessionMatchCount)판 · $($script:sessionWinCount)승 $($script:sessionDrawCount)무 $($script:sessionLossCount)패 (미분류 $($script:sessionUnclassifiedCount))`r`n" +
        "오늘 $($script:todayMatchCount)판 $($script:todayWinCount)승 $($script:todayDrawCount)무 $($script:todayLossCount)패(미분류 $($script:todayUnclassifiedCount)) · 전체 $($script:totalMatchCount)판 · 점수 샘플 $($script:pointSampleCount)장"
}

function Save-MatchStats {
    try {
        $stats = [ordered]@{
            Date = $script:statsDate
            TodayCount = [int]$script:todayMatchCount
            TotalCount = [int]$script:totalMatchCount
            TodayWin = [int]$script:todayWinCount
            TodayDraw = [int]$script:todayDrawCount
            TodayLoss = [int]$script:todayLossCount
            TodayUnclassified = [int]$script:todayUnclassifiedCount
            TotalWin = [int]$script:totalWinCount
            TotalDraw = [int]$script:totalDrawCount
            TotalLoss = [int]$script:totalLossCount
            TotalUnclassified = [int]$script:totalUnclassifiedCount
        }
        $stats | ConvertTo-Json | Set-Content -LiteralPath $script:statsPath -Encoding UTF8
    } catch {
        Write-Log "판수 기록 저장 실패: $($_.Exception.Message)"
    }
}

function Load-MatchStats {
    $today = Get-Date -Format "yyyy-MM-dd"
    $script:statsDate = $today
    if ([IO.File]::Exists($script:statsPath)) {
        try {
            $stats = Get-Content -LiteralPath $script:statsPath -Raw -Encoding UTF8 | ConvertFrom-Json
            $script:totalMatchCount = [Math]::Max(0, [int]$stats.TotalCount)
            $script:totalWinCount = [Math]::Max(0, [int]$stats.TotalWin)
            $script:totalDrawCount = [Math]::Max(0, [int]$stats.TotalDraw)
            $script:totalLossCount = [Math]::Max(0, [int]$stats.TotalLoss)
            $script:totalUnclassifiedCount = [Math]::Max(0, [int]$stats.TotalUnclassified)
            $totalKnown = $script:totalWinCount + $script:totalDrawCount + $script:totalLossCount + $script:totalUnclassifiedCount
            if ($totalKnown -lt $script:totalMatchCount) {
                $script:totalUnclassifiedCount += ($script:totalMatchCount - $totalKnown)
            }
            if ([string]$stats.Date -eq $today) {
                $script:todayMatchCount = [Math]::Max(0, [int]$stats.TodayCount)
                $script:todayWinCount = [Math]::Max(0, [int]$stats.TodayWin)
                $script:todayDrawCount = [Math]::Max(0, [int]$stats.TodayDraw)
                $script:todayLossCount = [Math]::Max(0, [int]$stats.TodayLoss)
                $script:todayUnclassifiedCount = [Math]::Max(0, [int]$stats.TodayUnclassified)
                $todayKnown = $script:todayWinCount + $script:todayDrawCount + $script:todayLossCount + $script:todayUnclassifiedCount
                if ($todayKnown -lt $script:todayMatchCount) {
                    $script:todayUnclassifiedCount += ($script:todayMatchCount - $todayKnown)
                }
            }
        } catch {
            Write-Log "기존 판수 기록을 읽지 못해 새 기록으로 시작합니다."
        }
    }
    Update-MatchCounter
}

function Get-MatchSummary {
    $summary = "이번 실행 $($script:sessionMatchCount)판 ($($script:sessionWinCount)승 $($script:sessionDrawCount)무 $($script:sessionLossCount)패 · 미분류 $($script:sessionUnclassifiedCount)) · 오늘 $($script:todayMatchCount)판 · 전체 $($script:totalMatchCount)판"
    if ($script:parkingMode -and $null -ne $script:currentRankPoints) {
        $summary += " · 확인된 랭킹 점수 $($script:currentRankPoints)점"
    }
    return $summary
}

function Save-ResultSample($frame, [int]$matchNumber, [string]$result, [string]$scoreText) {
    try {
        $bitmap = [FCTemplateMatcher]::ToBitmap($frame.Buffer)
        if ($null -eq $bitmap) { return "" }
        try {
            $fileName = "Result_{0}_match{1:D4}_{2}.png" -f (Get-Date -Format "yyyyMMdd_HHmmss"), $matchNumber, $result
            $path = Join-Path $script:resultSampleDir $fileName
            $bitmap.Save($path, [Drawing.Imaging.ImageFormat]::Png)
        } finally {
            $bitmap.Dispose()
        }

        $indexPath = Join-Path $script:resultSampleDir "samples.csv"
        if (-not [IO.File]::Exists($indexPath)) {
            Add-Content -LiteralPath $indexPath -Value "time,session,today,total,result,file" -Encoding UTF8
        }
        $row = "{0},{1},{2},{3},{4},{5}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $script:sessionMatchCount, $script:todayMatchCount, $script:totalMatchCount, $result, $fileName
        Add-Content -LiteralPath $indexPath -Value $row -Encoding UTF8
        return $fileName
    } catch {
        Write-Log "경기 결과 샘플 저장 실패: $($_.Exception.Message)"
        return ""
    }
}

function Get-SettledResultFrame($initialFrame) {
    # The green '다음' button appears before every reward row has finished
    # fading in. Keep the result screen open long enough to capture the final
    # points row. This also gives the existing win/draw/loss reader a stable
    # scoreboard instead of a transition frame.
    $bestFrame = $initialFrame
    $sameWindow = $true
    Set-Status "경기 결과 화면 안정화 중" ([Drawing.Color]::FromArgb(236, 190, 86))
    for ($attempt = 1; $attempt -le 14; $attempt++) {
        Start-Sleep -Milliseconds 250
        # Do not pump WinForms messages here. A nested timer tick could see
        # the same '다음' button and press Space before sampling is complete.
        $info = Get-ForegroundInfo
        if (-not $info.Allowed -or $info.Handle -ne $initialFrame.Handle) {
            $sameWindow = $false
            break
        }
        $nextFrame = Get-FCFrame $initialFrame.Handle
        if ($null -ne $nextFrame) { $bestFrame = $nextFrame }
    }
    return [PSCustomObject]@{ Frame = $bestFrame; SameWindow = $sameWindow }
}

function Save-PointSample($frame, [int]$matchNumber, [string]$result, [string]$scoreText) {
    try {
        $bitmap = [FCTemplateMatcher]::ToBitmap($frame.Buffer)
        if ($null -eq $bitmap) { return "" }

        $stamp = Get-Date -Format "yyyyMMdd_HHmmss_fff"
        $safeResult = if ($result -match '^(win|draw|loss|unclassified)$') { $result } else { "unclassified" }
        $baseName = "Point_{0}_match{1:D4}_{2}" -f $stamp, $matchNumber, $safeResult
        $fullName = "$baseName`_full.png"
        $roiName = "$baseName`_score_area.png"
        $fullPath = Join-Path $script:pointSampleFullDir $fullName
        $roiPath = Join-Path $script:pointSampleRoiDir $roiName

        try {
            $bitmap.Save($fullPath, [Drawing.Imaging.ImageFormat]::Png)

            # Broad normalized reward-panel crop. It deliberately includes the
            # label as well as the signed value so future OCR can validate both
            # '승점' and high-tier '점수 획득' layouts.
            $left = [Math]::Max(0, [int]($bitmap.Width * 0.27))
            $top = [Math]::Max(0, [int]($bitmap.Height * 0.27))
            $right = [Math]::Min($bitmap.Width, [int]($bitmap.Width * 0.99))
            $bottom = [Math]::Min($bitmap.Height, [int]($bitmap.Height * 0.82))
            $roiRect = New-Object Drawing.Rectangle($left, $top, ($right - $left), ($bottom - $top))
            $roiBitmap = $bitmap.Clone($roiRect, [Drawing.Imaging.PixelFormat]::Format32bppArgb)
            try {
                $roiBitmap.Save($roiPath, [Drawing.Imaging.ImageFormat]::Png)
            } finally {
                $roiBitmap.Dispose()
            }
        } finally {
            $width = $bitmap.Width
            $height = $bitmap.Height
            $bitmap.Dispose()
        }

        $indexPath = Join-Path $script:pointSampleDir "point_samples.csv"
        if (-not [IO.File]::Exists($indexPath)) {
            Add-Content -LiteralPath $indexPath -Value "time,session,today,total,result,match_score,full_file,score_area_file,width,height" -Encoding UTF8
        }
        $row = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9}" -f `
            (Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"), $script:sessionMatchCount,
            $script:todayMatchCount, $script:totalMatchCount, $safeResult, $scoreText,
            $fullName, $roiName, $width, $height
        Add-Content -LiteralPath $indexPath -Value $row -Encoding UTF8
        $script:pointSampleCount++
        return $fullName
    } catch {
        Write-Log "점수 화면 샘플 저장 실패: $($_.Exception.Message)"
        return ""
    }
}

function Get-StableScoreResult($initialFrame) {
    $bestFrame = $initialFrame
    $lastScore = [FCScoreReader]::Read($initialFrame.Buffer)
    if ($lastScore.Found) {
        return [PSCustomObject]@{ Score = $lastScore; Frame = $initialFrame }
    }

    for ($attempt = 1; $attempt -le 6; $attempt++) {
        Start-Sleep -Milliseconds 250
        $info = Get-ForegroundInfo
        if (-not $info.Allowed -or $info.Handle -ne $initialFrame.Handle) { break }
        $nextFrame = Get-FCFrame $initialFrame.Handle
        if ($null -eq $nextFrame) { continue }
        $bestFrame = $nextFrame
        $lastScore = [FCScoreReader]::Read($nextFrame.Buffer)
        if ($lastScore.Found) {
            return [PSCustomObject]@{ Score = $lastScore; Frame = $nextFrame }
        }
    }
    return [PSCustomObject]@{ Score = $lastScore; Frame = $bestFrame }
}

function Get-ParkingTransition($reading, $current, [int]$target, [bool]$minimumEnabled, [int]$minimum) {
    if ($reading.Reason -eq '등급 승점 화면') {
        return [PSCustomObject]@{ Kind='League'; Current=$null; Stop=$false; Resync=$false }
    }
    if (-not $reading.Found) {
        return [PSCustomObject]@{ Kind='Unreadable'; Current=$null; Stop=$true; Resync=$true }
    }
    if ($null -eq $current) {
        return [PSCustomObject]@{ Kind='Resync'; Current=$null; Stop=$false; Resync=$true }
    }
    $total = [int]$current + [int]$reading.Delta
    $kind = if ($total -ge $target) { 'Target' } elseif ($minimumEnabled -and $total -le $minimum) { 'Minimum' } else { 'Rank' }
    return [PSCustomObject]@{ Kind=$kind; Current=$total; Stop=($kind -in @('Target','Minimum')); Resync=$false }
}

function Get-StableRankResult($initialFrame) {
    $last = $null
    $frame = $initialFrame
    for ($attempt = 0; $attempt -lt 5; $attempt++) {
        $reading = [FCRankPointsReader]::Read($frame.Buffer)
        if ($null -ne $last -and
            (($reading.Found -and $last.Found -and $reading.Delta -eq $last.Delta) -or
             ($reading.Reason -eq '등급 승점 화면' -and $last.Reason -eq $reading.Reason))) { return $reading }
        $last = $reading
        if ($attempt -eq 4) { break }
        Start-Sleep -Milliseconds 300
        $info = Get-ForegroundInfo
        if (-not $info.Allowed -or $info.Handle -ne $initialFrame.Handle) { break }
        $next = Get-FCFrame $initialFrame.Handle
        if ($null -eq $next) { break }
        $frame = $next
    }
    return [PSCustomObject]@{ Found=$false; Delta=0; Reason='점수 재확인 실패 또는 연속 판독 불일치' }
}

function Sync-ParkingRank($frame) {
    $rank = Read-StartingRankPoints $frame
    if (-not $rank.Found) { throw "등급 복귀 후 현재점수 재확인 실패: $($rank.Reason)" }
    Start-Sleep -Milliseconds 350
    $info = Get-ForegroundInfo
    if (-not $info.Allowed -or $info.Handle -ne $frame.Handle) { return $false }
    $secondFrame = Get-FCFrame $frame.Handle
    if ($null -eq $secondFrame) { return $false }
    $second = Read-StartingRankPoints $secondFrame
    if (-not $second.Found -or $second.Points -ne $rank.Points) { throw '등급 복귀 후 현재점수 연속 판독 불일치' }
    $script:currentRankPoints = [int]$rank.Points
    $script:rankResyncRequired = $false
    $rankPointsLabel.Text = "등급 복귀 후 현재 $($script:currentRankPoints)점 재확인"
    Write-Log "등급 복귀 후 현재점수 재확인: $($script:currentRankPoints)점"
    if ($script:currentRankPoints -ge [int]$targetPointsBox.Value -or
        ($minimumPointsCheck.Checked -and $script:currentRankPoints -le [int]$minimumPointsBox.Value)) {
        Stop-Automation '재확인 점수 조건 도달'
        return $false
    }
    return $true
}

function Register-CompletedMatch($frame) {
    if ($script:resultScreenCounted) { return }
    $script:resultScreenCounted = $true

    $today = Get-Date -Format "yyyy-MM-dd"
    if ($script:statsDate -ne $today) {
        $script:statsDate = $today
        $script:todayMatchCount = 0
        $script:todayWinCount = 0
        $script:todayDrawCount = 0
        $script:todayLossCount = 0
        $script:todayUnclassifiedCount = 0
    }

    $settled = Get-SettledResultFrame $frame
    $frameForAnalysis = $settled.Frame
    Set-Status "경기 결과 판정 및 점수 저장 중" ([Drawing.Color]::FromArgb(236, 190, 86))
    $analysis = Get-StableScoreResult $frameForAnalysis
    $rankDelta = $null
    if ($script:parkingMode) {
        $reading = Get-StableRankResult $analysis.Frame
        $transition = Get-ParkingTransition $reading $script:currentRankPoints ([int]$targetPointsBox.Value) $minimumPointsCheck.Checked ([int]$minimumPointsBox.Value)
        $script:currentRankPoints = $transition.Current
        $script:rankResyncRequired = $transition.Resync
        if ($transition.Stop) { $script:stopAfterCurrentMatch = $true; $script:requiredStopAfterMatch = $true }
        switch ($transition.Kind) {
            'League' {
                $rankPointsLabel.Text = '챔피언스 아래 등급 · 승점 합산 제외 · 등급 복귀 후 점수 재확인'
                Write-Log '등급 승점 화면: 랭킹 점수 합산을 보류하고 등급 경기를 계속합니다.'
            }
            'Resync' {
                $rankPointsLabel.Text = '챔피언스 점수 복귀 · 다음 경기 전 현재점수 재확인 대기'
                Write-Log '랭킹 점수가 다시 나타났습니다. 기존 누적값을 사용하지 않고 로비에서 재확인합니다.'
            }
            'Unreadable' {
                $rankPointsLabel.Text = '점수 미확인 · 재판독 실패로 중지'
                Write-Log "점수 재판독 후에도 확인할 수 없어 다음 경기를 시작하지 않습니다. ($($reading.Reason))"
                Queue-DiscordNotification '주차 점수 판독 실패' '연속 재판독에 실패해 중지합니다. 현재점수를 다시 읽어 주세요.'
            }
            default {
                $rankDelta = [int]$reading.Delta
                $rankPointsLabel.Text = "시작 $($script:startingRankPoints)점 | 현재 $($script:currentRankPoints)점 ($('{0:+#;-#;0}' -f $rankDelta))"
                $rankRecord = '{0},{1},{2},{3}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), ($script:sessionMatchCount + 1), $rankDelta, $script:currentRankPoints
                Add-Content -LiteralPath (Join-Path $script:diagnosticDir 'rank_points.csv') -Value $rankRecord -Encoding UTF8
                Write-Log "주차 점수: $rankDelta 점, 현재 $($script:currentRankPoints)점"
                if ($transition.Kind -eq 'Target') {
                    Write-Log "목표점수 $([int]$targetPointsBox.Value)점 도달. 이번 결과를 넘긴 뒤 중지합니다."
                    Queue-DiscordNotification '주차 목표점수 도달' "현재 $($script:currentRankPoints)점"
                } elseif ($transition.Kind -eq 'Minimum') {
                    Write-Log "최저점수 $([int]$minimumPointsBox.Value)점 도달. 이번 결과를 넘긴 뒤 중지합니다."
                    Queue-DiscordNotification '주차 최저점수 도달' "현재 $($script:currentRankPoints)점"
                }
            }
        }
    }
    $result = "unclassified"
    $resultLabel = "미분류"
    $scoreText = "점수 인식 실패"
    if ($analysis.Score.Found) {
        $leftScore = [int]$analysis.Score.LeftScore
        $rightScore = [int]$analysis.Score.RightScore
        $scoreText = "$leftScore`:$rightScore"
        if ($leftScore -gt $rightScore) { $result = "win"; $resultLabel = "승" }
        elseif ($leftScore -eq $rightScore) { $result = "draw"; $resultLabel = "무" }
        else { $result = "loss"; $resultLabel = "패" }
    }

    $script:sessionMatchCount++
    $script:todayMatchCount++
    $script:totalMatchCount++
    switch ($result) {
        "win" {
            $script:sessionWinCount++; $script:todayWinCount++; $script:totalWinCount++
        }
        "draw" {
            $script:sessionDrawCount++; $script:todayDrawCount++; $script:totalDrawCount++
        }
        "loss" {
            $script:sessionLossCount++; $script:todayLossCount++; $script:totalLossCount++
        }
        default {
            $script:sessionUnclassifiedCount++; $script:todayUnclassifiedCount++; $script:totalUnclassifiedCount++
        }
    }
    Save-MatchStats
    Update-MatchCounter
    $sampleName = Save-ResultSample $analysis.Frame $script:totalMatchCount $result $scoreText
    $pointSampleName = Save-PointSample $analysis.Frame $script:totalMatchCount $result $scoreText
    Update-MatchCounter
    $sampleText = if ([string]::IsNullOrWhiteSpace($sampleName)) { "샘플 저장 실패" } else { "샘플: $sampleName" }
    $pointSampleText = if ([string]::IsNullOrWhiteSpace($pointSampleName)) { "점수 샘플 저장 실패" } else { "점수 샘플: $pointSampleName" }
    Write-Log "경기 완료 집계: $scoreText $resultLabel · $(Get-MatchSummary) · $sampleText · $pointSampleText"
    if (-not $settled.SameWindow) {
        Write-Log "결과 화면 대기 중 FC 창 선택이 해제되어 입력은 보류합니다. 저장된 화면을 확인해 주세요."
    }
    Save-DiagnosticInfo "경기 완료: $scoreText $resultLabel"

    if (($script:sessionMatchCount % 20) -eq 0) {
        Queue-DiscordNotification "FC 감독모드 20판 진행 알림" "$(Get-MatchSummary)`n최근 경기: $scoreText $resultLabel"
    }
}

function Test-DiscordWebhookUrl([string]$url) {
    if ([string]::IsNullOrWhiteSpace($url)) { return $false }
    return $url -match '^https://(canary\.|ptb\.)?(discord(?:app)?\.com)/api/webhooks/[0-9]+/[A-Za-z0-9._-]+/?$'
}

function Protect-DiscordWebhook([string]$url) {
    $secure = ConvertTo-SecureString -String $url -AsPlainText -Force
    return ConvertFrom-SecureString -SecureString $secure
}

function Unprotect-DiscordWebhook {
    if ([string]::IsNullOrWhiteSpace($script:encryptedWebhook)) { return "" }
    try {
        $secure = ConvertTo-SecureString -String $script:encryptedWebhook
        $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
        try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer) }
        finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) }
    } catch {
        return ""
    }
}

function Save-DiscordSettings {
    $settings = [ordered]@{
        DiscordEnabled = [bool]$script:discordEnabled
        EncryptedWebhook = [string]$script:encryptedWebhook
    }
    $settings | ConvertTo-Json | Set-Content -LiteralPath $script:settingsPath -Encoding UTF8
}

function Load-DiscordSettings {
    if (-not [IO.File]::Exists($script:settingsPath)) { return }
    try {
        $settings = Get-Content -LiteralPath $script:settingsPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $script:discordEnabled = [bool]$settings.DiscordEnabled
        $script:encryptedWebhook = [string]$settings.EncryptedWebhook
        $savedUrl = Unprotect-DiscordWebhook
        if (Test-DiscordWebhookUrl $savedUrl) {
            $webhookBox.Text = $savedUrl
            $discordCheck.Checked = $script:discordEnabled
            $discordStatus.Text = "암호화하여 저장된 웹훅을 불러왔습니다."
        } else {
            $script:discordEnabled = $false
            $script:encryptedWebhook = ""
            $discordCheck.Checked = $false
            $discordStatus.Text = "저장된 웹훅을 사용할 수 없습니다. 다시 입력해 주세요."
        }
    } catch {
        $script:discordEnabled = $false
        $script:encryptedWebhook = ""
        $discordStatus.Text = "설정을 불러오지 못했습니다. 웹훅을 다시 저장해 주세요."
    }
}

function Save-DiscordSettingsFromUi {
    $url = $webhookBox.Text.Trim()
    if (-not (Test-DiscordWebhookUrl $url)) {
        throw "Discord 웹훅 주소 형식이 올바르지 않습니다."
    }
    $script:encryptedWebhook = Protect-DiscordWebhook $url
    $script:discordEnabled = [bool]$discordCheck.Checked
    Save-DiscordSettings
    $discordStatus.Text = if ($script:discordEnabled) { "알림 사용 중" } else { "저장됨 · 알림 꺼짐" }
    Write-Log "Discord 웹훅 설정을 안전하게 저장했습니다."
}

function Queue-DiscordNotification([string]$titleText, [string]$message, [bool]$force = $false) {
    if (-not $force -and -not $script:discordEnabled) { return }
    $url = Unprotect-DiscordWebhook
    if (-not (Test-DiscordWebhookUrl $url)) {
        Write-Log "Discord 알림을 보내지 못했습니다: 저장된 웹훅을 확인해 주세요."
        return
    }
    $item = [PSCustomObject]@{
        Url = $url
        Title = $titleText
        Message = $message
        Attempt = 0
        DueAt = [DateTime]::Now
    }
    $script:notificationQueue.Enqueue($item)
}

function Process-DiscordQueue {
    if ($null -ne $script:activeNotification) {
        $active = $script:activeNotification
        if (-not $active.Task.IsCompleted) { return }
        $success = $false
        $failure = ""
        try {
            if ($active.Task.IsCanceled) {
                $failure = "전송 시간 초과"
            } elseif ($active.Task.IsFaulted) {
                $failure = $active.Task.Exception.GetBaseException().Message
            } else {
                $response = $active.Task.Result
                $success = $response.IsSuccessStatusCode
                if (-not $success) { $failure = "HTTP $([int]$response.StatusCode)" }
                $response.Dispose()
            }
        } catch {
            $failure = $_.Exception.Message
        } finally {
            $active.Content.Dispose()
        }

        if ($success) {
            Write-Log "Discord 알림을 보냈습니다: $($active.Item.Title)"
            $discordStatus.Text = "최근 알림 전송 성공: $(Get-Date -Format 'HH:mm:ss')"
        } else {
            $active.Item.Attempt++
            if ($active.Item.Attempt -lt 3) {
                $active.Item.DueAt = [DateTime]::Now.AddSeconds([Math]::Pow(2, $active.Item.Attempt))
                $script:notificationQueue.Enqueue($active.Item)
                Write-Log "Discord 알림 전송 재시도 $($active.Item.Attempt)/2"
            } else {
                if ($failure.Length -gt 120) { $failure = $failure.Substring(0, 120) }
                Write-Log "Discord 알림 전송 실패: $failure"
                $discordStatus.Text = "최근 알림 전송 실패 · 웹훅/인터넷 확인"
            }
        }
        $script:activeNotification = $null
    }

    if ($null -eq $script:activeNotification -and $script:notificationQueue.Count -gt 0) {
        $next = $script:notificationQueue.Peek()
        if ([DateTime]::Now -lt $next.DueAt) { return }
        [void]$script:notificationQueue.Dequeue()
        $contentText = "**$($next.Title)**`n$($next.Message)`n시간: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
        if ($contentText.Length -gt 1900) { $contentText = $contentText.Substring(0, 1900) }
        $payload = @{ content = $contentText; username = "FC Manager Assistant" } | ConvertTo-Json -Compress
        $content = [System.Net.Http.StringContent]::new($payload, [Text.Encoding]::UTF8, "application/json")
        $task = $script:httpClient.PostAsync($next.Url, $content)
        $script:activeNotification = [PSCustomObject]@{ Item = $next; Task = $task; Content = $content }
    }
}

function Send-StuckAlert([string]$reason) {
    $now = [DateTime]::Now
    if (($now - $script:lastStuckAlertAt).TotalMinutes -lt 10) { return }
    $script:lastStuckAlertAt = $now
    $script:stuckAlertActive = $true
    Queue-DiscordNotification "FC 감독모드 멈춤 감지" "$reason`n$(Get-MatchSummary)`nPC에서 FC 온라인 화면과 도우미 로그를 확인해 주세요."
    Write-Log "멈춤 가능성을 감지했습니다: $reason"
    Save-DiagnosticInfo "멈춤 감지: $reason"
    # Preserve the actual screen that failed before the user has to intervene.
    try {
        $foreground = Get-ForegroundInfo
        if ($foreground.Allowed) {
            $stuckFrame = Get-FCFrame $foreground.Handle
            if ($null -ne $stuckFrame) {
                $snapshot = [FCTemplateMatcher]::ToBitmap($stuckFrame.Buffer)
                if ($null -ne $snapshot) {
                    try {
                        $snapshotPath = Join-Path $script:captureDir ("stuck_{0}.png" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
                        $snapshot.Save($snapshotPath, [Drawing.Imaging.ImageFormat]::Png)
                        Write-Log "멈춤 당시 화면을 저장했습니다: $([IO.Path]::GetFileName($snapshotPath))"
                    } finally { $snapshot.Dispose() }
                }
            }
        }
    } catch {
        Write-Log "멈춤 화면 저장 실패: $($_.Exception.Message)"
    }
}

function Mark-AutomationProgress([string]$fileName, [string]$label) {
    $wasStuck = $script:stuckAlertActive
    $script:lastProgressAt = [DateTime]::Now

    if ($script:lastRecognizedFile -eq $fileName) {
        $script:sameScreenActionCount++
    } else {
        $script:lastRecognizedFile = $fileName
        $script:sameScreenActionCount = 1
        $script:sameScreenSince = [DateTime]::Now
        $script:stuckAlertActive = $false
        if ($wasStuck) {
            Queue-DiscordNotification "FC 감독모드 정상 작동 재개" "새 화면 '$label'을 인식해 자동 진행이 다시 작동했습니다.`n$(Get-MatchSummary)"
        }
    }

    if ($script:sameScreenActionCount -ge 3) {
        if ($fileName -eq "s.png") {
            if (([DateTime]::Now - $script:lastVisualChangeAt).TotalMinutes -ge 3) {
                Send-StuckAlert "S 안내가 반복되는 동안 FC 경기 화면이 3분 이상 변하지 않았습니다."
            }
        } elseif (([DateTime]::Now - $script:sameScreenSince).TotalSeconds -ge 15) {
            Send-StuckAlert "'$label' 화면에서 같은 동작이 반복되고 15초 이상 화면이 바뀌지 않았습니다."
        }
    }
}

function Show-TopmostError([string]$message, [string]$titleText = "FC 감독모드 도우미 오류") {
    $previousTopMost = $form.TopMost
    try {
        if ($form.WindowState -eq [System.Windows.Forms.FormWindowState]::Minimized) {
            $form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
        }
        $form.Show()
        $form.TopMost = $true
        $form.BringToFront()
        $form.Activate()
        [System.Windows.Forms.MessageBox]::Show(
            $form,
            $message,
            $titleText,
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    } finally {
        $form.TopMost = $previousTopMost
    }
}

function Get-ForegroundInfo {
    $handle = [FCNative]::GetForegroundWindow()
    if ($handle -eq [IntPtr]::Zero) {
        return [PSCustomObject]@{ Handle = $handle; Allowed = $false; Title = "창 없음"; Process = "" }
    }
    $titleText = [FCNative]::GetTitle($handle)
    $processName = [FCNative]::GetProcessName($handle)
    $allowed = ($processName -ieq "fczf") -or ($titleText -like "*FC ONLINE*")
    return [PSCustomObject]@{ Handle = $handle; Allowed = $allowed; Title = $titleText; Process = $processName }
}

function Get-FCWindowInfo {
    foreach ($process in @(Get-Process -Name "fczf" -ErrorAction SilentlyContinue)) {
        try {
            if ($process.MainWindowHandle -ne [IntPtr]::Zero) {
                return [PSCustomObject]@{
                    Handle = $process.MainWindowHandle
                    Allowed = $true
                    Title = $process.MainWindowTitle
                    Process = $process.ProcessName
                }
            }
        } catch {}
    }
    return $null
}

function Get-FCFrame([IntPtr]$handle) {
    $rect = New-Object FCNative+RECT
    if (-not [FCNative]::GetWindowRect($handle, [ref]$rect)) { return $null }
    $width = $rect.Right - $rect.Left
    $height = $rect.Bottom - $rect.Top
    if ($width -lt 640 -or $height -lt 360) { return $null }

    $bitmap = New-Object Drawing.Bitmap($width, $height)
    $graphics = [Drawing.Graphics]::FromImage($bitmap)
    try {
        $graphics.CopyFromScreen($rect.Left, $rect.Top, 0, 0, (New-Object Drawing.Size($width, $height)))
        $buffer = [FCTemplateMatcher]::FromBitmap($bitmap)
        return [PSCustomObject]@{ Rect = $rect; Buffer = $buffer; Handle = $handle }
    } finally {
        $graphics.Dispose()
        $bitmap.Dispose()
    }
}

function Initialize-RankOcr {
    if ($null -ne $script:rankOcrEngine) { return }
    Add-Type -AssemblyName System.Runtime.WindowsRuntime
    $null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
    $null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
    $null = [Windows.Media.Ocr.OcrResult, Windows.Foundation, ContentType = WindowsRuntime]
    $null = [Windows.Foundation.IAsyncOperation`1, Windows.Foundation, ContentType = WindowsRuntime]
    $null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Foundation, ContentType = WindowsRuntime]
    $null = [Windows.Storage.Streams.IRandomAccessStream, Windows.Foundation, ContentType = WindowsRuntime]
    $null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType = WindowsRuntime]
    $null = [Windows.Globalization.Language, Windows.Globalization, ContentType = WindowsRuntime]
    $script:rankOcrAwaiter = [WindowsRuntimeSystemExtensions].GetMember('GetAwaiter').Where({
        $PSItem.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
    }, 'First')[0]
    if ($null -eq $script:rankOcrAwaiter) { throw 'Windows OCR 비동기 호출을 준비하지 못했습니다.' }
    $language = [Windows.Globalization.Language]::new('en-US')
    $script:rankOcrEngine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($language)
    if ($null -eq $script:rankOcrEngine) {
        $script:rankOcrEngine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
    }
    if ($null -eq $script:rankOcrEngine) { throw 'Windows OCR 언어를 사용할 수 없습니다.' }
}

function Await-RankOcr($operation, [Type]$resultType) {
    return $script:rankOcrAwaiter.MakeGenericMethod($resultType).Invoke($null, @($operation)).GetResult()
}

function Read-StartingRankPoints($frame) {
    $notFound = [PSCustomObject]@{ Found = $false; Points = 0; Reason = '챔피언스 감독 랭킹 화면이 아닙니다.' }
    $bitmap = [FCTemplateMatcher]::ToBitmap($frame.Buffer)
    if ($null -eq $bitmap) { return $notFound }
    try {
        $normalized = New-Object Drawing.Bitmap(1296, ([int][Math]::Round($bitmap.Height * 1296.0 / $bitmap.Width)))
        try {
            $graphics = [Drawing.Graphics]::FromImage($normalized)
            try { $graphics.DrawImage($bitmap, 0, 0, $normalized.Width, $normalized.Height) }
            finally { $graphics.Dispose() }
            if ($normalized.Height -lt 720) { return $notFound }
            # Official-match lobby tab and the purple Champions ranking banner.
            $tab = $normalized.GetPixel(250, 135)
            $banner = $normalized.GetPixel(500, 245)
            if ($tab.R -lt 225 -or $tab.G -lt 225 -or $tab.B -lt 225 -or
                $banner.B -lt ($banner.R + 25) -or $banner.B -lt ($banner.G + 25)) {
                return $notFound
            }
            $crop = $normalized.Clone((New-Object Drawing.Rectangle(235, 274, 120, 56)), [Drawing.Imaging.PixelFormat]::Format32bppArgb)
            try {
                $enlarged = New-Object Drawing.Bitmap($crop, (New-Object Drawing.Size(480, 224)))
                try {
                    $rankPath = Join-Path $script:captureDir ('rank_start_{0}.png' -f (Get-Date -Format 'yyyyMMdd_HHmmss_fff'))
                    $enlarged.Save($rankPath, [Drawing.Imaging.ImageFormat]::Png)
                } finally { $enlarged.Dispose() }
            } finally { $crop.Dispose() }
        } finally { $normalized.Dispose() }
    } finally { $bitmap.Dispose() }

    Initialize-RankOcr
    $file = Await-RankOcr ([Windows.Storage.StorageFile]::GetFileFromPathAsync($rankPath)) ([Windows.Storage.StorageFile])
    $stream = Await-RankOcr ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
    try {
        $decoder = Await-RankOcr ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
        $softwareBitmap = Await-RankOcr ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
        try {
            $ocr = Await-RankOcr ($script:rankOcrEngine.RecognizeAsync($softwareBitmap)) ([Windows.Media.Ocr.OcrResult])
        } finally { if ($null -ne $softwareBitmap) { $softwareBitmap.Dispose() } }
    } finally { if ($null -ne $stream) { $stream.Dispose() } }
    $matches = [regex]::Matches($ocr.Text, '(?<!\d)(?:\d,\d{3}|\d{4})(?!\d)')
    if ($matches.Count -ne 1) {
        return [PSCustomObject]@{ Found = $false; Points = 0; Reason = "시작점수 숫자 인식 실패: $($ocr.Text)" }
    }
    $points = [int]($matches[0].Value -replace ',', '')
    if ($points -lt 1000 -or $points -gt 9999) {
        return [PSCustomObject]@{ Found = $false; Points = 0; Reason = '챔피언스 점수 범위를 벗어났습니다.' }
    }
    return [PSCustomObject]@{ Found = $true; Points = $points; Reason = '확인' }
}

function Invoke-KeyTap([System.UInt16]$scanCode, [int]$holdMilliseconds = 65) {
    if (-not [FCNative]::SendScanCode($scanCode, $false)) {
        throw "키 누르기 입력에 실패했습니다. Windows 오류: $([FCNative]::LastInputError)"
    }
    Start-Sleep -Milliseconds ([Math]::Max(50, $holdMilliseconds))
    if (-not [FCNative]::SendScanCode($scanCode, $true)) {
        throw "키 떼기 입력에 실패했습니다. Windows 오류: $([FCNative]::LastInputError)"
    }
}

function Invoke-ReliableSTap {
    # FC occasionally ignores a very short scan-code-only S press on SKIP
    # screens. Hold it longer, then send one virtual-key S pulse as a fallback.
    Invoke-KeyTap 0x1F 140
    Start-Sleep -Milliseconds 80
    if (-not [FCNative]::SendVirtualKey(0x53, $false)) {
        throw "S 보강 입력 누르기에 실패했습니다. Windows 오류: $([FCNative]::LastInputError)"
    }
    Start-Sleep -Milliseconds 100
    if (-not [FCNative]::SendVirtualKey(0x53, $true)) {
        throw "S 보강 입력 떼기에 실패했습니다. Windows 오류: $([FCNative]::LastInputError)"
    }
}

function Find-TemplateAction($frame) {
    # Uniform confirmation is checked first because the same screen also
    # contains the opponent's '준비 완료' indicator.
    # ESC is allowed only when both the bottom-right key icon and its adjacent
    # SKIP caption are present. A lone ESC icon may open the settings menu.
    $priority = @("tier_popup.png", "tier_result.png", "space_2.png", "space_1.png", "space_3.png", "click_1.png", "click_2.png",
                  "click_3.png", "click_4.png", "skip.png", "s.png", "esc.png", "client.png")

    foreach ($fileName in $priority) {
        $lowTemplate = $script:templates | Where-Object { $_.Definition.File -eq $fileName } | Select-Object -First 1
        if ($null -eq $lowTemplate) { continue }

        $definition = $lowTemplate.Definition
        if ($fileName -eq "tier_popup.png" -and -not [FCRewardLabels]::IsTierPopup($frame.Buffer)) { continue }
        if ($fileName -eq "tier_result.png" -and -not [FCRewardLabels]::IsTierResult($frame.Buffer)) { continue }
        if ($script:lastTemplateActions.ContainsKey($definition.File)) {
            $lastTime = [DateTime]$script:lastTemplateActions[$definition.File]
            if (([DateTime]::Now - $lastTime).TotalMilliseconds -lt $definition.Cooldown) {
                continue
            }
        }

        # Prefer the supplied 2560x1440 source images in scaled environments.
        # They retain the text edges that were lost when the 1280 templates
        # were enlarged and prevent a green uniform screen from looking like
        # the green result-screen 'Next' button.
        $widthScale = [double]$frame.Buffer.Width / 1282.0
        $scaledMode = [Math]::Abs($widthScale - 1.0) -gt 0.08
        $template = $lowTemplate
        $templateSource = "1280"
        $effectiveThreshold = [double]$definition.Threshold

        if ($fileName -like "tier_*") {
            [double[]]$scaleCandidates = @([double]$frame.Buffer.Width / 1296.0)
            if ($scaledMode) { $effectiveThreshold = [double]$definition.ScaledThreshold }
        } elseif ($scaledMode -and $definition.File -ne "click_1.png") {
            $hdTemplate = $script:hdTemplates | Where-Object { $_.Definition.File -eq $fileName } | Select-Object -First 1
            if ($null -ne $hdTemplate) {
                $template = $hdTemplate
                $templateSource = "2560"
                [double[]]$scaleCandidates = @([double]$frame.Buffer.Width / 2560.0)
            } else {
                [double[]]$scaleCandidates = @($widthScale)
            }
            $effectiveThreshold = [double]$definition.ScaledThreshold
        } elseif ($definition.File -eq "click_1.png") {
            # The rank lobby can also be borderless, so keep height and native
            # size as safe fallbacks for this tightly-scoped bottom-right item.
            $heightScale = [double]$frame.Buffer.Height / 752.0
            [double[]]$scaleCandidates = @($widthScale, $heightScale, 1.0)
            if ($scaledMode) { $effectiveThreshold = [double]$definition.ScaledThreshold }
        } else {
            # FHD/QHD does not always produce the exact same outer window
            # size even when FC is set to 1280x720. Windows title bars and
            # borders observed in diagnostics ranged around 1282x752 to
            # 1296x759, so compare the small width/height corrections too.
            $heightScale = [double]$frame.Buffer.Height / 752.0
            [double[]]$scaleCandidates = @($widthScale, $heightScale, 1.0)
        }
        $match = [FCTemplateMatcher]::FindMultiScale(
            $frame.Buffer,
            $template.Buffer,
            $definition.X1,
            $definition.Y1,
            $definition.X2,
            $definition.Y2,
            $effectiveThreshold,
            $scaleCandidates,
            ($fileName -eq "s.png"),
            ($fileName -eq "esc.png")
        )
        if ($match.Found) {
            return [PSCustomObject]@{ Template = $template; Match = $match; Source = $templateSource }
        }
    }
    return $null
}

function Invoke-TemplateAction($recognized, $frame) {
    $definition = $recognized.Template.Definition
    $match = $recognized.Match
    if ($definition.File -eq 'click_1.png' -and $script:parkingMode -and $script:rankResyncRequired) {
        if (-not (Sync-ParkingRank $frame)) { return }
        # The OCR wait may have changed focus; never click another window.
        $verified = Get-ForegroundInfo
        if (-not $verified.Allowed -or $verified.Handle -ne $frame.Handle) { return }
    }
    $actionText = ""
    $stopAfterThisAction = $false

    # Recognition can take long enough for the user to switch windows.
    $foreground = Get-ForegroundInfo
    if ($onlyFcCheck.Checked -and
        (-not $foreground.Allowed -or $foreground.Handle -ne $frame.Handle)) {
        $script:paused = $true
        $script:resumeStableSince = $null
        return
    }

    if ($definition.File -ne "space_3.png" -and $definition.Action -ne "none") {
        $script:resultScreenCounted = $false
    }

    switch ($definition.Action) {
        "click" {
            $matchedWidth = if ($match.MatchWidth -gt 0) { $match.MatchWidth } else { $recognized.Template.Buffer.Width }
            $matchedHeight = if ($match.MatchHeight -gt 0) { $match.MatchHeight } else { $recognized.Template.Buffer.Height }
            $screenX = $frame.Rect.Left + $match.X + [int]($matchedWidth / 2)
            $screenY = $frame.Rect.Top + $match.Y + [int]($matchedHeight / 2)
            if (-not [FCNative]::SendLeftClick($screenX, $screenY)) {
                throw "마우스 클릭 입력에 실패했습니다. Windows 오류: $([FCNative]::LastInputError)"
            }
            if ([FCNative]::LastClickUsedFallback) {
                $actionText = "클릭(호환 입력)"
                Write-Log "기본 마우스 입력이 거부되어 호환 입력으로 다시 시도했습니다."
            } else {
                $actionText = "클릭"
            }
        }
        "space" {
            if ($definition.File -eq "space_3.png") {
                Register-CompletedMatch $frame
                $stopAfterThisAction = $script:stopAfterCurrentMatch
                $infoAfterCapture = Get-ForegroundInfo
                if ($onlyFcCheck.Checked -and
                    (-not $infoAfterCapture.Allowed -or $infoAfterCapture.Handle -ne $frame.Handle)) {
                    $script:paused = $true
                    $script:resumeStableSince = $null
                    $windowLabel.Text = "점수 화면 저장 완료 · FC 창 복귀 대기"
                    Write-Log "점수 화면 저장 중 창이 바뀌어 Space 입력을 안전하게 보류했습니다."
                    return
                }
            }
            Invoke-KeyTap 0x39
            $actionText = "Space"
        }
        "esc" {
            Invoke-KeyTap 0x01
            $actionText = "Esc"
        }
        "s" {
            Invoke-ReliableSTap
            $actionText = "S 보강 입력"
        }
        "none" {
            $actionText = "입력 없음"
        }
    }

    $script:lastTemplateActions[$definition.File] = [DateTime]::Now
    if ($definition.Action -ne "none") {
        Mark-AutomationProgress $definition.File $definition.Label
        $script:actionCount++
        Update-Counters
    }
    $windowLabel.Text = "인식 화면: $($definition.Label) · 동작: $actionText"
    $sourceText = if ([string]::IsNullOrWhiteSpace($recognized.Source)) { "1280" } else { $recognized.Source }
    Write-Log ("화면 인식[{0}]: {1} -> {2} (차이 {3:N1})" -f $sourceText, $definition.File, $actionText, $match.MeanDifference)

    if ($stopAfterThisAction) {
        Stop-Automation "이번 판 완료"
        Set-Status "이번 판 완료 · 자동 진행 중지" ([Drawing.Color]::FromArgb(150, 156, 166))
        $windowLabel.Text = "경기 결과 저장 및 다음 화면 이동 완료"
        Write-Log "예약한 이번 경기를 완료하여 자동 진행을 중지했습니다."
    }
}

function Set-Status([string]$text, [Drawing.Color]$color) {
    $statusLabel.Text = $text
    $statusDot.ForeColor = $color
}

function Update-Counters {
    $counterLabel.Text = "화면 동작: $($script:actionCount)회   |   자동 일시정지: $($script:pauseCount)회"
}

function Start-Automation {
    if ($script:running) { return }
    $script:parkingMode = $parkingModeRadio.Checked
    if ($script:parkingMode) {
        if ($null -eq $script:startingRankPoints -or $null -eq $script:startingRankReadAt -or
            ([DateTime]::Now - $script:startingRankReadAt).TotalMinutes -gt 5) {
            Show-TopmostError '먼저 챔피언스 감독 랭킹 화면에서 시작점수를 읽어 주세요. 인식 후 5분 안에 시작해야 합니다.' '주차 시작점수 미확인'
            return
        }
        if ([int]$targetPointsBox.Value -le [int]$script:startingRankPoints) {
            Show-TopmostError '목표점수는 시작점수보다 커야 합니다.' '주차 목표점수 확인'
            return
        }
        if ($minimumPointsCheck.Checked -and [int]$minimumPointsBox.Value -ge [int]$script:startingRankPoints) {
            Show-TopmostError '최저점수는 시작점수보다 작아야 합니다.' '주차 최저점수 확인'
            return
        }
        $script:currentRankPoints = [int]$script:startingRankPoints
        $script:rankResyncRequired = $false
    }
    $info = Get-ForegroundInfo
    # A rank reading authorizes one run only. After stopping, the game may
    # have advanced, so restarting requires another confirmed reading.
    $script:startingRankReadAt = $null
    $script:running = $true
    $script:paused = $onlyFcCheck.Checked -and -not $info.Allowed
    $script:nextScanDue = [DateTime]::Now.AddMilliseconds(500)
    $script:resumeStableSince = $null
    $script:lastTemplateActions.Clear()
    $script:lastRecognizedFile = ""
    $script:sameScreenActionCount = 0
    $script:sameScreenSince = [DateTime]::Now
    $script:previousVisualFrame = $null
    $script:lastVisualChangeAt = [DateTime]::Now
    $script:lastProgressAt = [DateTime]::Now
    $script:stuckAlertActive = $false
    $script:stopAfterCurrentMatch = $false
    $script:requiredStopAfterMatch = $false
    $startButton.Enabled = $false
    $stopButton.Enabled = $true
    $finishMatchButton.Enabled = $true
    $generalModeRadio.Enabled = $false
    $parkingModeRadio.Enabled = $false
    $readRankButton.Enabled = $false
    $targetPointsBox.Enabled = $false
    $minimumPointsCheck.Enabled = $false
    $minimumPointsBox.Enabled = $false
    $finishMatchButton.Text = "이번 판까지만 (F8)"
    $finishMatchButton.BackColor = [Drawing.Color]::FromArgb(184, 126, 45)
    if ($script:paused) {
        Set-Status "FC 창 대기 중" ([Drawing.Color]::FromArgb(236, 190, 86))
        Write-Log "자동 진행을 준비했습니다. FC ONLINE 창을 선택하면 시작합니다."
    } else {
        Set-Status "화면 인식 중" ([Drawing.Color]::FromArgb(83, 220, 120))
        Write-Log "화면 인식 자동 진행을 시작했습니다."
    }
}

function Stop-Automation([string]$reason) {
    if (-not $script:running) { return }
    # Release all mapped keys defensively.
    [void][FCNative]::SendScanCode(0x39, $true)
    [void][FCNative]::SendScanCode(0x1F, $true)
    [void][FCNative]::SendVirtualKey(0x53, $true)
    [void][FCNative]::SendScanCode(0x01, $true)
    $script:running = $false
    $script:paused = $false
    $script:stopAfterCurrentMatch = $false
    $script:requiredStopAfterMatch = $false
    $startButton.Enabled = $true
    $stopButton.Enabled = $false
    $finishMatchButton.Enabled = $false
    $generalModeRadio.Enabled = $true
    $parkingModeRadio.Enabled = $true
    $readRankButton.Enabled = $parkingModeRadio.Checked
    $targetPointsBox.Enabled = $parkingModeRadio.Checked
    $minimumPointsCheck.Enabled = $parkingModeRadio.Checked
    $minimumPointsBox.Enabled = $parkingModeRadio.Checked -and $minimumPointsCheck.Checked
    $finishMatchButton.Text = "이번 판까지만 (F8)"
    $finishMatchButton.BackColor = [Drawing.Color]::FromArgb(184, 126, 45)
    Set-Status "대기 중" ([Drawing.Color]::FromArgb(150, 156, 166))
    Write-Log "자동 진행을 중지했습니다. ($reason)"
    Save-DiagnosticInfo "자동 진행 중지: $reason"
}

function Toggle-FinishMatchReservation {
    if (-not $script:running) { return }
    if ($script:requiredStopAfterMatch) {
        Write-Log "주차 조건에 따른 중지는 취소할 수 없습니다. 중지 후 시작점수를 다시 읽어 주세요."
        return
    }
    $script:stopAfterCurrentMatch = -not $script:stopAfterCurrentMatch
    if ($script:stopAfterCurrentMatch) {
        $finishMatchButton.Text = "예약 취소 (F8)"
        $finishMatchButton.BackColor = [Drawing.Color]::FromArgb(220, 139, 38)
        Set-Status "경기 종료 후 중지 예약" ([Drawing.Color]::FromArgb(236, 190, 86))
        Write-Log "이번 판 완료 후 자동 진행 중지를 예약했습니다. (버튼/F8)"
    } else {
        $finishMatchButton.Text = "이번 판까지만 (F8)"
        $finishMatchButton.BackColor = [Drawing.Color]::FromArgb(184, 126, 45)
        Set-Status "화면 인식 중" ([Drawing.Color]::FromArgb(83, 220, 120))
        Write-Log "이번 판 완료 후 중지 예약을 취소했습니다. (버튼/F8)"
    }
}

function Save-FCScreenshot {
    $info = Get-FCWindowInfo
    if ($null -eq $info) {
        [System.Windows.Forms.MessageBox]::Show("실행 중인 FC ONLINE 창을 찾지 못했습니다.", "화면 저장") | Out-Null
        return
    }
    $rect = New-Object FCNative+RECT
    if (-not [FCNative]::GetWindowRect($info.Handle, [ref]$rect)) {
        [System.Windows.Forms.MessageBox]::Show("FC ONLINE 창 크기를 확인하지 못했습니다.", "화면 저장") | Out-Null
        return
    }
    $width = $rect.Right - $rect.Left
    $height = $rect.Bottom - $rect.Top
    if ($width -le 0 -or $height -le 0) { return }
    $form.Hide()
    [System.Windows.Forms.Application]::DoEvents()
    Start-Sleep -Milliseconds 300
    $bitmap = New-Object Drawing.Bitmap($width, $height)
    $graphics = [Drawing.Graphics]::FromImage($bitmap)
    try {
        $graphics.CopyFromScreen($rect.Left, $rect.Top, 0, 0, (New-Object Drawing.Size($width, $height)))
        $path = Join-Path $script:captureDir ("FC_{0}.png" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
        $bitmap.Save($path, [Drawing.Imaging.ImageFormat]::Png)
        Write-Log "FC 화면을 저장했습니다: $([IO.Path]::GetFileName($path)) ($($width)x$($height), DPI $script:dpiAwarenessMode)"
        [System.Windows.Forms.MessageBox]::Show("화면을 오류확인용_보내기\\captures 폴더에 저장했습니다.", "화면 저장") | Out-Null
    } finally {
        $graphics.Dispose()
        $bitmap.Dispose()
        $form.Show()
        $form.Activate()
    }
}

function Update-ParkingAppearance {
    $isParking = $parkingModeRadio.Checked
    $form.BackColor = if ($isParking) { [Drawing.Color]::FromArgb(34, 26, 55) } else { [Drawing.Color]::FromArgb(12, 32, 26) }
    $modeGroup.BackColor = if ($isParking) { [Drawing.Color]::FromArgb(64, 36, 99) } else { [Drawing.Color]::FromArgb(12, 48, 35) }
    $readRankButton.Enabled = $isParking -and -not $script:running
    $targetPointsBox.Enabled = $isParking -and -not $script:running
    $minimumPointsCheck.Enabled = $isParking -and -not $script:running
    $minimumPointsBox.Enabled = $isParking -and $minimumPointsCheck.Checked -and -not $script:running
}

$generalModeRadio.Add_CheckedChanged({ Update-ParkingAppearance })
$parkingModeRadio.Add_CheckedChanged({ Update-ParkingAppearance })
$minimumPointsCheck.Add_CheckedChanged({ Update-ParkingAppearance })
$readRankButton.Add_Click({
    try {
        if ($script:running) { return }
        $info = Get-FCWindowInfo
        if ($null -eq $info) { throw 'FC ONLINE 창을 찾지 못했습니다.' }
        $form.Hide()
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 350
        $foreground = Get-ForegroundInfo
        if (-not $foreground.Allowed -or $foreground.Handle -ne $info.Handle) {
            throw 'FC ONLINE 창을 맨 앞에 놓고 챔피언스 감독 랭킹 화면에서 다시 시도해 주세요.'
        }
        $frame = Get-FCFrame $info.Handle
        if ($null -eq $frame) { throw '게임 화면을 캡처하지 못했습니다.' }
        $rank = Read-StartingRankPoints $frame
        if (-not $rank.Found) { throw $rank.Reason }
        Start-Sleep -Milliseconds 350
        $secondFrame = Get-FCFrame $info.Handle
        if ($null -eq $secondFrame) { throw '시작점수 재확인용 화면을 캡처하지 못했습니다.' }
        $secondRank = Read-StartingRankPoints $secondFrame
        if (-not $secondRank.Found -or $secondRank.Points -ne $rank.Points) {
            throw '두 번 읽은 시작점수가 일치하지 않습니다. 랭킹 화면을 다시 확인해 주세요.'
        }
        $script:startingRankPoints = [int]$rank.Points
        $script:currentRankPoints = [int]$rank.Points
        $script:startingRankReadAt = [DateTime]::Now
        $rankPointsLabel.Text = "시작점수: $($rank.Points)점 · 화면에서 인식됨"
        Write-Log "주차 시작점수 화면 인식: $($rank.Points)점"
    } catch {
        $script:startingRankPoints = $null
        $script:startingRankReadAt = $null
        Write-Log "시작점수 인식 실패: $($_.Exception.Message)"
        Show-TopmostError $_.Exception.Message '시작점수 인식 실패'
    } finally {
        $form.Show()
        $form.Activate()
    }
})
Update-ParkingAppearance

$startButton.Add_Click({ Start-Automation })
$stopButton.Add_Click({ Stop-Automation "중지 버튼" })
$finishMatchButton.Add_Click({ Toggle-FinishMatchReservation })
$captureButton.Add_Click({
    try {
        Save-FCScreenshot
    } catch {
        Write-Log "화면 저장 오류: $($_.Exception.Message)"
        Show-TopmostError $_.Exception.Message "FC 화면 저장 오류"
    }
})

$saveWebhookButton.Add_Click({
    try {
        Save-DiscordSettingsFromUi
        [System.Windows.Forms.MessageBox]::Show("Discord 알림 설정을 저장했습니다.", "설정 저장") | Out-Null
    } catch {
        Show-TopmostError $_.Exception.Message "Discord 설정 오류"
    }
})

$testWebhookButton.Add_Click({
    try {
        Save-DiscordSettingsFromUi
        Queue-DiscordNotification "FC 감독모드 테스트 알림" "Discord 직접 알림이 정상적으로 연결되었습니다." $true
        $discordStatus.Text = "테스트 알림 전송 중..."
    } catch {
        Show-TopmostError $_.Exception.Message "Discord 테스트 오류"
    }
})

Add-Type -ReferencedAssemblies "System.Windows.Forms" -TypeDefinition @"
using System;
using System.Threading;
using System.Windows.Forms;
public sealed class FCF8MessageFilter : IMessageFilter
{
    private int pending;
    public bool PreFilterMessage(ref Message message)
    {
        if (message.Msg != 0x0312 || message.WParam.ToInt64() != 0xFC08) return false;
        Interlocked.Increment(ref pending);
        return true;
    }
    public bool ConsumePress() { return Interlocked.Exchange(ref pending, 0) > 0; }
}
"@

$script:f8MessageFilter = New-Object FCF8MessageFilter
[System.Windows.Forms.Application]::AddMessageFilter($script:f8MessageFilter)
$script:f8HotkeyActive = [FCNative]::RegisterHotKey($form.Handle, $script:f8HotkeyId, 0x4000, 0x77)
if (-not $script:f8HotkeyActive) {
    Write-Log "F8 전역 단축키를 등록할 수 없어 키 상태 확인으로 대체합니다. 필요하면 화면 버튼을 사용하세요."
}

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 25
$timer.Add_Tick({
    try {
        Process-DiscordQueue
        $f9Down = (([FCNative]::GetAsyncKeyState(0x78) -band 0x8000) -ne 0)
        $f8Down = if ($script:f8HotkeyActive) {
            $script:f8MessageFilter.ConsumePress()
        } else {
            (([FCNative]::GetAsyncKeyState(0x77) -band 0x8000) -ne 0)
        }
        $f12Down = (([FCNative]::GetAsyncKeyState(0x7B) -band 0x8000) -ne 0)
        if ($f9Down -and -not $script:f9WasDown) { Start-Automation }
        if ($script:f8HotkeyActive) {
            if ($f8Down) { Toggle-FinishMatchReservation }
        } elseif ($f8Down -and -not $script:f8WasDown) {
            Toggle-FinishMatchReservation
        }
        if ($f12Down -and -not $script:f12WasDown) { Stop-Automation "F12" }
        $script:f9WasDown = $f9Down
        $script:f8WasDown = $f8Down
        $script:f12WasDown = $f12Down

        $info = Get-ForegroundInfo
        $shownTitle = if ([string]::IsNullOrWhiteSpace($info.Title)) { $info.Process } else { $info.Title }
        if ([string]::IsNullOrWhiteSpace($shownTitle)) { $shownTitle = "확인 불가" }
        if ($shownTitle.Length -gt 70) { $shownTitle = $shownTitle.Substring(0, 70) + "..." }
        $windowLabel.Text = "현재 창: $shownTitle"

        if (-not $script:running) { return }

        $allowedNow = (-not $onlyFcCheck.Checked) -or $info.Allowed
        if (-not $allowedNow) {
            if (-not $script:paused) {
                $script:paused = $true
                $script:previousVisualFrame = $null
                $script:pauseCount++
                $script:resumeStableSince = $null
                [void][FCNative]::SendScanCode(0x39, $true)
                [void][FCNative]::SendScanCode(0x1F, $true)
                [void][FCNative]::SendVirtualKey(0x53, $true)
                [void][FCNative]::SendScanCode(0x01, $true)
                Update-Counters
                Set-Status "자동 일시정지" ([Drawing.Color]::FromArgb(236, 190, 86))
                Write-Log "다른 창이 선택되어 입력을 멈췄습니다."
            }
            return
        }

        if ($script:paused) {
            if ($null -eq $script:resumeStableSince) {
                $script:resumeStableSince = [DateTime]::Now
                Set-Status "FC 창 복귀 확인 중" ([Drawing.Color]::FromArgb(236, 190, 86))
                return
            }
            if (([DateTime]::Now - $script:resumeStableSince).TotalMilliseconds -lt 1500) { return }
            $script:paused = $false
            $script:previousVisualFrame = $null
            $script:lastVisualChangeAt = [DateTime]::Now
            $script:nextScanDue = [DateTime]::Now.AddMilliseconds(300)
            $script:lastTemplateActions.Clear()
            Set-Status "화면 인식 중" ([Drawing.Color]::FromArgb(83, 220, 120))
            Write-Log "FC ONLINE 창으로 돌아와 화면 인식을 재개합니다."
        }

        if ([DateTime]::Now -lt $script:nextScanDue) { return }
        $script:nextScanDue = [DateTime]::Now.AddMilliseconds(650)

        $frame = Get-FCFrame $info.Handle
        if ($null -eq $frame) {
            Set-Status "FC 화면 캡처 대기" ([Drawing.Color]::FromArgb(236, 190, 86))
            return
        }

        if ($null -ne $script:previousVisualFrame) {
            if ([FCTemplateMatcher]::VisualChangeFraction($script:previousVisualFrame, $frame.Buffer) -ge 0.01) {
                $script:lastVisualChangeAt = [DateTime]::Now
            }
        } else {
            $script:lastVisualChangeAt = [DateTime]::Now
        }
        $script:previousVisualFrame = $frame.Buffer

        $recognized = Find-TemplateAction $frame
        if ($null -ne $recognized) {
            Invoke-TemplateAction $recognized $frame
            if ($script:running) {
                Set-Status "화면 인식 작동 중" ([Drawing.Color]::FromArgb(83, 220, 120))
            }
        } else {
            Set-Status "등록 화면 대기 중" ([Drawing.Color]::FromArgb(120, 180, 235))
            if (([DateTime]::Now - $script:lastProgressAt).TotalMinutes -ge 20) {
                Send-StuckAlert "자동 진행 중 20분 동안 다음 조작 화면을 인식하지 못했습니다."
            }
        }
    } catch {
        $message = $_.Exception.Message
        Queue-DiscordNotification "FC 감독모드 프로그램 오류" "자동 진행이 오류로 중지되었습니다: $message`n$(Get-MatchSummary)"
        Stop-Automation "오류"
        Write-Log "오류: $message"
        Save-DiagnosticInfo "프로그램 오류: $message"
        Show-TopmostError $message
    }
})

$form.Add_FormClosing({
    if ($script:running) { Stop-Automation "프로그램 종료" }
    $timer.Stop()
    if ($script:f8HotkeyActive) {
        [void][FCNative]::UnregisterHotKey($form.Handle, $script:f8HotkeyId)
    }
    [System.Windows.Forms.Application]::RemoveMessageFilter($script:f8MessageFilter)
    if ($null -ne $script:httpClient) { $script:httpClient.Dispose() }
})

Load-DiscordSettings
Load-MatchStats
Write-Log "Windows DPI 인식 모드: $script:dpiAwarenessMode"
Write-Log "프로그램을 실행했습니다. FC ONLINE 창을 선택한 뒤 F9를 눌러주세요."
Save-DiagnosticInfo "프로그램 시작"
$timer.Start()
[void]$form.ShowDialog()
