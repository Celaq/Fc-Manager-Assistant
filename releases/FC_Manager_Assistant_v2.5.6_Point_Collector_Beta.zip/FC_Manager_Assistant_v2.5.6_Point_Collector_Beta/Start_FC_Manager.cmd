@echo off
setlocal
cd /d "%~dp0"

powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command "try { $p = Join-Path (Get-Location) 'FCManager.ps1'; $s = [IO.File]::ReadAllText($p, [Text.UTF8Encoding]::new($false)); & ([ScriptBlock]::Create($s)) } catch { $e = $_.Exception.ToString(); try { $dn = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('7Jik66WY7ZmV7J247JqpX+uztOuCtOq4sA==')); $d = Join-Path (Get-Location) $dn; [IO.Directory]::CreateDirectory($d) | Out-Null; $ep = Join-Path $d ('startup_error_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.txt'); [IO.File]::WriteAllText($ep, $e, [Text.UTF8Encoding]::new($true)) } catch {}; try { $w = New-Object -ComObject WScript.Shell; [void]$w.Popup($e, 0, 'FC Manager Assistant', 4112) } catch { Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show($e, 'FC Manager Assistant') | Out-Null }; exit 1 }"

endlocal
