$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Net.Http

Add-Type @"
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

public static class FCNative
{
    [StructLayout(LayoutKind.Sequential)]
    public struct INPUT
    {
        public uint type;
        public InputUnion U;
    }

    [StructLayout(LayoutKind.Explicit)]
    public struct InputUnion
    {
        [FieldOffset(0)] public KEYBDINPUT ki;
        [FieldOffset(0)] public MOUSEINPUT mi;
        [FieldOffset(0)] public HARDWAREINPUT hi;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct KEYBDINPUT
    {
        public ushort wVk;
        public ushort wScan;
        public uint dwFlags;
        public uint time;
        public UIntPtr dwExtraInfo;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct MOUSEINPUT
    {
        public int dx;
        public int dy;
        public uint mouseData;
        public uint dwFlags;
        public uint time;
        public UIntPtr dwExtraInfo;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct HARDWAREINPUT
    {
        public uint uMsg;
        public ushort wParamL;
        public ushort wParamH;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct RECT
    {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct POINT
    {
        public int X;
        public int Y;
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

    public static int LastInputError { get; private set; }

    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);

    [DllImport("user32.dll")]
    public static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);

    [DllImport("user32.dll")]
    public static extern short GetAsyncKeyState(int virtualKey);

    [DllImport("user32.dll")]
    private static extern bool GetCursorPos(out POINT point);

    [DllImport("user32.dll")]
    private static extern bool SetCursorPos(int x, int y);

    public static bool SendScanCode(ushort scanCode, bool keyUp)
    {
        const uint INPUT_KEYBOARD = 1;
        const uint KEYEVENTF_KEYUP = 0x0002;
        const uint KEYEVENTF_SCANCODE = 0x0008;

        INPUT input = new INPUT();
        input.type = INPUT_KEYBOARD;
        input.U.ki.wVk = 0;
        input.U.ki.wScan = scanCode;
        input.U.ki.dwFlags = KEYEVENTF_SCANCODE | (keyUp ? KEYEVENTF_KEYUP : 0);
        input.U.ki.time = 0;
        input.U.ki.dwExtraInfo = UIntPtr.Zero;
        uint sent = SendInput(1, new INPUT[] { input }, Marshal.SizeOf(typeof(INPUT)));
        LastInputError = sent == 1 ? 0 : Marshal.GetLastWin32Error();
        return sent == 1;
    }

    public static bool SendLeftClick(int screenX, int screenY)
    {
        const uint INPUT_MOUSE = 0;
        const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
        const uint MOUSEEVENTF_LEFTUP = 0x0004;

        POINT oldPoint;
        bool haveOldPoint = GetCursorPos(out oldPoint);
        if (!SetCursorPos(screenX, screenY)) return false;

        INPUT down = new INPUT();
        down.type = INPUT_MOUSE;
        down.U.mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
        INPUT up = new INPUT();
        up.type = INPUT_MOUSE;
        up.U.mi.dwFlags = MOUSEEVENTF_LEFTUP;

        uint sent = SendInput(2, new INPUT[] { down, up }, Marshal.SizeOf(typeof(INPUT)));
        LastInputError = sent == 2 ? 0 : Marshal.GetLastWin32Error();
        if (haveOldPoint) SetCursorPos(oldPoint.X, oldPoint.Y);
        return sent == 2;
    }

    public static string GetTitle(IntPtr hWnd)
    {
        StringBuilder builder = new StringBuilder(512);
        GetWindowText(hWnd, builder, builder.Capacity);
        return builder.ToString();
    }

    public static string GetProcessName(IntPtr hWnd)
    {
        uint pid;
        GetWindowThreadProcessId(hWnd, out pid);
        if (pid == 0) return "";
        try { return Process.GetProcessById((int)pid).ProcessName; }
        catch { return ""; }
    }
}
"@

Add-Type -ReferencedAssemblies "System.Drawing" -TypeDefinition @"
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Collections.Generic;

public sealed class FCPixelBuffer
{
    public int Width;
    public int Height;
    public int Stride;
    public byte[] Data;
}

public sealed class FCTemplateResult
{
    public bool Found;
    public int X;
    public int Y;
    public double MeanDifference;
}

public sealed class FCScoreResult
{
    public bool Found;
    public int LeftScore;
    public int RightScore;
    public double Confidence;
    public string Reason;
}

public static class FCTemplateMatcher
{
    public static FCPixelBuffer FromBitmap(Bitmap source)
    {
        Bitmap converted = new Bitmap(source.Width, source.Height, PixelFormat.Format32bppArgb);
        using (Graphics graphics = Graphics.FromImage(converted))
        {
            graphics.DrawImage(source, 0, 0, source.Width, source.Height);
        }

        Rectangle rect = new Rectangle(0, 0, converted.Width, converted.Height);
        BitmapData data = converted.LockBits(rect, ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        try
        {
            int byteCount = Math.Abs(data.Stride) * data.Height;
            byte[] bytes = new byte[byteCount];
            Marshal.Copy(data.Scan0, bytes, 0, byteCount);
            return new FCPixelBuffer {
                Width = converted.Width,
                Height = converted.Height,
                Stride = Math.Abs(data.Stride),
                Data = bytes
            };
        }
        finally
        {
            converted.UnlockBits(data);
            converted.Dispose();
        }
    }

    public static Bitmap ToBitmap(FCPixelBuffer source)
    {
        if (source == null) return null;
        Bitmap bitmap = new Bitmap(source.Width, source.Height, PixelFormat.Format32bppArgb);
        Rectangle rect = new Rectangle(0, 0, bitmap.Width, bitmap.Height);
        BitmapData data = bitmap.LockBits(rect, ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
        try
        {
            int targetStride = Math.Abs(data.Stride);
            if (targetStride == source.Stride)
            {
                Marshal.Copy(source.Data, 0, data.Scan0, Math.Min(source.Data.Length, targetStride * source.Height));
            }
            else
            {
                for (int y = 0; y < source.Height; y++)
                {
                    IntPtr row = new IntPtr(data.Scan0.ToInt64() + (long)y * targetStride);
                    Marshal.Copy(source.Data, y * source.Stride, row, Math.Min(source.Stride, targetStride));
                }
            }
        }
        finally
        {
            bitmap.UnlockBits(data);
        }
        return bitmap;
    }

    private static long DifferenceAt(FCPixelBuffer screen, FCPixelBuffer template,
        int left, int top, int stepX, int stepY, long stopAt, out int sampleChannels)
    {
        long difference = 0;
        sampleChannels = 0;
        for (int ty = 0; ty < template.Height; ty += stepY)
        {
            int screenRow = (top + ty) * screen.Stride;
            int templateRow = ty * template.Stride;
            for (int tx = 0; tx < template.Width; tx += stepX)
            {
                int si = screenRow + (left + tx) * 4;
                int ti = templateRow + tx * 4;
                difference += Math.Abs(screen.Data[si] - template.Data[ti]);
                difference += Math.Abs(screen.Data[si + 1] - template.Data[ti + 1]);
                difference += Math.Abs(screen.Data[si + 2] - template.Data[ti + 2]);
                sampleChannels += 3;
                if (difference > stopAt) return difference;
            }
        }
        return difference;
    }

    public static FCTemplateResult Find(FCPixelBuffer screen, FCPixelBuffer template,
        double x1, double y1, double x2, double y2, double maximumMeanDifference)
    {
        FCTemplateResult result = new FCTemplateResult { Found = false, MeanDifference = 999.0 };
        if (screen == null || template == null || template.Width > screen.Width || template.Height > screen.Height)
            return result;

        int minX = Math.Max(0, (int)Math.Floor(screen.Width * x1));
        int minY = Math.Max(0, (int)Math.Floor(screen.Height * y1));
        int maxX = Math.Min(screen.Width - template.Width, (int)Math.Ceiling(screen.Width * x2) - template.Width);
        int maxY = Math.Min(screen.Height - template.Height, (int)Math.Ceiling(screen.Height * y2) - template.Height);
        if (maxX < minX || maxY < minY) return result;

        int sampleStepX = Math.Max(2, template.Width / 12);
        int sampleStepY = Math.Max(2, template.Height / 6);
        int sampleColumns = (template.Width + sampleStepX - 1) / sampleStepX;
        int sampleRows = (template.Height + sampleStepY - 1) / sampleStepY;
        // Coarse candidates may be one pixel away from the true location.
        // Use a wider coarse allowance, then enforce the requested threshold
        // after the one-pixel refinement pass.
        long allowed = (long)Math.Ceiling(maximumMeanDifference * 2.5 * sampleColumns * sampleRows * 3.0);
        long best = allowed;
        int bestX = -1, bestY = -1;

        for (int y = minY; y <= maxY; y += 2)
        {
            for (int x = minX; x <= maxX; x += 2)
            {
                int channels;
                long value = DifferenceAt(screen, template, x, y, sampleStepX, sampleStepY, best, out channels);
                if (value < best)
                {
                    best = value;
                    bestX = x;
                    bestY = y;
                }
            }
        }

        if (bestX < 0) return result;

        int refineMinX = Math.Max(minX, bestX - 3);
        int refineMaxX = Math.Min(maxX, bestX + 3);
        int refineMinY = Math.Max(minY, bestY - 3);
        int refineMaxY = Math.Min(maxY, bestY + 3);
        for (int y = refineMinY; y <= refineMaxY; y++)
        {
            for (int x = refineMinX; x <= refineMaxX; x++)
            {
                int channels;
                long value = DifferenceAt(screen, template, x, y, sampleStepX, sampleStepY, best, out channels);
                if (value < best)
                {
                    best = value;
                    bestX = x;
                    bestY = y;
                }
            }
        }

        int finalChannels;
        long finalDifference = DifferenceAt(screen, template, bestX, bestY, 2, 2, long.MaxValue, out finalChannels);
        double finalMean = finalChannels > 0 ? finalDifference / (double)finalChannels : 999.0;
        result.Found = finalMean <= maximumMeanDifference;
        result.X = bestX;
        result.Y = bestY;
        result.MeanDifference = finalMean;
        return result;
    }
}

public static class FCScoreReader
{
    private const int NormalWidth = 28;
    private const int NormalHeight = 56;
    private static readonly string[] EncodedTemplates = new string[] {
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH//4A///wH/n/gf4H+D/AP8P8A/w/gB/D+AH8P4Afw/gB/D+AH8P4Afw/gB/H+AH+f4Af5/gB/n+AH+f4Af5/gB/n+AH+f4Af5/gB/n+AH+f4Af4/gB/D+AH8P4Afw/gB/D+AH8P4Afw/wD/D/gP8H+B/gf+f+A///wB//+AH//4Af//gAf/4AB//gAAfgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
        "AAAAAAA/+AAH/4AA//gAf/+B///4H///gf//+B///4H///gf//+B///4H///gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAA/+AAD/4AAP/gAAAAA==",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP//8B///4P///w/8P/D/AP8P8A/w/gB/j+AH+P4Af5/gB/n+AH+P4Af4AAD/AAAP8AAA/wAAH/AAA/8AAH/gAAf+AAH/gAA/+AAH/4AA/+AAH/4AB/8AAH/wAA/+AAH/gAAf+AAD/gAAf+AAD/wAAP8AAA////j///+P///5////n///+f///5////n///+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAD///Af//+D/5/4P+D/w/wD/D/AP8P4A/w/gD/D+AP8PwA/wAAD/AAAP8AAB/gAAP+AAB/wAB/+AAH/wAAf/gAB//AAH/8AAf/8AAf/wAAP/AAAP+AAA/4AAB/gAAH+fwAf5/AB/n8AH+f4Af5/gD/j+AP8P8A/w/4H/D/5/8P///gf//8A///wB//+AD//wAH/+AAD/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/gAB/+AAH/4AA//gAH/+AAfv4AB8/gAHz+AA/P4AH4/gAfj+AB8P4APw/gB+D+AH4P4AfA/gD4D+APgP4B+A/gP4D+A/AP4D4B/gfgH+B////n///+f///5////n///+f///5////gAB/gAAH+AAAf4AAB/gAAH+AAAf4AAB/gAAH+AAAf4AAB/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAD///wP///A///8D///wPwAAA/AAAD8AAAfwAAB/AAAH8AAAfgAAB+HwAH7/4Af//4D///gP///A///+D///8P/n/w/wP/D/AP8H4A/4AAD/gAAH+AAAf4AAB/gAAH+AAAf4AAB/n+AH+f4Af5/gD/H/AP8P8A/w/4P/D/5/8H///gf//8A///gB//8AD//gAH/+AAD+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAB///gP///A/5/8H/A/wf4D/D/AP8P8Afw/wAAD/AAAP4AAA/gAAD+AAAf5/4B/v/wH+//gf///B///+H///8f///x/+f/H/AP8f8A/5/wB/n+AH+f4Af5/gA/j+AD+P4AP4/gA/j+AD+P4Af4/wB/j/AP8P8A/wf8H/B/5/8D///gH//8Af//wA//+AB//wAD/+AAB/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH///+f///5////n///+AAAfwAAD+AAAfwAAD+AAAP4AAB/gAAH8AAA/gAAD+AAAf4AAB/AAAP4AAA/gAAD+AAAfwAAB/AAAP4AAB/gAAH8AAAfwAAB/AAAP8AAA/wAAD/AAAf4AAB/gAAH+AAAfwAAB/AAAH8AAAfwAAB/AAAP8AAA/wAAD/AAAP8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP//8B///4H/n/g/4H/D/AP8P8A/w/gB/D+AH8P4Afw/gD/D/AP4H+B/gf8P8A///gB//+AD//gAP//AB///AP//+B///8P/D/w/4H/D+AP8P4Af5/gB/n+AH+f4Af5/gB/n+AH+f4Af4/gB/D/AP8P+B/w/+f/D///4D///AP//4Af//gA//4AB//gAA/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP//4B///wP///A/wH+D/AP4P4A/w/gB/H+AH8f4Afx/gB/H+AH8f4Afx/gB/H+AH8f4Af4/gD/j/Af+P/H/4////h///+D///4H///gf//8Af/fwAfx/AAAH8AAAfwAAB/AAAH8P4A/w/gD+D/Af4P8D/A/8/8B///gD//+AH//wAf/+AA//wAB/+AAA/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=="
    };
    private static readonly bool[][] Templates = DecodeTemplates();

    private static bool[][] DecodeTemplates()
    {
        bool[][] result = new bool[10][];
        for (int d = 0; d < 10; d++)
        {
            byte[] packed = Convert.FromBase64String(EncodedTemplates[d]);
            result[d] = new bool[NormalWidth * NormalHeight];
            for (int i = 0; i < result[d].Length; i++)
                result[d][i] = (packed[i / 8] & (1 << (7 - (i % 8)))) != 0;
        }
        return result;
    }

    private sealed class DigitResult
    {
        public bool Found;
        public int Digit;
        public double Difference;
        public double Gap;
        public string Reason;
    }

    private static DigitResult ReadDigit(FCPixelBuffer screen, double x1, double x2)
    {
        int left = Math.Max(0, (int)(screen.Width * x1));
        int right = Math.Min(screen.Width, (int)(screen.Width * x2));
        int top = Math.Max(0, (int)(screen.Height * 0.11));
        int bottom = Math.Min(screen.Height, (int)(screen.Height * 0.26));
        int width = right - left;
        int height = bottom - top;
        if (width <= 0 || height <= 0)
            return new DigitResult { Found = false, Reason = "점수 영역 없음" };

        int maximum = 0;
        for (int y = top; y < bottom; y++)
        {
            int row = y * screen.Stride;
            for (int x = left; x < right; x++)
            {
                int i = row + x * 4;
                int b = screen.Data[i], g = screen.Data[i + 1], r = screen.Data[i + 2];
                int lum = (r + g + b) / 3;
                if (lum > maximum) maximum = lum;
            }
        }
        if (maximum < 55)
            return new DigitResult { Found = false, Reason = "점수 표시 전환 중" };

        int threshold = Math.Max(38, (int)(maximum * 0.62));
        bool[] mask = new bool[width * height];
        for (int y = 0; y < height; y++)
        {
            int row = (top + y) * screen.Stride;
            for (int x = 0; x < width; x++)
            {
                int i = row + (left + x) * 4;
                int b = screen.Data[i], g = screen.Data[i + 1], r = screen.Data[i + 2];
                int lum = (r + g + b) / 3;
                int hi = Math.Max(r, Math.Max(g, b));
                int lo = Math.Min(r, Math.Min(g, b));
                mask[y * width + x] = lum > threshold && (hi - lo) < 50;
            }
        }

        bool[] visited = new bool[mask.Length];
        List<int> bestPixels = null;
        double bestComponentScore = -1;
        int[] queue = new int[mask.Length];
        int minimumHeight = Math.Max(35, (int)(screen.Height * 0.055));
        int maximumHeight = Math.Max(minimumHeight, (int)(screen.Height * 0.12));
        int minimumWidth = Math.Max(8, (int)(screen.Width * 0.008));
        int maximumWidth = Math.Max(minimumWidth, (int)(screen.Width * 0.06));

        for (int start = 0; start < mask.Length; start++)
        {
            if (!mask[start] || visited[start]) continue;
            int head = 0, tail = 0;
            queue[tail++] = start;
            visited[start] = true;
            List<int> pixels = new List<int>();
            int minX = width, maxX = 0, minY = height, maxY = 0;
            while (head < tail)
            {
                int p = queue[head++];
                pixels.Add(p);
                int px = p % width, py = p / width;
                if (px < minX) minX = px; if (px > maxX) maxX = px;
                if (py < minY) minY = py; if (py > maxY) maxY = py;
                int next;
                if (px > 0) { next = p - 1; if (mask[next] && !visited[next]) { visited[next] = true; queue[tail++] = next; } }
                if (px + 1 < width) { next = p + 1; if (mask[next] && !visited[next]) { visited[next] = true; queue[tail++] = next; } }
                if (py > 0) { next = p - width; if (mask[next] && !visited[next]) { visited[next] = true; queue[tail++] = next; } }
                if (py + 1 < height) { next = p + width; if (mask[next] && !visited[next]) { visited[next] = true; queue[tail++] = next; } }
            }

            int componentWidth = maxX - minX + 1;
            int componentHeight = maxY - minY + 1;
            if (pixels.Count < 80 || componentHeight < minimumHeight || componentHeight > maximumHeight ||
                componentWidth < minimumWidth || componentWidth > maximumWidth) continue;
            double componentScore = componentHeight * 10.0 + pixels.Count;
            if (componentScore > bestComponentScore)
            {
                bestComponentScore = componentScore;
                bestPixels = pixels;
            }
        }

        if (bestPixels == null)
            return new DigitResult { Found = false, Reason = "점수 숫자 없음" };

        int bx0 = width, bx1 = 0, by0 = height, by1 = 0;
        bool[] componentMask = new bool[mask.Length];
        foreach (int p in bestPixels)
        {
            componentMask[p] = true;
            int px = p % width, py = p / width;
            if (px < bx0) bx0 = px; if (px > bx1) bx1 = px;
            if (py < by0) by0 = py; if (py > by1) by1 = py;
        }
        int bw = bx1 - bx0 + 1, bh = by1 - by0 + 1;
        double scale = Math.Min((NormalWidth - 2.0) / bw, (NormalHeight - 2.0) / bh);
        int scaledWidth = Math.Max(1, (int)Math.Round(bw * scale));
        int scaledHeight = Math.Max(1, (int)Math.Round(bh * scale));
        int offsetX = (NormalWidth - scaledWidth) / 2;
        int offsetY = (NormalHeight - scaledHeight) / 2;
        bool[] normalized = new bool[NormalWidth * NormalHeight];
        for (int y = 0; y < scaledHeight; y++)
        {
            int sourceY = Math.Min(bh - 1, (int)((double)y * bh / scaledHeight));
            for (int x = 0; x < scaledWidth; x++)
            {
                int sourceX = Math.Min(bw - 1, (int)((double)x * bw / scaledWidth));
                normalized[(offsetY + y) * NormalWidth + offsetX + x] = componentMask[(by0 + sourceY) * width + bx0 + sourceX];
            }
        }

        int bestDigit = -1;
        double bestDifference = 1.0, secondDifference = 1.0;
        for (int digit = 0; digit < 10; digit++)
        {
            int mismatch = 0;
            for (int i = 0; i < normalized.Length; i++)
                if (normalized[i] != Templates[digit][i]) mismatch++;
            double difference = mismatch / (double)normalized.Length;
            if (difference < bestDifference)
            {
                secondDifference = bestDifference;
                bestDifference = difference;
                bestDigit = digit;
            }
            else if (difference < secondDifference)
            {
                secondDifference = difference;
            }
        }

        double gap = secondDifference - bestDifference;
        bool accepted = bestDifference <= 0.31 && gap >= 0.025;
        return new DigitResult {
            Found = accepted,
            Digit = bestDigit,
            Difference = bestDifference,
            Gap = gap,
            Reason = accepted ? "확인" : "숫자 신뢰도 부족"
        };
    }

    public static FCScoreResult Read(FCPixelBuffer screen)
    {
        if (screen == null)
            return new FCScoreResult { Found = false, Reason = "화면 없음" };
        DigitResult left = ReadDigit(screen, 0.40, 0.50);
        DigitResult right = ReadDigit(screen, 0.50, 0.59);
        if (!left.Found || !right.Found)
            return new FCScoreResult { Found = false, Reason = left.Found ? right.Reason : left.Reason };
        double confidence = 1.0 - Math.Max(left.Difference, right.Difference);
        return new FCScoreResult {
            Found = true,
            LeftScore = left.Digit,
            RightScore = right.Digit,
            Confidence = confidence,
            Reason = "확인"
        };
    }
}
"@

[System.Windows.Forms.Application]::EnableVisualStyles()

# When this file is loaded through the UTF-8 launcher it runs as an in-memory
# script block, so PSScriptRoot can be empty on Windows PowerShell 5.1.
$script:appDir = if ([string]::IsNullOrWhiteSpace($PSScriptRoot)) {
    (Get-Location).Path
} else {
    $PSScriptRoot
}
$script:diagnosticDir = Join-Path $script:appDir "오류확인용_보내기"
$script:logDir = Join-Path $script:diagnosticDir "logs"
$script:captureDir = Join-Path $script:diagnosticDir "captures"
$script:resultSampleDir = Join-Path $script:diagnosticDir "result_samples"
$script:pointSampleDir = Join-Path $script:diagnosticDir "point_samples"
$script:pointSampleFullDir = Join-Path $script:pointSampleDir "full"
$script:pointSampleRoiDir = Join-Path $script:pointSampleDir "score_area"
[IO.Directory]::CreateDirectory($script:diagnosticDir) | Out-Null
[IO.Directory]::CreateDirectory($script:logDir) | Out-Null
[IO.Directory]::CreateDirectory($script:captureDir) | Out-Null
[IO.Directory]::CreateDirectory($script:resultSampleDir) | Out-Null
[IO.Directory]::CreateDirectory($script:pointSampleDir) | Out-Null
[IO.Directory]::CreateDirectory($script:pointSampleFullDir) | Out-Null
[IO.Directory]::CreateDirectory($script:pointSampleRoiDir) | Out-Null
$script:logPath = Join-Path $script:logDir ("FCManager_{0}.log" -f (Get-Date -Format "yyyyMMdd"))
$script:templateDir = Join-Path $script:appDir "templates"
$script:settingsPath = Join-Path $script:appDir "settings.json"
$script:statsPath = Join-Path $script:appDir "stats.json"

$script:running = $false
$script:paused = $false
$script:actionCount = 0
$script:pauseCount = 0
$script:nextScanDue = [DateTime]::Now
$script:resumeStableSince = $null
$script:f9WasDown = $false
$script:f10WasDown = $false
$script:f12WasDown = $false
$script:lastTemplateActions = @{}
$script:lastRecognitionLogAt = [DateTime]::MinValue
$script:templates = New-Object System.Collections.ArrayList
$script:lastRecognizedFile = ""
$script:sameScreenActionCount = 0
$script:sameScreenSince = [DateTime]::Now
$script:lastProgressAt = [DateTime]::Now
$script:stuckAlertActive = $false
$script:lastStuckAlertAt = [DateTime]::MinValue
$script:notificationQueue = New-Object System.Collections.Queue
$script:activeNotification = $null
$script:httpClient = New-Object System.Net.Http.HttpClient
$script:httpClient.Timeout = [TimeSpan]::FromSeconds(10)
$script:discordEnabled = $false
$script:encryptedWebhook = ""
$script:sessionMatchCount = 0
$script:todayMatchCount = 0
$script:totalMatchCount = 0
$script:sessionWinCount = 0
$script:sessionDrawCount = 0
$script:sessionLossCount = 0
$script:sessionUnclassifiedCount = 0
$script:todayWinCount = 0
$script:todayDrawCount = 0
$script:todayLossCount = 0
$script:todayUnclassifiedCount = 0
$script:totalWinCount = 0
$script:totalDrawCount = 0
$script:totalLossCount = 0
$script:totalUnclassifiedCount = 0
$script:statsDate = Get-Date -Format "yyyy-MM-dd"
$script:resultScreenCounted = $false
$script:stopAfterCurrentMatch = $false
$script:pointSampleCount = 0

# Template filenames intentionally define their behavior.
$templateDefinitions = @(
    [PSCustomObject]@{ File = "click_1.png"; Action = "click"; Label = "공식경기"; X1 = 0.60; Y1 = 0.65; X2 = 1.00; Y2 = 1.00; Threshold = 6.0; Cooldown = 1800 },
    [PSCustomObject]@{ File = "click_2.png"; Action = "click"; Label = "확인"; X1 = 0.10; Y1 = 0.30; X2 = 1.00; Y2 = 1.00; Threshold = 6.0; Cooldown = 1800 },
    [PSCustomObject]@{ File = "click_3.png"; Action = "click"; Label = "확인 화살표"; X1 = 0.10; Y1 = 0.30; X2 = 1.00; Y2 = 1.00; Threshold = 6.0; Cooldown = 1800 },
    [PSCustomObject]@{ File = "click_4.png"; Action = "click"; Label = "준비 완료"; X1 = 0.40; Y1 = 0.45; X2 = 0.85; Y2 = 0.80; Threshold = 6.0; Cooldown = 1800 },
    [PSCustomObject]@{ File = "client.png"; Action = "none"; Label = "FC 클라이언트"; X1 = 0.00; Y1 = 0.00; X2 = 0.25; Y2 = 0.25; Threshold = 10.0; Cooldown = 3000 },
    [PSCustomObject]@{ File = "esc.png"; Action = "esc"; Label = "Esc 안내"; X1 = 0.55; Y1 = 0.65; X2 = 1.00; Y2 = 1.00; Threshold = 24.0; Cooldown = 1200 },
    [PSCustomObject]@{ File = "s.png"; Action = "s"; Label = "S 안내"; X1 = 0.45; Y1 = 0.55; X2 = 1.00; Y2 = 1.00; Threshold = 12.0; Cooldown = 900 },
    [PSCustomObject]@{ File = "skip.png"; Action = "s"; Label = "후반 종료 SKIP"; X1 = 0.20; Y1 = 0.60; X2 = 1.00; Y2 = 1.00; Threshold = 16.0; Cooldown = 900 },
    [PSCustomObject]@{ File = "space_1.png"; Action = "space"; Label = "진행"; X1 = 0.60; Y1 = 0.70; X2 = 1.00; Y2 = 1.00; Threshold = 6.0; Cooldown = 1500 },
    [PSCustomObject]@{ File = "space_2.png"; Action = "space"; Label = "선택 완료"; X1 = 0.25; Y1 = 0.50; X2 = 0.65; Y2 = 0.75; Threshold = 6.0; Cooldown = 1500 },
    [PSCustomObject]@{ File = "space_3.png"; Action = "space"; Label = "다음"; X1 = 0.60; Y1 = 0.70; X2 = 1.00; Y2 = 1.00; Threshold = 6.0; Cooldown = 1500 }
)

foreach ($definition in $templateDefinitions) {
    $templatePath = Join-Path $script:templateDir $definition.File
    if (-not [IO.File]::Exists($templatePath)) {
        throw "화면 인식 템플릿을 찾지 못했습니다: $($definition.File)"
    }
    $templateBitmap = New-Object Drawing.Bitmap($templatePath)
    try {
        $buffer = [FCTemplateMatcher]::FromBitmap($templateBitmap)
    } finally {
        $templateBitmap.Dispose()
    }
    [void]$script:templates.Add([PSCustomObject]@{
        Definition = $definition
        Buffer = $buffer
    })
}

$form = New-Object System.Windows.Forms.Form
$form.Text = "FC 온라인 감독모드 도우미 v2.5.1 점수 수집 베타"
$form.ClientSize = New-Object System.Drawing.Size(720, 725)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox = $false
$form.BackColor = [Drawing.Color]::FromArgb(8, 31, 23)
$form.ForeColor = [Drawing.Color]::White
$form.Font = New-Object Drawing.Font("Malgun Gothic", 9)

$title = New-Object System.Windows.Forms.Label
$title.Text = "FC 온라인 감독모드 도우미 v2.5.1 POINT COLLECTOR"
$title.Font = New-Object Drawing.Font("Malgun Gothic", 18, [Drawing.FontStyle]::Bold)
$title.ForeColor = [Drawing.Color]::FromArgb(244, 249, 241)
$title.Location = New-Object Drawing.Point(24, 18)
$title.Size = New-Object Drawing.Size(500, 42)
$form.Controls.Add($title)

$subtitle = New-Object System.Windows.Forms.Label
$subtitle.Text = "MATCH CONTROL  ·  자동 진행을 유지하며 경기별 점수 화면을 안정적으로 수집합니다."
$subtitle.ForeColor = [Drawing.Color]::FromArgb(160, 205, 174)
$subtitle.Location = New-Object Drawing.Point(27, 62)
$subtitle.Size = New-Object Drawing.Size(650, 24)
$form.Controls.Add($subtitle)

$statusPanel = New-Object System.Windows.Forms.Panel
$statusPanel.Location = New-Object Drawing.Point(24, 94)
$statusPanel.Size = New-Object Drawing.Size(672, 94)
$statusPanel.BackColor = [Drawing.Color]::FromArgb(18, 76, 49)
$form.Controls.Add($statusPanel)
$statusPanel.Add_Paint({
    param($sender, $eventArgs)
    $pitchPen = New-Object Drawing.Pen([Drawing.Color]::FromArgb(75, 226, 238, 221), 1)
    try {
        $eventArgs.Graphics.DrawRectangle($pitchPen, 4, 4, $sender.Width - 9, $sender.Height - 9)
        $centerX = [int]($sender.Width / 2)
        $eventArgs.Graphics.DrawLine($pitchPen, $centerX, 4, $centerX, $sender.Height - 5)
        $eventArgs.Graphics.DrawEllipse($pitchPen, $centerX - 22, [int]($sender.Height / 2) - 22, 44, 44)
    } finally {
        $pitchPen.Dispose()
    }
})

$statusDot = New-Object System.Windows.Forms.Label
$statusDot.Text = "●"
$statusDot.Font = New-Object Drawing.Font("Malgun Gothic", 16, [Drawing.FontStyle]::Bold)
$statusDot.ForeColor = [Drawing.Color]::FromArgb(150, 156, 166)
$statusDot.Location = New-Object Drawing.Point(16, 10)
$statusDot.Size = New-Object Drawing.Size(30, 30)
$statusPanel.Controls.Add($statusDot)

$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Text = "대기 중"
$statusLabel.Font = New-Object Drawing.Font("Malgun Gothic", 13, [Drawing.FontStyle]::Bold)
$statusLabel.Location = New-Object Drawing.Point(48, 12)
$statusLabel.Size = New-Object Drawing.Size(330, 30)
$statusPanel.Controls.Add($statusLabel)

$windowLabel = New-Object System.Windows.Forms.Label
$windowLabel.Text = "현재 창: 확인 중"
$windowLabel.ForeColor = [Drawing.Color]::FromArgb(190, 196, 205)
$windowLabel.Location = New-Object Drawing.Point(18, 52)
$windowLabel.Size = New-Object Drawing.Size(620, 24)
$statusPanel.Controls.Add($windowLabel)

$counterLabel = New-Object System.Windows.Forms.Label
$counterLabel.Text = "화면 동작: 0회   |   자동 일시정지: 0회"
$counterLabel.TextAlign = "MiddleRight"
$counterLabel.Location = New-Object Drawing.Point(382, 14)
$counterLabel.Size = New-Object Drawing.Size(270, 28)
$statusPanel.Controls.Add($counterLabel)

$startButton = New-Object System.Windows.Forms.Button
$startButton.Text = "시작  (F9)"
$startButton.Location = New-Object Drawing.Point(24, 204)
$startButton.Size = New-Object Drawing.Size(150, 48)
$startButton.FlatStyle = "Flat"
$startButton.BackColor = [Drawing.Color]::FromArgb(24, 160, 88)
$startButton.ForeColor = [Drawing.Color]::White
$startButton.Font = New-Object Drawing.Font("Malgun Gothic", 11, [Drawing.FontStyle]::Bold)
$form.Controls.Add($startButton)

$stopButton = New-Object System.Windows.Forms.Button
$stopButton.Text = "중지  (F12)"
$stopButton.Location = New-Object Drawing.Point(184, 204)
$stopButton.Size = New-Object Drawing.Size(150, 48)
$stopButton.FlatStyle = "Flat"
$stopButton.BackColor = [Drawing.Color]::FromArgb(184, 55, 62)
$stopButton.ForeColor = [Drawing.Color]::White
$stopButton.Font = New-Object Drawing.Font("Malgun Gothic", 11, [Drawing.FontStyle]::Bold)
$stopButton.Enabled = $false
$form.Controls.Add($stopButton)

$finishMatchButton = New-Object System.Windows.Forms.Button
$finishMatchButton.Text = "이번 판까지만"
$finishMatchButton.Location = New-Object Drawing.Point(344, 204)
$finishMatchButton.Size = New-Object Drawing.Size(172, 48)
$finishMatchButton.FlatStyle = "Flat"
$finishMatchButton.BackColor = [Drawing.Color]::FromArgb(184, 126, 45)
$finishMatchButton.ForeColor = [Drawing.Color]::White
$finishMatchButton.Font = New-Object Drawing.Font("Malgun Gothic", 10, [Drawing.FontStyle]::Bold)
$finishMatchButton.Enabled = $false
$form.Controls.Add($finishMatchButton)

$captureButton = New-Object System.Windows.Forms.Button
$captureButton.Text = "FC 화면 저장"
$captureButton.Location = New-Object Drawing.Point(526, 204)
$captureButton.Size = New-Object Drawing.Size(170, 48)
$captureButton.FlatStyle = "Flat"
$captureButton.BackColor = [Drawing.Color]::FromArgb(35, 100, 72)
$captureButton.ForeColor = [Drawing.Color]::White
$form.Controls.Add($captureButton)

$onlyFcCheck = New-Object System.Windows.Forms.CheckBox
$onlyFcCheck.Text = "FC ONLINE 창에서만 입력 (권장)"
$onlyFcCheck.Checked = $true
$onlyFcCheck.Location = New-Object Drawing.Point(30, 264)
$onlyFcCheck.Size = New-Object Drawing.Size(290, 28)
$form.Controls.Add($onlyFcCheck)

$matchCounterLabel = New-Object System.Windows.Forms.Label
$matchCounterLabel.Text = "이번 실행 0판 · 0승 0무 0패 (미분류 0)`r`n오늘 0판 · 전체 0판"
$matchCounterLabel.ForeColor = [Drawing.Color]::FromArgb(160, 225, 177)
$matchCounterLabel.Font = New-Object Drawing.Font("Malgun Gothic", 9, [Drawing.FontStyle]::Bold)
$matchCounterLabel.Location = New-Object Drawing.Point(24, 292)
$matchCounterLabel.Size = New-Object Drawing.Size(672, 42)
$matchCounterLabel.TextAlign = "MiddleLeft"
$form.Controls.Add($matchCounterLabel)

$discordGroup = New-Object System.Windows.Forms.GroupBox
$discordGroup.Text = "Discord 멈춤 알림"
$discordGroup.Location = New-Object Drawing.Point(24, 340)
$discordGroup.Size = New-Object Drawing.Size(672, 112)
$discordGroup.ForeColor = [Drawing.Color]::White
$discordGroup.BackColor = [Drawing.Color]::FromArgb(12, 48, 35)
$form.Controls.Add($discordGroup)

$webhookLabel = New-Object System.Windows.Forms.Label
$webhookLabel.Text = "웹훅 주소"
$webhookLabel.Location = New-Object Drawing.Point(14, 28)
$webhookLabel.Size = New-Object Drawing.Size(70, 24)
$discordGroup.Controls.Add($webhookLabel)

$webhookBox = New-Object System.Windows.Forms.TextBox
$webhookBox.Location = New-Object Drawing.Point(86, 25)
$webhookBox.Size = New-Object Drawing.Size(392, 24)
$webhookBox.UseSystemPasswordChar = $true
$discordGroup.Controls.Add($webhookBox)

$saveWebhookButton = New-Object System.Windows.Forms.Button
$saveWebhookButton.Text = "저장"
$saveWebhookButton.Location = New-Object Drawing.Point(486, 23)
$saveWebhookButton.Size = New-Object Drawing.Size(78, 29)
$saveWebhookButton.FlatStyle = "Flat"
$saveWebhookButton.BackColor = [Drawing.Color]::FromArgb(35, 100, 72)
$saveWebhookButton.ForeColor = [Drawing.Color]::White
$discordGroup.Controls.Add($saveWebhookButton)

$testWebhookButton = New-Object System.Windows.Forms.Button
$testWebhookButton.Text = "테스트"
$testWebhookButton.Location = New-Object Drawing.Point(572, 23)
$testWebhookButton.Size = New-Object Drawing.Size(82, 29)
$testWebhookButton.FlatStyle = "Flat"
$testWebhookButton.BackColor = [Drawing.Color]::FromArgb(24, 160, 88)
$testWebhookButton.ForeColor = [Drawing.Color]::White
$discordGroup.Controls.Add($testWebhookButton)

$discordCheck = New-Object System.Windows.Forms.CheckBox
$discordCheck.Text = "멈춤·오류·복구 알림 사용"
$discordCheck.Location = New-Object Drawing.Point(18, 64)
$discordCheck.Size = New-Object Drawing.Size(220, 26)
$discordGroup.Controls.Add($discordCheck)

$discordStatus = New-Object System.Windows.Forms.Label
$discordStatus.Text = "웹훅을 입력하고 저장해 주세요."
$discordStatus.ForeColor = [Drawing.Color]::FromArgb(190, 196, 205)
$discordStatus.Location = New-Object Drawing.Point(244, 67)
$discordStatus.Size = New-Object Drawing.Size(410, 24)
$discordStatus.TextAlign = "MiddleRight"
$discordGroup.Controls.Add($discordStatus)

$note = New-Object System.Windows.Forms.Label
$note.Text = "사용법: F9 시작 · F10 이번 판까지만 예약/취소 · F12 즉시 중지"
$note.ForeColor = [Drawing.Color]::FromArgb(236, 190, 86)
$note.Location = New-Object Drawing.Point(27, 464)
$note.Size = New-Object Drawing.Size(665, 26)
$form.Controls.Add($note)

$logBox = New-Object System.Windows.Forms.RichTextBox
$logBox.Location = New-Object Drawing.Point(24, 498)
$logBox.Size = New-Object Drawing.Size(672, 172)
$logBox.ReadOnly = $true
$logBox.BackColor = [Drawing.Color]::FromArgb(5, 22, 16)
$logBox.ForeColor = [Drawing.Color]::FromArgb(210, 231, 216)
$logBox.BorderStyle = "FixedSingle"
$logBox.Font = New-Object Drawing.Font("Consolas", 9)
$form.Controls.Add($logBox)

$footer = New-Object System.Windows.Forms.Label
$footer.Text = "외부 자동 입력은 게임 운영정책에 따라 제한될 수 있습니다. 사용 책임은 사용자에게 있습니다."
$footer.ForeColor = [Drawing.Color]::FromArgb(145, 150, 158)
$footer.Location = New-Object Drawing.Point(27, 686)
$footer.Size = New-Object Drawing.Size(665, 22)
$form.Controls.Add($footer)

function Write-Log([string]$message) {
    $line = "[{0}] {1}" -f (Get-Date -Format "HH:mm:ss"), $message
    $logBox.AppendText($line + [Environment]::NewLine)
    $logBox.SelectionStart = $logBox.TextLength
    $logBox.ScrollToCaret()
    try { Add-Content -LiteralPath $script:logPath -Value $line -Encoding UTF8 } catch {}
}

function Save-DiagnosticInfo([string]$lastEvent) {
    try {
        $bounds = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
        $lines = @(
            "FC 온라인 감독모드 도우미 v2.5.1 점수 수집 베타 진단정보",
            "생성 시각: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')",
            "마지막 상태: $lastEvent",
            "Windows: $([Environment]::OSVersion.VersionString)",
            "PowerShell: $($PSVersionTable.PSVersion.ToString())",
            "주 모니터: $($bounds.Width)x$($bounds.Height)",
            "FC 권장 설정: 1280x720 창모드 / Windows 배율 100%",
            "전적: $(Get-MatchSummary)",
            "",
            "이 폴더에는 Discord 웹훅과 settings.json이 포함되지 않습니다."
        )
        $lines | Set-Content -LiteralPath (Join-Path $script:diagnosticDir "진단정보.txt") -Encoding UTF8
    } catch {}
}

function Update-MatchCounter {
    $matchCounterLabel.Text = "이번 실행 $($script:sessionMatchCount)판 · $($script:sessionWinCount)승 $($script:sessionDrawCount)무 $($script:sessionLossCount)패 (미분류 $($script:sessionUnclassifiedCount))`r`n" +
        "오늘 $($script:todayMatchCount)판 $($script:todayWinCount)승 $($script:todayDrawCount)무 $($script:todayLossCount)패(미분류 $($script:todayUnclassifiedCount)) · 전체 $($script:totalMatchCount)판 · 점수 샘플 $($script:pointSampleCount)장"
}

function Save-MatchStats {
    try {
        $stats = [ordered]@{
            Date = $script:statsDate
            TodayCount = [int]$script:todayMatchCount
            TotalCount = [int]$script:totalMatchCount
            TodayWin = [int]$script:todayWinCount
            TodayDraw = [int]$script:todayDrawCount
            TodayLoss = [int]$script:todayLossCount
            TodayUnclassified = [int]$script:todayUnclassifiedCount
            TotalWin = [int]$script:totalWinCount
            TotalDraw = [int]$script:totalDrawCount
            TotalLoss = [int]$script:totalLossCount
            TotalUnclassified = [int]$script:totalUnclassifiedCount
        }
        $stats | ConvertTo-Json | Set-Content -LiteralPath $script:statsPath -Encoding UTF8
    } catch {
        Write-Log "판수 기록 저장 실패: $($_.Exception.Message)"
    }
}

function Load-MatchStats {
    $today = Get-Date -Format "yyyy-MM-dd"
    $script:statsDate = $today
    if ([IO.File]::Exists($script:statsPath)) {
        try {
            $stats = Get-Content -LiteralPath $script:statsPath -Raw -Encoding UTF8 | ConvertFrom-Json
            $script:totalMatchCount = [Math]::Max(0, [int]$stats.TotalCount)
            $script:totalWinCount = [Math]::Max(0, [int]$stats.TotalWin)
            $script:totalDrawCount = [Math]::Max(0, [int]$stats.TotalDraw)
            $script:totalLossCount = [Math]::Max(0, [int]$stats.TotalLoss)
            $script:totalUnclassifiedCount = [Math]::Max(0, [int]$stats.TotalUnclassified)
            $totalKnown = $script:totalWinCount + $script:totalDrawCount + $script:totalLossCount + $script:totalUnclassifiedCount
            if ($totalKnown -lt $script:totalMatchCount) {
                $script:totalUnclassifiedCount += ($script:totalMatchCount - $totalKnown)
            }
            if ([string]$stats.Date -eq $today) {
                $script:todayMatchCount = [Math]::Max(0, [int]$stats.TodayCount)
                $script:todayWinCount = [Math]::Max(0, [int]$stats.TodayWin)
                $script:todayDrawCount = [Math]::Max(0, [int]$stats.TodayDraw)
                $script:todayLossCount = [Math]::Max(0, [int]$stats.TodayLoss)
                $script:todayUnclassifiedCount = [Math]::Max(0, [int]$stats.TodayUnclassified)
                $todayKnown = $script:todayWinCount + $script:todayDrawCount + $script:todayLossCount + $script:todayUnclassifiedCount
                if ($todayKnown -lt $script:todayMatchCount) {
                    $script:todayUnclassifiedCount += ($script:todayMatchCount - $todayKnown)
                }
            }
        } catch {
            Write-Log "기존 판수 기록을 읽지 못해 새 기록으로 시작합니다."
        }
    }
    Update-MatchCounter
}

function Get-MatchSummary {
    return "이번 실행 $($script:sessionMatchCount)판 ($($script:sessionWinCount)승 $($script:sessionDrawCount)무 $($script:sessionLossCount)패 · 미분류 $($script:sessionUnclassifiedCount)) · 오늘 $($script:todayMatchCount)판 · 전체 $($script:totalMatchCount)판"
}

function Save-ResultSample($frame, [int]$matchNumber, [string]$result, [string]$scoreText) {
    try {
        $bitmap = [FCTemplateMatcher]::ToBitmap($frame.Buffer)
        if ($null -eq $bitmap) { return "" }
        try {
            $fileName = "Result_{0}_match{1:D4}_{2}.png" -f (Get-Date -Format "yyyyMMdd_HHmmss"), $matchNumber, $result
            $path = Join-Path $script:resultSampleDir $fileName
            $bitmap.Save($path, [Drawing.Imaging.ImageFormat]::Png)
        } finally {
            $bitmap.Dispose()
        }

        $indexPath = Join-Path $script:resultSampleDir "samples.csv"
        if (-not [IO.File]::Exists($indexPath)) {
            Add-Content -LiteralPath $indexPath -Value "time,session,today,total,result,file" -Encoding UTF8
        }
        $row = "{0},{1},{2},{3},{4},{5}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $script:sessionMatchCount, $script:todayMatchCount, $script:totalMatchCount, $result, $fileName
        Add-Content -LiteralPath $indexPath -Value $row -Encoding UTF8
        return $fileName
    } catch {
        Write-Log "경기 결과 샘플 저장 실패: $($_.Exception.Message)"
        return ""
    }
}

function Get-SettledResultFrame($initialFrame) {
    # The green '다음' button appears before every reward row has finished
    # fading in. Keep the result screen open long enough to capture the final
    # points row. This also gives the existing win/draw/loss reader a stable
    # scoreboard instead of a transition frame.
    $bestFrame = $initialFrame
    $sameWindow = $true
    Set-Status "경기 결과 화면 안정화 중" ([Drawing.Color]::FromArgb(236, 190, 86))
    for ($attempt = 1; $attempt -le 14; $attempt++) {
        Start-Sleep -Milliseconds 250
        # Do not pump WinForms messages here. A nested timer tick could see
        # the same '다음' button and press Space before sampling is complete.
        $info = Get-ForegroundInfo
        if (-not $info.Allowed -or $info.Handle -ne $initialFrame.Handle) {
            $sameWindow = $false
            break
        }
        $nextFrame = Get-FCFrame $initialFrame.Handle
        if ($null -ne $nextFrame) { $bestFrame = $nextFrame }
    }
    return [PSCustomObject]@{ Frame = $bestFrame; SameWindow = $sameWindow }
}

function Save-PointSample($frame, [int]$matchNumber, [string]$result, [string]$scoreText) {
    try {
        $bitmap = [FCTemplateMatcher]::ToBitmap($frame.Buffer)
        if ($null -eq $bitmap) { return "" }

        $stamp = Get-Date -Format "yyyyMMdd_HHmmss_fff"
        $safeResult = if ($result -match '^(win|draw|loss|unclassified)$') { $result } else { "unclassified" }
        $baseName = "Point_{0}_match{1:D4}_{2}" -f $stamp, $matchNumber, $safeResult
        $fullName = "$baseName`_full.png"
        $roiName = "$baseName`_score_area.png"
        $fullPath = Join-Path $script:pointSampleFullDir $fullName
        $roiPath = Join-Path $script:pointSampleRoiDir $roiName

        try {
            $bitmap.Save($fullPath, [Drawing.Imaging.ImageFormat]::Png)

            # Broad normalized reward-panel crop. It deliberately includes the
            # label as well as the signed value so future OCR can validate both
            # '승점' and high-tier '점수 획득' layouts.
            $left = [Math]::Max(0, [int]($bitmap.Width * 0.27))
            $top = [Math]::Max(0, [int]($bitmap.Height * 0.27))
            $right = [Math]::Min($bitmap.Width, [int]($bitmap.Width * 0.99))
            $bottom = [Math]::Min($bitmap.Height, [int]($bitmap.Height * 0.82))
            $roiRect = New-Object Drawing.Rectangle($left, $top, ($right - $left), ($bottom - $top))
            $roiBitmap = $bitmap.Clone($roiRect, [Drawing.Imaging.PixelFormat]::Format32bppArgb)
            try {
                $roiBitmap.Save($roiPath, [Drawing.Imaging.ImageFormat]::Png)
            } finally {
                $roiBitmap.Dispose()
            }
        } finally {
            $width = $bitmap.Width
            $height = $bitmap.Height
            $bitmap.Dispose()
        }

        $indexPath = Join-Path $script:pointSampleDir "point_samples.csv"
        if (-not [IO.File]::Exists($indexPath)) {
            Add-Content -LiteralPath $indexPath -Value "time,session,today,total,result,match_score,full_file,score_area_file,width,height" -Encoding UTF8
        }
        $row = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9}" -f `
            (Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"), $script:sessionMatchCount,
            $script:todayMatchCount, $script:totalMatchCount, $safeResult, $scoreText,
            $fullName, $roiName, $width, $height
        Add-Content -LiteralPath $indexPath -Value $row -Encoding UTF8
        $script:pointSampleCount++
        return $fullName
    } catch {
        Write-Log "점수 화면 샘플 저장 실패: $($_.Exception.Message)"
        return ""
    }
}

function Get-StableScoreResult($initialFrame) {
    $bestFrame = $initialFrame
    $lastScore = [FCScoreReader]::Read($initialFrame.Buffer)
    if ($lastScore.Found) {
        return [PSCustomObject]@{ Score = $lastScore; Frame = $initialFrame }
    }

    for ($attempt = 1; $attempt -le 6; $attempt++) {
        Start-Sleep -Milliseconds 250
        $info = Get-ForegroundInfo
        if (-not $info.Allowed -or $info.Handle -ne $initialFrame.Handle) { break }
        $nextFrame = Get-FCFrame $initialFrame.Handle
        if ($null -eq $nextFrame) { continue }
        $bestFrame = $nextFrame
        $lastScore = [FCScoreReader]::Read($nextFrame.Buffer)
        if ($lastScore.Found) {
            return [PSCustomObject]@{ Score = $lastScore; Frame = $nextFrame }
        }
    }
    return [PSCustomObject]@{ Score = $lastScore; Frame = $bestFrame }
}

function Register-CompletedMatch($frame) {
    if ($script:resultScreenCounted) { return }
    $script:resultScreenCounted = $true

    $today = Get-Date -Format "yyyy-MM-dd"
    if ($script:statsDate -ne $today) {
        $script:statsDate = $today
        $script:todayMatchCount = 0
        $script:todayWinCount = 0
        $script:todayDrawCount = 0
        $script:todayLossCount = 0
        $script:todayUnclassifiedCount = 0
    }

    $settled = Get-SettledResultFrame $frame
    $frameForAnalysis = $settled.Frame
    Set-Status "경기 결과 판정 및 점수 저장 중" ([Drawing.Color]::FromArgb(236, 190, 86))
    $analysis = Get-StableScoreResult $frameForAnalysis
    $result = "unclassified"
    $resultLabel = "미분류"
    $scoreText = "점수 인식 실패"
    if ($analysis.Score.Found) {
        $leftScore = [int]$analysis.Score.LeftScore
        $rightScore = [int]$analysis.Score.RightScore
        $scoreText = "$leftScore`:$rightScore"
        if ($leftScore -gt $rightScore) { $result = "win"; $resultLabel = "승" }
        elseif ($leftScore -eq $rightScore) { $result = "draw"; $resultLabel = "무" }
        else { $result = "loss"; $resultLabel = "패" }
    }

    $script:sessionMatchCount++
    $script:todayMatchCount++
    $script:totalMatchCount++
    switch ($result) {
        "win" {
            $script:sessionWinCount++; $script:todayWinCount++; $script:totalWinCount++
        }
        "draw" {
            $script:sessionDrawCount++; $script:todayDrawCount++; $script:totalDrawCount++
        }
        "loss" {
            $script:sessionLossCount++; $script:todayLossCount++; $script:totalLossCount++
        }
        default {
            $script:sessionUnclassifiedCount++; $script:todayUnclassifiedCount++; $script:totalUnclassifiedCount++
        }
    }
    Save-MatchStats
    Update-MatchCounter
    $sampleName = Save-ResultSample $analysis.Frame $script:totalMatchCount $result $scoreText
    $pointSampleName = Save-PointSample $analysis.Frame $script:totalMatchCount $result $scoreText
    Update-MatchCounter
    $sampleText = if ([string]::IsNullOrWhiteSpace($sampleName)) { "샘플 저장 실패" } else { "샘플: $sampleName" }
    $pointSampleText = if ([string]::IsNullOrWhiteSpace($pointSampleName)) { "점수 샘플 저장 실패" } else { "점수 샘플: $pointSampleName" }
    Write-Log "경기 완료 집계: $scoreText $resultLabel · $(Get-MatchSummary) · $sampleText · $pointSampleText"
    if (-not $settled.SameWindow) {
        Write-Log "결과 화면 대기 중 FC 창 선택이 해제되어 입력은 보류합니다. 저장된 화면을 확인해 주세요."
    }
    Save-DiagnosticInfo "경기 완료: $scoreText $resultLabel"

    if (($script:sessionMatchCount % 20) -eq 0) {
        Queue-DiscordNotification "FC 감독모드 20판 진행 알림" "$(Get-MatchSummary)`n최근 경기: $scoreText $resultLabel"
    }
}

function Test-DiscordWebhookUrl([string]$url) {
    if ([string]::IsNullOrWhiteSpace($url)) { return $false }
    return $url -match '^https://(canary\.|ptb\.)?(discord(?:app)?\.com)/api/webhooks/[0-9]+/[A-Za-z0-9._-]+/?$'
}

function Protect-DiscordWebhook([string]$url) {
    $secure = ConvertTo-SecureString -String $url -AsPlainText -Force
    return ConvertFrom-SecureString -SecureString $secure
}

function Unprotect-DiscordWebhook {
    if ([string]::IsNullOrWhiteSpace($script:encryptedWebhook)) { return "" }
    try {
        $secure = ConvertTo-SecureString -String $script:encryptedWebhook
        $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
        try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer) }
        finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) }
    } catch {
        return ""
    }
}

function Save-DiscordSettings {
    $settings = [ordered]@{
        DiscordEnabled = [bool]$script:discordEnabled
        EncryptedWebhook = [string]$script:encryptedWebhook
    }
    $settings | ConvertTo-Json | Set-Content -LiteralPath $script:settingsPath -Encoding UTF8
}

function Load-DiscordSettings {
    if (-not [IO.File]::Exists($script:settingsPath)) { return }
    try {
        $settings = Get-Content -LiteralPath $script:settingsPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $script:discordEnabled = [bool]$settings.DiscordEnabled
        $script:encryptedWebhook = [string]$settings.EncryptedWebhook
        $savedUrl = Unprotect-DiscordWebhook
        if (Test-DiscordWebhookUrl $savedUrl) {
            $webhookBox.Text = $savedUrl
            $discordCheck.Checked = $script:discordEnabled
            $discordStatus.Text = "암호화하여 저장된 웹훅을 불러왔습니다."
        } else {
            $script:discordEnabled = $false
            $script:encryptedWebhook = ""
            $discordCheck.Checked = $false
            $discordStatus.Text = "저장된 웹훅을 사용할 수 없습니다. 다시 입력해 주세요."
        }
    } catch {
        $script:discordEnabled = $false
        $script:encryptedWebhook = ""
        $discordStatus.Text = "설정을 불러오지 못했습니다. 웹훅을 다시 저장해 주세요."
    }
}

function Save-DiscordSettingsFromUi {
    $url = $webhookBox.Text.Trim()
    if (-not (Test-DiscordWebhookUrl $url)) {
        throw "Discord 웹훅 주소 형식이 올바르지 않습니다."
    }
    $script:encryptedWebhook = Protect-DiscordWebhook $url
    $script:discordEnabled = [bool]$discordCheck.Checked
    Save-DiscordSettings
    $discordStatus.Text = if ($script:discordEnabled) { "알림 사용 중" } else { "저장됨 · 알림 꺼짐" }
    Write-Log "Discord 웹훅 설정을 안전하게 저장했습니다."
}

function Queue-DiscordNotification([string]$titleText, [string]$message, [bool]$force = $false) {
    if (-not $force -and -not $script:discordEnabled) { return }
    $url = Unprotect-DiscordWebhook
    if (-not (Test-DiscordWebhookUrl $url)) {
        Write-Log "Discord 알림을 보내지 못했습니다: 저장된 웹훅을 확인해 주세요."
        return
    }
    $item = [PSCustomObject]@{
        Url = $url
        Title = $titleText
        Message = $message
        Attempt = 0
        DueAt = [DateTime]::Now
    }
    $script:notificationQueue.Enqueue($item)
}

function Process-DiscordQueue {
    if ($null -ne $script:activeNotification) {
        $active = $script:activeNotification
        if (-not $active.Task.IsCompleted) { return }
        $success = $false
        $failure = ""
        try {
            if ($active.Task.IsCanceled) {
                $failure = "전송 시간 초과"
            } elseif ($active.Task.IsFaulted) {
                $failure = $active.Task.Exception.GetBaseException().Message
            } else {
                $response = $active.Task.Result
                $success = $response.IsSuccessStatusCode
                if (-not $success) { $failure = "HTTP $([int]$response.StatusCode)" }
                $response.Dispose()
            }
        } catch {
            $failure = $_.Exception.Message
        } finally {
            $active.Content.Dispose()
        }

        if ($success) {
            Write-Log "Discord 알림을 보냈습니다: $($active.Item.Title)"
            $discordStatus.Text = "최근 알림 전송 성공: $(Get-Date -Format 'HH:mm:ss')"
        } else {
            $active.Item.Attempt++
            if ($active.Item.Attempt -lt 3) {
                $active.Item.DueAt = [DateTime]::Now.AddSeconds([Math]::Pow(2, $active.Item.Attempt))
                $script:notificationQueue.Enqueue($active.Item)
                Write-Log "Discord 알림 전송 재시도 $($active.Item.Attempt)/2"
            } else {
                if ($failure.Length -gt 120) { $failure = $failure.Substring(0, 120) }
                Write-Log "Discord 알림 전송 실패: $failure"
                $discordStatus.Text = "최근 알림 전송 실패 · 웹훅/인터넷 확인"
            }
        }
        $script:activeNotification = $null
    }

    if ($null -eq $script:activeNotification -and $script:notificationQueue.Count -gt 0) {
        $next = $script:notificationQueue.Peek()
        if ([DateTime]::Now -lt $next.DueAt) { return }
        [void]$script:notificationQueue.Dequeue()
        $contentText = "**$($next.Title)**`n$($next.Message)`n시간: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
        if ($contentText.Length -gt 1900) { $contentText = $contentText.Substring(0, 1900) }
        $payload = @{ content = $contentText; username = "FC Manager Assistant" } | ConvertTo-Json -Compress
        $content = [System.Net.Http.StringContent]::new($payload, [Text.Encoding]::UTF8, "application/json")
        $task = $script:httpClient.PostAsync($next.Url, $content)
        $script:activeNotification = [PSCustomObject]@{ Item = $next; Task = $task; Content = $content }
    }
}

function Send-StuckAlert([string]$reason) {
    $now = [DateTime]::Now
    if (($now - $script:lastStuckAlertAt).TotalMinutes -lt 10) { return }
    $script:lastStuckAlertAt = $now
    $script:stuckAlertActive = $true
    Queue-DiscordNotification "FC 감독모드 멈춤 감지" "$reason`n$(Get-MatchSummary)`nPC에서 FC 온라인 화면과 도우미 로그를 확인해 주세요."
    Write-Log "멈춤 가능성을 감지했습니다: $reason"
    Save-DiagnosticInfo "멈춤 감지: $reason"
}

function Mark-AutomationProgress([string]$fileName, [string]$label) {
    $wasStuck = $script:stuckAlertActive
    $script:lastProgressAt = [DateTime]::Now

    if ($script:lastRecognizedFile -eq $fileName) {
        $script:sameScreenActionCount++
    } else {
        $script:lastRecognizedFile = $fileName
        $script:sameScreenActionCount = 1
        $script:sameScreenSince = [DateTime]::Now
        $script:stuckAlertActive = $false
        if ($wasStuck) {
            Queue-DiscordNotification "FC 감독모드 정상 작동 재개" "새 화면 '$label'을 인식해 자동 진행이 다시 작동했습니다.`n$(Get-MatchSummary)"
        }
    }

    if ($script:sameScreenActionCount -ge 3 -and
        ([DateTime]::Now - $script:sameScreenSince).TotalSeconds -ge 15) {
        Send-StuckAlert "'$label' 화면에서 같은 동작이 반복되고 15초 이상 화면이 바뀌지 않았습니다."
    }
}

function Show-TopmostError([string]$message, [string]$titleText = "FC 감독모드 도우미 오류") {
    $previousTopMost = $form.TopMost
    try {
        if ($form.WindowState -eq [System.Windows.Forms.FormWindowState]::Minimized) {
            $form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
        }
        $form.Show()
        $form.TopMost = $true
        $form.BringToFront()
        $form.Activate()
        [System.Windows.Forms.MessageBox]::Show(
            $form,
            $message,
            $titleText,
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    } finally {
        $form.TopMost = $previousTopMost
    }
}

function Get-ForegroundInfo {
    $handle = [FCNative]::GetForegroundWindow()
    if ($handle -eq [IntPtr]::Zero) {
        return [PSCustomObject]@{ Handle = $handle; Allowed = $false; Title = "창 없음"; Process = "" }
    }
    $titleText = [FCNative]::GetTitle($handle)
    $processName = [FCNative]::GetProcessName($handle)
    $allowed = ($processName -ieq "fczf") -or ($titleText -like "*FC ONLINE*")
    return [PSCustomObject]@{ Handle = $handle; Allowed = $allowed; Title = $titleText; Process = $processName }
}

function Get-FCWindowInfo {
    foreach ($process in @(Get-Process -Name "fczf" -ErrorAction SilentlyContinue)) {
        try {
            if ($process.MainWindowHandle -ne [IntPtr]::Zero) {
                return [PSCustomObject]@{
                    Handle = $process.MainWindowHandle
                    Allowed = $true
                    Title = $process.MainWindowTitle
                    Process = $process.ProcessName
                }
            }
        } catch {}
    }
    return $null
}

function Get-FCFrame([IntPtr]$handle) {
    $rect = New-Object FCNative+RECT
    if (-not [FCNative]::GetWindowRect($handle, [ref]$rect)) { return $null }
    $width = $rect.Right - $rect.Left
    $height = $rect.Bottom - $rect.Top
    if ($width -lt 640 -or $height -lt 360) { return $null }

    $bitmap = New-Object Drawing.Bitmap($width, $height)
    $graphics = [Drawing.Graphics]::FromImage($bitmap)
    try {
        $graphics.CopyFromScreen($rect.Left, $rect.Top, 0, 0, (New-Object Drawing.Size($width, $height)))
        $buffer = [FCTemplateMatcher]::FromBitmap($bitmap)
        return [PSCustomObject]@{ Rect = $rect; Buffer = $buffer; Handle = $handle }
    } finally {
        $graphics.Dispose()
        $bitmap.Dispose()
    }
}

function Invoke-KeyTap([System.UInt16]$scanCode) {
    if (-not [FCNative]::SendScanCode($scanCode, $false)) {
        throw "키 누르기 입력에 실패했습니다. Windows 오류: $([FCNative]::LastInputError)"
    }
    Start-Sleep -Milliseconds 65
    if (-not [FCNative]::SendScanCode($scanCode, $true)) {
        throw "키 떼기 입력에 실패했습니다. Windows 오류: $([FCNative]::LastInputError)"
    }
}

function Find-TemplateAction($frame) {
    # Uniform confirmation is checked first because the same screen also
    # contains the opponent's '준비 완료' indicator.
    $priority = @("space_2.png", "space_1.png", "space_3.png", "click_1.png", "click_2.png",
                  "click_3.png", "click_4.png", "skip.png", "s.png", "esc.png", "client.png")

    foreach ($fileName in $priority) {
        $template = $script:templates | Where-Object { $_.Definition.File -eq $fileName } | Select-Object -First 1
        if ($null -eq $template) { continue }

        $definition = $template.Definition
        if ($script:lastTemplateActions.ContainsKey($definition.File)) {
            $lastTime = [DateTime]$script:lastTemplateActions[$definition.File]
            if (([DateTime]::Now - $lastTime).TotalMilliseconds -lt $definition.Cooldown) {
                continue
            }
        }

        $match = [FCTemplateMatcher]::Find(
            $frame.Buffer,
            $template.Buffer,
            $definition.X1,
            $definition.Y1,
            $definition.X2,
            $definition.Y2,
            $definition.Threshold
        )
        if ($match.Found) {
            return [PSCustomObject]@{ Template = $template; Match = $match }
        }
    }
    return $null
}

function Invoke-TemplateAction($recognized, $frame) {
    $definition = $recognized.Template.Definition
    $match = $recognized.Match
    $actionText = ""
    $stopAfterThisAction = $false

    if ($definition.File -ne "space_3.png" -and $definition.Action -ne "none") {
        $script:resultScreenCounted = $false
    }

    switch ($definition.Action) {
        "click" {
            $screenX = $frame.Rect.Left + $match.X + [int]($recognized.Template.Buffer.Width / 2)
            $screenY = $frame.Rect.Top + $match.Y + [int]($recognized.Template.Buffer.Height / 2)
            if (-not [FCNative]::SendLeftClick($screenX, $screenY)) {
                throw "마우스 클릭 입력에 실패했습니다. Windows 오류: $([FCNative]::LastInputError)"
            }
            $actionText = "클릭"
        }
        "space" {
            if ($definition.File -eq "space_3.png") {
                Register-CompletedMatch $frame
                $stopAfterThisAction = $script:stopAfterCurrentMatch
                $infoAfterCapture = Get-ForegroundInfo
                if ($onlyFcCheck.Checked -and
                    (-not $infoAfterCapture.Allowed -or $infoAfterCapture.Handle -ne $frame.Handle)) {
                    $script:paused = $true
                    $script:resumeStableSince = $null
                    $windowLabel.Text = "점수 화면 저장 완료 · FC 창 복귀 대기"
                    Write-Log "점수 화면 저장 중 창이 바뀌어 Space 입력을 안전하게 보류했습니다."
                    return
                }
            }
            Invoke-KeyTap 0x39
            $actionText = "Space"
        }
        "esc" {
            Invoke-KeyTap 0x01
            $actionText = "Esc"
        }
        "s" {
            Invoke-KeyTap 0x1F
            $actionText = "S"
        }
        "none" {
            $actionText = "입력 없음"
        }
    }

    $script:lastTemplateActions[$definition.File] = [DateTime]::Now
    if ($definition.Action -ne "none") {
        Mark-AutomationProgress $definition.File $definition.Label
        $script:actionCount++
        Update-Counters
    }
    $windowLabel.Text = "인식 화면: $($definition.Label) · 동작: $actionText"
    Write-Log ("화면 인식: {0} -> {1} (차이 {2:N1})" -f $definition.File, $actionText, $match.MeanDifference)

    if ($stopAfterThisAction) {
        Stop-Automation "이번 판 완료"
        Set-Status "이번 판 완료 · 자동 진행 중지" ([Drawing.Color]::FromArgb(150, 156, 166))
        $windowLabel.Text = "경기 결과 저장 및 다음 화면 이동 완료"
        Write-Log "예약한 이번 경기를 완료하여 자동 진행을 중지했습니다."
    }
}

function Set-Status([string]$text, [Drawing.Color]$color) {
    $statusLabel.Text = $text
    $statusDot.ForeColor = $color
}

function Update-Counters {
    $counterLabel.Text = "화면 동작: $($script:actionCount)회   |   자동 일시정지: $($script:pauseCount)회"
}

function Start-Automation {
    if ($script:running) { return }
    $info = Get-ForegroundInfo
    $script:running = $true
    $script:paused = $onlyFcCheck.Checked -and -not $info.Allowed
    $script:nextScanDue = [DateTime]::Now.AddMilliseconds(500)
    $script:resumeStableSince = $null
    $script:lastTemplateActions.Clear()
    $script:lastRecognizedFile = ""
    $script:sameScreenActionCount = 0
    $script:sameScreenSince = [DateTime]::Now
    $script:lastProgressAt = [DateTime]::Now
    $script:stuckAlertActive = $false
    $script:resultScreenCounted = $false
    $script:stopAfterCurrentMatch = $false
    $startButton.Enabled = $false
    $stopButton.Enabled = $true
    $finishMatchButton.Enabled = $true
    $finishMatchButton.Text = "이번 판까지만"
    $finishMatchButton.BackColor = [Drawing.Color]::FromArgb(184, 126, 45)
    if ($script:paused) {
        Set-Status "FC 창 대기 중" ([Drawing.Color]::FromArgb(236, 190, 86))
        Write-Log "자동 진행을 준비했습니다. FC ONLINE 창을 선택하면 시작합니다."
    } else {
        Set-Status "화면 인식 중" ([Drawing.Color]::FromArgb(83, 220, 120))
        Write-Log "화면 인식 자동 진행을 시작했습니다."
    }
}

function Stop-Automation([string]$reason) {
    if (-not $script:running) { return }
    # Release all mapped keys defensively.
    [void][FCNative]::SendScanCode(0x39, $true)
    [void][FCNative]::SendScanCode(0x1F, $true)
    [void][FCNative]::SendScanCode(0x01, $true)
    $script:running = $false
    $script:paused = $false
    $script:stopAfterCurrentMatch = $false
    $startButton.Enabled = $true
    $stopButton.Enabled = $false
    $finishMatchButton.Enabled = $false
    $finishMatchButton.Text = "이번 판까지만"
    $finishMatchButton.BackColor = [Drawing.Color]::FromArgb(184, 126, 45)
    Set-Status "대기 중" ([Drawing.Color]::FromArgb(150, 156, 166))
    Write-Log "자동 진행을 중지했습니다. ($reason)"
    Save-DiagnosticInfo "자동 진행 중지: $reason"
}

function Toggle-FinishMatchReservation {
    if (-not $script:running) { return }
    $script:stopAfterCurrentMatch = -not $script:stopAfterCurrentMatch
    if ($script:stopAfterCurrentMatch) {
        $finishMatchButton.Text = "중지 예약 취소"
        $finishMatchButton.BackColor = [Drawing.Color]::FromArgb(220, 139, 38)
        Set-Status "경기 종료 후 중지 예약" ([Drawing.Color]::FromArgb(236, 190, 86))
        Write-Log "이번 판 완료 후 자동 진행 중지를 예약했습니다. (버튼/F10)"
    } else {
        $finishMatchButton.Text = "이번 판까지만"
        $finishMatchButton.BackColor = [Drawing.Color]::FromArgb(184, 126, 45)
        Set-Status "화면 인식 중" ([Drawing.Color]::FromArgb(83, 220, 120))
        Write-Log "이번 판 완료 후 중지 예약을 취소했습니다. (버튼/F10)"
    }
}

function Save-FCScreenshot {
    $info = Get-FCWindowInfo
    if ($null -eq $info) {
        [System.Windows.Forms.MessageBox]::Show("실행 중인 FC ONLINE 창을 찾지 못했습니다.", "화면 저장") | Out-Null
        return
    }
    $rect = New-Object FCNative+RECT
    if (-not [FCNative]::GetWindowRect($info.Handle, [ref]$rect)) {
        [System.Windows.Forms.MessageBox]::Show("FC ONLINE 창 크기를 확인하지 못했습니다.", "화면 저장") | Out-Null
        return
    }
    $width = $rect.Right - $rect.Left
    $height = $rect.Bottom - $rect.Top
    if ($width -le 0 -or $height -le 0) { return }
    $form.Hide()
    [System.Windows.Forms.Application]::DoEvents()
    Start-Sleep -Milliseconds 300
    $bitmap = New-Object Drawing.Bitmap($width, $height)
    $graphics = [Drawing.Graphics]::FromImage($bitmap)
    try {
        $graphics.CopyFromScreen($rect.Left, $rect.Top, 0, 0, (New-Object Drawing.Size($width, $height)))
        $path = Join-Path $script:captureDir ("FC_{0}.png" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
        $bitmap.Save($path, [Drawing.Imaging.ImageFormat]::Png)
        Write-Log "FC 화면을 저장했습니다: $([IO.Path]::GetFileName($path))"
        [System.Windows.Forms.MessageBox]::Show("화면을 오류확인용_보내기\\captures 폴더에 저장했습니다.", "화면 저장") | Out-Null
    } finally {
        $graphics.Dispose()
        $bitmap.Dispose()
        $form.Show()
        $form.Activate()
    }
}

$startButton.Add_Click({ Start-Automation })
$stopButton.Add_Click({ Stop-Automation "중지 버튼" })
$finishMatchButton.Add_Click({ Toggle-FinishMatchReservation })
$captureButton.Add_Click({
    try {
        Save-FCScreenshot
    } catch {
        Write-Log "화면 저장 오류: $($_.Exception.Message)"
        Show-TopmostError $_.Exception.Message "FC 화면 저장 오류"
    }
})

$saveWebhookButton.Add_Click({
    try {
        Save-DiscordSettingsFromUi
        [System.Windows.Forms.MessageBox]::Show("Discord 알림 설정을 저장했습니다.", "설정 저장") | Out-Null
    } catch {
        Show-TopmostError $_.Exception.Message "Discord 설정 오류"
    }
})

$testWebhookButton.Add_Click({
    try {
        Save-DiscordSettingsFromUi
        Queue-DiscordNotification "FC 감독모드 테스트 알림" "Discord 직접 알림이 정상적으로 연결되었습니다." $true
        $discordStatus.Text = "테스트 알림 전송 중..."
    } catch {
        Show-TopmostError $_.Exception.Message "Discord 테스트 오류"
    }
})

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 25
$timer.Add_Tick({
    try {
        Process-DiscordQueue
        $f9Down = (([FCNative]::GetAsyncKeyState(0x78) -band 0x8000) -ne 0)
        $f10Down = (([FCNative]::GetAsyncKeyState(0x79) -band 0x8000) -ne 0)
        $f12Down = (([FCNative]::GetAsyncKeyState(0x7B) -band 0x8000) -ne 0)
        if ($f9Down -and -not $script:f9WasDown) { Start-Automation }
        if ($f10Down -and -not $script:f10WasDown) { Toggle-FinishMatchReservation }
        if ($f12Down -and -not $script:f12WasDown) { Stop-Automation "F12" }
        $script:f9WasDown = $f9Down
        $script:f10WasDown = $f10Down
        $script:f12WasDown = $f12Down

        $info = Get-ForegroundInfo
        $shownTitle = if ([string]::IsNullOrWhiteSpace($info.Title)) { $info.Process } else { $info.Title }
        if ([string]::IsNullOrWhiteSpace($shownTitle)) { $shownTitle = "확인 불가" }
        if ($shownTitle.Length -gt 70) { $shownTitle = $shownTitle.Substring(0, 70) + "..." }
        $windowLabel.Text = "현재 창: $shownTitle"

        if (-not $script:running) { return }

        $allowedNow = (-not $onlyFcCheck.Checked) -or $info.Allowed
        if (-not $allowedNow) {
            if (-not $script:paused) {
                $script:paused = $true
                $script:pauseCount++
                $script:resumeStableSince = $null
                [void][FCNative]::SendScanCode(0x39, $true)
                [void][FCNative]::SendScanCode(0x1F, $true)
                [void][FCNative]::SendScanCode(0x01, $true)
                Update-Counters
                Set-Status "자동 일시정지" ([Drawing.Color]::FromArgb(236, 190, 86))
                Write-Log "다른 창이 선택되어 입력을 멈췄습니다."
            }
            return
        }

        if ($script:paused) {
            if ($null -eq $script:resumeStableSince) {
                $script:resumeStableSince = [DateTime]::Now
                Set-Status "FC 창 복귀 확인 중" ([Drawing.Color]::FromArgb(236, 190, 86))
                return
            }
            if (([DateTime]::Now - $script:resumeStableSince).TotalMilliseconds -lt 1500) { return }
            $script:paused = $false
            $script:nextScanDue = [DateTime]::Now.AddMilliseconds(300)
            $script:lastTemplateActions.Clear()
            Set-Status "화면 인식 중" ([Drawing.Color]::FromArgb(83, 220, 120))
            Write-Log "FC ONLINE 창으로 돌아와 화면 인식을 재개합니다."
        }

        if ([DateTime]::Now -lt $script:nextScanDue) { return }
        $script:nextScanDue = [DateTime]::Now.AddMilliseconds(650)

        $frame = Get-FCFrame $info.Handle
        if ($null -eq $frame) {
            Set-Status "FC 화면 캡처 대기" ([Drawing.Color]::FromArgb(236, 190, 86))
            return
        }

        $recognized = Find-TemplateAction $frame
        if ($null -ne $recognized) {
            Invoke-TemplateAction $recognized $frame
            if ($script:running) {
                Set-Status "화면 인식 작동 중" ([Drawing.Color]::FromArgb(83, 220, 120))
            }
        } else {
            Set-Status "등록 화면 대기 중" ([Drawing.Color]::FromArgb(120, 180, 235))
            if (([DateTime]::Now - $script:lastProgressAt).TotalMinutes -ge 20) {
                Send-StuckAlert "자동 진행 중 20분 동안 다음 조작 화면을 인식하지 못했습니다."
            }
        }
    } catch {
        $message = $_.Exception.Message
        Queue-DiscordNotification "FC 감독모드 프로그램 오류" "자동 진행이 오류로 중지되었습니다: $message`n$(Get-MatchSummary)"
        Stop-Automation "오류"
        Write-Log "오류: $message"
        Save-DiagnosticInfo "프로그램 오류: $message"
        Show-TopmostError $message
    }
})

$form.Add_FormClosing({
    if ($script:running) { Stop-Automation "프로그램 종료" }
    $timer.Stop()
    if ($null -ne $script:httpClient) { $script:httpClient.Dispose() }
})

Load-DiscordSettings
Load-MatchStats
Write-Log "프로그램을 실행했습니다. FC ONLINE 창을 선택한 뒤 F9를 눌러주세요."
Save-DiagnosticInfo "프로그램 시작"
$timer.Start()
[void]$form.ShowDialog()
