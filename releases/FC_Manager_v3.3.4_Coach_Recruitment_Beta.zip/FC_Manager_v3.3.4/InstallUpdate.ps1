﻿param([Parameter(Mandatory=$true)][string]$AppRoot,[Parameter(Mandatory=$true)][string]$ZipPath,
      [Parameter(Mandatory=$true)][string]$Sha256,[Parameter(Mandatory=$true)][string]$Version,
      [Parameter(Mandatory=$true)][int]$ParentId)
$ErrorActionPreference='Stop'
$status=Join-Path $AppRoot '.updates/last-result.json'
try {
    $parent=Get-Process -Id $ParentId -ErrorAction SilentlyContinue
    if($parent -and !$parent.WaitForExit(30000)){throw 'Application did not close; no files were changed.'}
    # Load only after the old process releases its files.
    . (Join-Path $AppRoot 'UpdateManager.ps1')
    $result=Install-FCUpdate $AppRoot $ZipPath $Sha256 $Version
    @{success=$true;version=$Version;message='업데이트를 완료했습니다.'}|ConvertTo-Json|Set-Content -LiteralPath $status -Encoding UTF8
} catch {
    @{success=$false;version=$Version;message=$_.Exception.Message}|ConvertTo-Json|Set-Content -LiteralPath $status -Encoding UTF8
    Add-Type -AssemblyName System.Windows.Forms
    [void][Windows.Forms.MessageBox]::Show("업데이트를 완료하지 못했습니다.`n$($_.Exception.Message)`n기존 프로그램을 다시 실행해 주세요.",'FC Manager Update')
    exit 1
}
Start-Process -FilePath (Join-Path $AppRoot 'Start_FC_Manager.cmd') -WorkingDirectory $AppRoot -WindowStyle Hidden
