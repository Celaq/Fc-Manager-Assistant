﻿# Shared release validation and transactional installer. No UI or network on import.
function Get-FCSha256([string]$path) {
    $stream=[IO.File]::OpenRead($path);$algorithm=[Security.Cryptography.SHA256]::Create()
    try{return ([BitConverter]::ToString($algorithm.ComputeHash($stream))).Replace('-','').ToLowerInvariant()}
    finally{$algorithm.Dispose();$stream.Dispose()}
}

function Test-FCRelease($manifest,[string]$currentVersion) {
    if($manifest.schemaVersion -ne 1){throw 'Unsupported release manifest.'}
    $version=[Version]::Parse([string]$manifest.version)
    if($version.Build -lt 0 -or $version.Revision -gt 0){throw 'Invalid release version.'}
    $url=[Uri]([string]$manifest.url)
    if($url.Scheme -ne 'https' -or $url.Host -ne 'raw.githubusercontent.com' -or
        $url.AbsolutePath -notmatch '^/Celaq/Fc-Manager-Assistant/(?:main|[a-f0-9]{40})/releases/[A-Za-z0-9_.-]+\.zip$' -or $url.Query -or $url.Fragment){throw 'Untrusted release URL.'}
    if([string]$manifest.sha256 -notmatch '^[a-fA-F0-9]{64}$'){throw 'Invalid release digest.'}
    $notes=[string]$manifest.notes
    if($notes.Length -gt 2000){$notes=$notes.Substring(0,2000)}
    return [PSCustomObject]@{Available=($version -gt [Version]$currentVersion);Version=$version.ToString();Url=$url.AbsoluteUri;Sha256=([string]$manifest.sha256).ToLowerInvariant();Notes=$notes}
}

function Resolve-FCManagedPath([string]$root,[string]$relative) {
    $relative=$relative.Replace('\','/')
    # Personal data and updater staging never occur in the release allowlist.
    if($relative -notmatch '^(?:FCManager\.ps1|UpdateManager\.ps1|InstallUpdate\.ps1|Start_FC_Manager\.cmd|version\.json|release-files\.json|[^/\\:]+\.txt|templates(?:_2560)?/[A-Za-z0-9_.-]+\.png)$' -or
        $relative.Contains('..') -or $relative.Contains(':')){throw "Unmanaged release path: $relative"}
    $base=[IO.Path]::GetFullPath($root).TrimEnd('\','/')+[IO.Path]::DirectorySeparatorChar
    $path=[IO.Path]::GetFullPath((Join-Path $root $relative))
    if(!$path.StartsWith($base,[StringComparison]::OrdinalIgnoreCase)){throw 'Release path escapes root.'}
    return $path
}

function Install-FCUpdate([string]$appRoot,[string]$zipPath,[string]$expectedSha,[string]$expectedVersion,[scriptblock]$AfterWrite) {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $appRoot=[IO.Path]::GetFullPath($appRoot)
    if(!(Test-Path -LiteralPath (Join-Path $appRoot 'FCManager.ps1'))){throw 'Application root not found.'}
    if((Get-FCSha256 $zipPath) -ne $expectedSha){throw 'Downloaded ZIP digest mismatch.'}
    $updateRoot=Join-Path $appRoot '.updates';[void][IO.Directory]::CreateDirectory($updateRoot)
    $lock=[IO.File]::Open((Join-Path $updateRoot 'install.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    $id=[Guid]::NewGuid().ToString('N');$stage=Join-Path $updateRoot ('staging/'+$id);$backup=Join-Path $updateRoot ('backups/'+$id)
    $written=[Collections.Generic.List[string]]::new();$existing=@{}
    try {
        [void][IO.Directory]::CreateDirectory($stage)
        $archive=[IO.Compression.ZipFile]::OpenRead($zipPath)
        try {
            if($archive.Entries.Count -gt 256){throw 'Too many release entries.'}
            $entries=@($archive.Entries|Where-Object{!$_.FullName.Replace('\','/').EndsWith('/')})
            # Permit a flat ZIP or exactly one enclosing release directory.
            $index=@($entries|Where-Object{$_.FullName.Replace('\','/') -match '(^|/)release-files\.json$'})
            if($index.Count -ne 1){throw 'Release file index missing or ambiguous.'}
            $indexName=$index[0].FullName.Replace('\','/')
            $prefix=$indexName.Substring(0,$indexName.Length-'release-files.json'.Length)
            $names=@{};$totalBytes=0L
            foreach($entry in $entries){
                $entryName=$entry.FullName.Replace('\','/')
                if(!$entryName.StartsWith($prefix,[StringComparison]::Ordinal)){throw 'Mixed release roots.'}
                $name=$entryName.Substring($prefix.Length)
                $dest=Resolve-FCManagedPath $stage $name
                if($names.ContainsKey($name)){throw 'Duplicate release file.'};$names[$name]=$true
                $totalBytes+=$entry.Length
                if($entry.Length -gt 20MB -or $totalBytes -gt 60MB){throw 'Release exceeds size limit.'}
                [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($dest))
                $entryStream=$entry.Open();$outputStream=[IO.File]::Create($dest)
                try{$entryStream.CopyTo($outputStream)}finally{$outputStream.Dispose();$entryStream.Dispose()}
            }
        } finally {$archive.Dispose()}
        $manifest=Get-Content -LiteralPath (Join-Path $stage 'release-files.json') -Raw -Encoding UTF8|ConvertFrom-Json
        $version=Get-Content -LiteralPath (Join-Path $stage 'version.json') -Raw -Encoding UTF8|ConvertFrom-Json
        if([Version]$manifest.version -ne [Version]$expectedVersion -or [Version]$version.version -ne [Version]$expectedVersion){throw 'Package version mismatch.'}
        $oldVersionPath=Join-Path $appRoot 'version.json'
        if(Test-Path -LiteralPath $oldVersionPath){
            $oldVersion=Get-Content -LiteralPath $oldVersionPath -Raw -Encoding UTF8|ConvertFrom-Json
            if([Version]$oldVersion.version -ge [Version]$expectedVersion){throw 'Same or older version cannot be installed.'}
        }
        $properties=@($manifest.files.PSObject.Properties)
        if($properties.Count -lt 5 -or $names.Count -ne $properties.Count+1){throw 'Release file index mismatch.'}
        foreach($required in @('FCManager.ps1','Start_FC_Manager.cmd','UpdateManager.ps1','InstallUpdate.ps1','version.json')){
            if($required -notin $properties.Name){throw "Required release file missing: $required"}
        }
        foreach($p in $properties){
            $path=Resolve-FCManagedPath $stage $p.Name
            if([string]$p.Value -notmatch '^[a-fA-F0-9]{64}$' -or !(Test-Path -LiteralPath $path) -or
                (Get-FCSha256 $path) -ne [string]$p.Value){throw "Release file digest mismatch: $($p.Name)"}
        }
        # Back up every managed destination before the first mutation.
        $allNames=@($properties.Name)+@('release-files.json')
        foreach($name in $allNames){
            $dest=Resolve-FCManagedPath $appRoot $name
            $existing[$name]=[IO.File]::Exists($dest)
            if($existing[$name]){
                $saved=Resolve-FCManagedPath $backup $name
                [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($saved))
                [IO.File]::Copy($dest,$saved,$false)
            }
        }
        try {
            foreach($name in $allNames){
                $dest=Resolve-FCManagedPath $appRoot $name
                [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($dest))
                # Include the current file in rollback even if its copy fails midway.
                $written.Add($name)
                [IO.File]::Copy((Resolve-FCManagedPath $stage $name),$dest,$true)
                if($AfterWrite){& $AfterWrite $written.Count}
                if($name -ne 'release-files.json' -and
                    (Get-FCSha256 $dest) -ne [string]$manifest.files.PSObject.Properties[$name].Value){throw 'Installed file digest mismatch.'}
            }
        } catch {
            $originalError=$_
            $restoreErrors=[Collections.Generic.List[string]]::new()
            foreach($name in $written){
                try {
                    $dest=Resolve-FCManagedPath $appRoot $name
                    if($existing[$name]){[IO.File]::Copy((Resolve-FCManagedPath $backup $name),$dest,$true)}
                    elseif([IO.File]::Exists($dest)){[IO.File]::Delete($dest)}
                } catch {$restoreErrors.Add("$name : $($_.Exception.Message)")}
            }
            if($restoreErrors.Count){throw "Update failed; rollback incomplete. Backup: $backup. $($restoreErrors -join '; ')"}
            throw "Update failed and was rolled back. $($originalError.Exception.Message)"
        }
        return [PSCustomObject]@{Success=$true;Version=$expectedVersion;Backup=$backup}
    } finally {$lock.Dispose()}
}
